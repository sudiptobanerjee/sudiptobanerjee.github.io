residuals_read.table("c:/My Projects/CppProjects/Slopes/SlopeResidualPredictions/SpatialResiduals_Matern.txt", header=F)


w.bar_vector()

for(i in 1:ncol(residuals)) {
	w.bar[i]_mean(residuals[500:1000,i])
}

Sites_read.table("c:/My Projects/CppProjects/Slopes/SlopeResidualPredictions/InputData_Matern.txt", header=F)

Sites_Sites[,1:2]

#Sites_6371*Sites*pi/180

#Sites[,1]_Sites[,1] - min(Sites[,1])
#Sites[,2]_Sites[,2] - min(Sites[,2])
#Sites_cbind(Sites[,1],Sites[,2])

slopes_cbind(Sites, w.bar)

x_slopes[,1]
y_slopes[,2]
z_slopes[,3]
slopes.interp_interp.new(x,y,z, extrap=T)

#par(mfrow=c(1,2))

ax_min(Sites[,1])
bx_max(Sites[,1])

ay_min(Sites[,2])
by_max(Sites[,2])

image(slopes.interp,xlim=c(0,10), ylim=c(0,10),xaxs="r",yaxs="r", xlab=" ",ylab=" ")

par(new=T)

contour(slopes.interp, xlim=c(0,10), ylim=c(0,10),xaxs="r",yaxs="r",xlab="x", ylab="y")

