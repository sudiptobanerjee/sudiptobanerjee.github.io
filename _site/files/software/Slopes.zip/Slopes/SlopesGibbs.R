source ("c:/My Documents/RPrograms/gibbsfinal.R")

SlopesGibbs_gibbsfinal("c:/My Projects/BccProjects/Slopes/SlopesAnalysis/debug1.txt", 1000,500,2)

source ("c:/My Documents/RPrograms/quantiles.R")

ParamQnt_param.table(SlopesGibbs)

SlopePrediction_gibbsfinal("c:/My Projects/BccProjects/Slopes/SlopesPredictions/predict.txt", 1000, 500,2)

SlopesQnt_param.table(SlopePrediction)
