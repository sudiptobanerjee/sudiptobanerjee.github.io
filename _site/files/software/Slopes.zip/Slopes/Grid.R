a_read.table("c:/Program Files/Borland/Projects/GaussianFields/Simulated_Data.txt", header=F)
b_expand.grid(a[,1],a[,2])
write(t(b),"c:/Program Files/Borland/Projects/GaussianFields/Grid_Kriging/Grid_Matern.txt")

