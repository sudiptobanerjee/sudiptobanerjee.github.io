
nablaMu <- function (x, i) {
#	beta[i,2:3]
	c(0)
}

correlation.smooth <- function(phi, d)
{
 (1+phi*d)*exp(-phi*d)
}

correlation.analytic <- function(phi, d)
{
 exp(-phi*d^2)
}  

Sigma.inv <- function(i) {
  Sigma <- sigmasq[i] * correlation.smooth(phi[i],DIST)
#	Sigma <- sigmasq[i] * correlation.analytic(phi[i],DIST)	
	solve(Sigma)
}

Hess.k <- function(x, i) {
	if ((x[1]==0)&&(x[2]==0)) {
	H <- -sigmasq[i]*(phi[i])^2*diag(2)
#	H <- -2*sigmasq[i]*phi[i]*diag(2)
	}
	else {
		H <- matrix(0, 2,2)
		H[1,1] <- -sigmasq[i]*phi[i]^2*exp(-phi[i]*sqrt(sum(x*x)))*(1-phi[i]*x[1]^2/sqrt(sum(x*x)))
		H[1,2] <- -sigmasq[i]*phi[i]^2*exp(-phi[i]*sqrt(sum(x*x)))*x[1]*x[2]/sqrt(sum(x*x))
		H[2,1] <- H[1,2]
		H[2,2] <- -sigmasq[i]*phi[i]^2*exp(-phi[i]*sqrt(sum(x*x)))*(1-phi[i]*x[2]^2/sqrt(sum(x*x)))
	}
	H
}

Cov.Y.nablaY <- function(x, i) {
	out <- matrix(0, nrow=NSITES, ncol=2)
	for (j in 1:NSITES) {
		delta <- sqrt(sum(x[j,]*x[j,]))
		out[j,1] <- -sigmasq[i]*(phi[i]^2)*exp(-phi[i]*delta)*x[j,1]
		out[j,2] <- -sigmasq[i]*(phi[i]^2)*exp(-phi[i]*delta)*x[j,2]
#		out[j,1] <- -2*sigmasq[i]*phi[i]*exp(-phi[i]*delta^2)*x[j,1]
#		out[j,2] <- -2*sigmasq[i]*phi[i]*exp(-phi[i]*delta^2)*x[j,2]
	}
	out
}

Var.nablaY <- function(i) {
	- H.k - t(nablaK)%*%SigmaInv%*%nablaK	
}

Mean.nablaY <- function(i) {
	nablaMu(x.0,i) - t(nablaK)%*%SigmaInv%*%(Y - X%*%beta[i,])
}

True.Predictive <- function (sigmasq, phi, beta, Delta)
{
	nablaMu <- 0
	H.k <- 2*sigmasq*phi*diag(2)
	nablaK <- matrix(0, nrow=NSITES, ncol=2)
	for (j in 1:NSITES) {
		delta <- sqrt(sum(Delta[j,]*Delta[j,]))
		nablaK[j,1] <- -sigmasq*(phi^2)*exp(-phi*delta)*Delta[j,1]
		nablaK[j,2] <- -sigmasq*(phi^2)*exp(-phi*delta)*Delta[j,2]
#		nablaK[j,1] <- -2*sigmasq*phi*exp(-phi*delta^2)*Delta[j,1]
#		nablaK[j,2] <- -2*sigmasq*phi*exp(-phi*delta^2)*Delta[j,2]
	}
	Sigma <- sigmasq*correlation.smooth(phi,DIST)	
	SigmaInv <- solve(Sigma)
	Mean.nablaY <- nablaMu - t(nablaK)%*%SigmaInv%*%(Y - X%*%beta)
	Var.nablaY <- H.k - t(nablaK)%*%SigmaInv%*%nablaK
	Mean.nablaY
}
