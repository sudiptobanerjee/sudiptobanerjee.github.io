library(akima)

slopes <- read.table("Predict.txt",header=F)

x <- slopes[,1]
y <- slopes[,2]
z <- slopes[,3]-5.0

slopes.interp <- interp(x,y,z,duplicate="strip")

#par(mfrow=c(1,2))

image(slopes.interp,xlim=c(0,10), ylim=c(0,10),xaxs="r",yaxs="r")

par(new=T)

contour(slopes.interp, xlim=c(0,10), ylim=c(0,10),xaxs="r",yaxs="r")

points(c(3.5,5.0), c(3.5,5.0), pch=18)

