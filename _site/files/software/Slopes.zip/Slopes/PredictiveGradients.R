rm(list=ls(all=TRUE))

set.seed(1234)

NITER <- 1000
BURNIN <- 0

Sites <- read.table("SitesInputBGS.txt", header=F)
Y <- read.table("Ybgs.txt", header=F)
Y <- Y[,1]
X <- read.table("Xbgs.txt")
X <- as.matrix(X)

NSITES <- nrow(Sites)

parameters <- read.table("ParametersBGS.txt")
#parameters <- parameters[-c(1:BURNIN),]
parameters <- as.matrix(parameters)

NITER <- nrow(parameters)

beta <- matrix(parameters[,1],ncol=1,byrow=T)
sigmasq <- parameters[,2]
phi <- parameters[,3]

SigmaInv <- matrix(0, NSITES,NSITES)
nablaK <- matrix(0, NSITES,2)
H.k <- matrix(0, 2,2)
Y.pred <- matrix(0,NITER,2)


x.0 <- c(3.5,3.5)
x.0.mat <- matrix(rep(x.0, times=NSITES),ncol=2,byrow=T)

Delta <- Sites - x.0.mat

library(fields)
library(MASS)

DIST <- rdist(Sites)

source("Essentials.R")

for (i in 1:NITER) {
	print(i)
	print("Computing Sigma.inv")
	SigmaInv <- Sigma.inv(i)
	print("Computing H.k")
	H.k <- Hess.k(c(0,0),i)
	print("Computing nablaK")
	nablaK <- Cov.Y.nablaY(Delta, i)
	print("Computing pred.var")
	pred.var <- Var.nablaY(i) 
	print("Computing pred.mean")
	pred.mean <- Mean.nablaY(i)
	Y.pred[i,] <- mvrnorm(1, pred.mean, pred.var)
}

u <- c(1,1)
u <- u/sqrt(sum(u*u))

DuY <- Y.pred%*%u
DuY.qnt <- quantile(DuY, c(0.50,0.025,0.975))

detach(package:fields)
detach(package:MASS) 

beta <- c(5.0)
sigmasq <- 1.0
phi <- 0.5

print("True Value")
TrueValue <- True.Predictive(sigmasq, phi, beta, Delta)

