#ifndef GENERATORS_H
#define GENERATORS_H

/* Header file for generators.c */

#include "lapack.h"

double drand48(void);
double rexp (double scale);
double rnorm (double mu, double sigma);
double rnormal (double mu, double sigma);
double rgamma (double shape, double scale);
double rigamma (double shape, double scale);
double rlognorm (double mu, double sigma);
void multinomial (int *count, int n, int k, const vector &p);
void multinormal (vector &out, const vector &mean, const matrix &disp);
void rinvertwishart (matrix &wishart, const matrix &LAMDA, int m);
void rdirichlet (vector &x, const vector &phi, int dim);
double rweibull (double shape, double scale);

#endif

/* End of Header files */
