#ifndef ERRORS_H
#define ERRORS_H

extern FILE *ferr;
void nrerror(char error_text[]);

#endif
