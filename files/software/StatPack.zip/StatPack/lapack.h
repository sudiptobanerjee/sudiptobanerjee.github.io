#ifndef LAPACK_H
#define LAPACK_H

#include <stdio.h>

#define TINY 0.00001
#define SWAP(a,b) {temp=(a);(a)=(b);(b)=temp;}

class vector;
class matrix;

double min(double a, double b);
int min(int a, int b);

double max(double a, double b);
int max(int a, int b);

//Declarations of some fundamentally important procedures
double **create_matrixd (int row, int col);
int **create_matrix (int row, int col);
void out_of_store (void);
void freematd (double **a, int row, int col);
void freemat (double **a, int row, int col);
void freemat (int **a, int row, int col);
void ludcmp (double **a, int n, int *indx, double *d);
void lubksb (double **a, int n, int *indx, double b[]);
void solve (double *b, double **a, int n);
void inverse (double **ainv, double **a, int n);
void inverse (double **ainv, int n);
void gaussj(double **a, int n, double **b, int m);
double det (double **a, int n);
double fast_det (double **a, int n);
double *create_vectord (int dim);
int *create_vector (int dim);
void copy (double **c, double **a, int rows, int cols);
void copy (int **c, int **a, int rows, int cols);
void copy (double **c, int **a, int rows, int cols);
void copy (double *x, double *y, int dim);
void copy (int *x, int *y, int dim);
void copy (double *x, int *y, int dim);

void vecsum (double *vector, double *a, double *b, int dim);
void vecdiff (double *vector, double *a, double *b, int dim);
void vecsclpr (double *vector, double a, double *b, int dim);
double innerprod (double *x, double *y, int dim);
void swap (double **c, int u, int v1, int dim);
void sweep (double **c, int u, int dim);
void printvec (double *d, int dim);
void fprintmatINT (FILE *fout, int **d, int rows, int cols);
void fprintvec (FILE *fout, double *d, int dim);
void fprintvecINT (FILE *fout, int *d, int dim);
void freadmatINT (FILE *fin, int **d, int rows, int cols);
void symmetrize (double **a, int dim);
double sum_components (double *a, int start, int end);
int sum_componentsINT (int *a, int start, int end);

//Prototypes for Matrix class methods and functions

class matrix
{
public:
	matrix ();
	matrix (int nrows, int ncols);
	matrix (const matrix &rhs);
	~matrix ();
	void freeit ();
	matrix LU (void);
	matrix inv (void);
	matrix chol (void);
	double compu_trace (void);
	matrix transpose (void);
	void set_row (const int i, const vector &x);
	void set_col (const int j, const vector &x);

	matrix &operator = (const matrix &rhs);
        double &operator () (const int i, const int j) const;
        vector operator [] (const int i) const;

	friend matrix operator + (const matrix &A, const matrix &B);
	friend matrix operator - (const matrix &A, const matrix &B);
	friend matrix operator * (const matrix &A, const matrix &B);
	friend matrix operator * (const double x, const matrix &rhs);
	friend matrix operator * (const matrix &lhs, const double x);
	friend vector operator * (const matrix &lhs, const vector &x);
	friend vector operator * (const vector &x, const matrix &rhs);
	friend matrix operator / (const matrix &lhs, const double x);
        friend matrix operator % (const matrix &lhs, const matrix &rhs);


//Friend Functions:
	friend double **create_matrixd (int row, int col);
	friend int **create_matrix (int row, int col);
	friend	void freematd (double **a, int row, int col);
	friend	void freemat (double **a, int row, int col);
	friend	void freemat (int **a, int row, int col);
	friend	void ludcmp (double **a, int n, int *indx, double *d);
	friend	void lubksb (double **a, int n, int *indx, double b[]);
	friend	void solve (double *b, double **a, int n);
	friend	void inverse (double **ainv, double **a, int n);
	friend	double det (double **a, int n);
	friend	double *create_vectord (int dim);
	friend	int *create_vector (int dim);
	friend	void copy (double **c, double **a, int rows, int cols);
	friend	void copy (int **c, int **a, int rows, int cols);
	friend void copy (double **c, int **a, int rows, int cols);
//End Friends' list

public:
	int nrows, ncols;
	double **a, determinant, trace;
};

matrix I(int n);

//Linear Algebra functions using Matrices as classes

void transpose (matrix &C, const matrix &A);
matrix transpose (const matrix &A);

void matsum (matrix &C, const matrix &A, const matrix &B);
void matdiff (matrix &C, const matrix &A, const matrix &B);
void matpr (matrix &C, const matrix &A, const matrix &B);
void matsclpr (matrix &B, double x, const matrix &A);

void LU (matrix &lhs, matrix &rhs);
void fast_LU (matrix &arg);
matrix LU(const matrix &rhs);
double det (const matrix &A);
double fast_det (matrix &A);
double log_det (const matrix &A);
double fast_log_det (matrix &A);
double ellipse (double *x, const matrix &A, double *y);
void inverse (matrix &Ainv, const matrix &A);
void fast_inverse (matrix &Ainv);
matrix inverse (const matrix &A);
void solve (double *x, const matrix &A, double *b);
void solve (const matrix &A, double *b);
void solve (matrix &X, const matrix &A, const matrix &B);
void fast_solve (matrix &A, matrix &B);
void fast_solve (matrix &A, double *b);
void chol (matrix &l, const matrix &A);
void fast_chol (matrix &l, matrix &A);
matrix chol (const matrix &A);
void matvecpr (double *vector, const matrix &A, double *x);
double trace (const matrix &A);
void matinv (matrix &Ainv, const matrix &A);

void printmat (const matrix &A);
void fprintmat (FILE *fout, const matrix &A);
void fprintmat (const char *filename, const matrix &A);
void readmat (matrix &A);
void freadmat (FILE *fin, matrix &A);
void freadmat (const char *filename, matrix &A);
void sub_matrix (matrix &C, const matrix &A, int i1, int i2, int j1, int j2);
void BlockDiagonal (matrix &Out, const matrix &A, const matrix &B);
void BlockMatrix (matrix &Out, const matrix &A11, const matrix &A12,
                               const matrix &A21, const matrix &A22);
void symmetrize (matrix &A);
void perturbmat (matrix &A, double eps);
void vectomat (matrix &A, double *vector);
void kroneckerprod(matrix &C, const matrix &A, const matrix &B);

void tred2 (vector &d, vector &e, matrix &V);
void tql2 (vector &d, vector &e, matrix &V);
void orthes (vector &d, vector &e, vector &ort, matrix &V, matrix &H);
void cdiv(double xr, double xi, double yr, double yi);
void hqr2 (vector &d, vector &e, matrix &V, matrix &H);
void eigen(matrix &D, matrix &V, vector &d, vector &e, const matrix &Arg);

void svd (matrix &U, matrix &D, matrix &V, const matrix &Arg);

//Prototypes for vector class methods and functions

class vector
{
public:
	vector (); // Default constructor
	vector (int len);
	~vector (); // Destructor
	vector (const vector &rhs); //Copy constructor
	void freeit (void);
	double compu_norm (void);

    double &operator [] (const int i) const;
	vector &operator = (const vector &rhs);

	//Friend functions
	friend vector operator + (const vector &lhs, const vector &rhs);
	friend vector operator - (const vector &lhs, const vector &rhs);
	friend double operator * (const vector &lhs, const vector &rhs);
	friend vector operator * (const double x, const vector &rhs);
	friend vector operator * (const vector &lhs, const double x);
	friend vector operator * (const matrix &lhs, const vector &x);
	friend vector operator * (const vector &x, const matrix &rhs);
	friend vector operator / (const vector &lhs, const double x);
	friend void copy (double *x, double *y, int dim);
	friend double *create_vectord (int dim);
	friend int *create_vector (int dim);
	friend void vecsum (double *vector, double *a, double *b, int dim);
	friend void vecdiff (double *vector, double *a, double *b, int dim);
	friend void vecsclpr (double *vector, double a, double *b, int dim);

public:
	//Members
	int length;
	double *a, norm;
};

void copy (vector &lhs, const vector &rhs);
void vecsum (vector &out, const vector &lhs, const vector &rhs);
void vecdiff (vector &out, const vector &lhs, const vector &rhs);
void vecsclpr (vector &out, double x, const vector &rhs);
double innerprod (const vector &x, const vector &y);
double sum_components (const vector &x, int start, int end);
void sub_vector (vector &out, const vector &x, int start, int end);
void concatenate (vector &out, const vector &x, const vector &y);
void freadvec (FILE *fin, vector &A);
void freadvec (const char *filename, vector &A);
void printvec (const vector &x);

//Prototypes for functions involving matrices and vectors

void matvecpr (vector &out, const matrix &A, const vector &x);
void matvecpr (vector &out, const vector &x, const matrix &A);
void solve (vector &x, const matrix &A, const vector &b);
double ellipse (const vector &x, const matrix &A, const vector &y);
void Row_extract (vector &lhs, const matrix &rhs, const int &row_no);
void Col_extract (vector &lhs, const matrix &rhs, const int &col_no);
vector operator * (const matrix &lhs, const vector &x);
vector operator * (const vector &x, const matrix &rhs);


#endif

