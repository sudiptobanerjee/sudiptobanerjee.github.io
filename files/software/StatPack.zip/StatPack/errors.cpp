#include <cstdio>
#include <cstdlib>
#include "errors.h"

void nrerror(char error_text[])
/* Numerical Recipes standard error handler */
{
	fprintf(ferr,"Numerical Recipes run-time error...\n");
	fprintf(ferr,"%s\n",error_text);
	fprintf(ferr,"...now exiting to system...\n");
	exit(1);
}
