#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h> 
#include "lapack.h"
#include "generators.h"
#include "errors.h"

using namespace std;

/*double drand48 (void)
{
   return ((double)rand() + 0.5)/((double)RAND_MAX + 1.0);
   }
*/


double rexp (double scale)
{
	double U;

	U = -log (drand48 ()) / scale;
	
	return U;
}

double rnormal(double mu, double sigma)
{
	static int iset=0;
	static double gset;
	double fac,rsq,v1,v2;
   
	if  (iset == 0) {
		do {
			v1=2.0*drand48()-1.0;
			v2=2.0*drand48()-1.0;
			rsq=v1*v1+v2*v2;
		} while (rsq >= 1.0 || rsq == 0.0);
		fac=sqrt(-2.0*log(rsq)/rsq);
		gset=mu + sigma*v1*fac;
		iset=1;
		return mu + sigma*v2*fac;
	} else {
		iset=0;
		return gset;
	}
}
	    		 
double rnorm (double mu, double sigma)
{
 double y1, y2, u1, u2, s, b, x;
 
 s = 1.0;
  
 while (s >= 1) { 
	 
	 y1 = drand48 () ;
 	 y2 = drand48 () ;
	 
  		u1 = 2*y1 - 1;
  		u2 = 2*y2 - 1;

  		s = pow (u1,2) + pow (u2,2);
		if (s >= 1) continue;
		b = sqrt(( - (2 * log(s) / s)));

		x = b * u1;
  		x = mu + sigma * x;
 }

	return x;
}
/*
double rgamma (double shape, double scale)
{
   int i;
   double  b, h, r, g, f, x, r2, d, gamma1;

   b = shape - 1.0;
   
   if (b >=0) {
	   h = sqrt (3 * shape - 0.75);
	   for (i = 0; i < 1; i++) {
			gen:	r = drand48 ();
			g = r - pow(r, 2);
   			if (g <= 0.0) goto gen;
   			f = (r - 0.5) * h /sqrt(g);
   			x = b + f;
   			if (x <= 0.0) goto gen;
   			r2 = drand48 ();
   			d = 64 * g * (pow(r2*g, 2));
   			if (d <= 0) goto assign;
   			if (d*x < (x - 2*f*f)) goto assign;
   			if (log(d) > 2*(b*log(x/b) - f)) goto gen;
   			assign:	gamma1 = x;
   			gamma1 = (1 / scale) * gamma1;	
	   }
   }
   else if (b < 0) {
	   x = rgamma (shape+1, 1);
	   r = drand48 ();
	   x = x*pow(r, 1/shape);
	   gamma1 = x / scale;
   }
   return gamma1;
}     	
*/

double rigamma (double shape, double scale)
{
    double temp;
    	temp = rgamma (shape, scale);
    	temp = 1 / temp;
    return temp;
} 

double rgamma (double shape, double scale)
{
   int i;
   double  b, h, r, g, f, x, r2, d, gamma1=10;

   b = shape - 1.0;
   
   if (b >=0) {
	   h = sqrt (3 * shape - 0.75);
       do {
          do {
             do {
                r = drand48 ();
                g = r - pow(r, 2);
             } while (g <= 0.0);
             f = (r - 0.5) * h /sqrt(g);
   			 x = b + f;
           } while (x <= 0.0);
   			r2 = drand48 ();
   			d = 64 * g * (pow(r2*g, 2));
   			if (d <= 0) {
               gamma1 = x;
               break;
            }
   			if (d*x < (x - 2*f*f)) {
                gamma1 = x;
                 break;
            }
       } while (log(d) > 2*(b*log(x/b) - f));
       gamma1 = x;
       gamma1 = (1 / scale) * gamma1;
   }
   else if (b < 0) {
	   x = rgamma (shape+1, 1);
	   r = drand48 ();
	   x = x*pow(r, 1/shape);
	   gamma1 = x / scale;
   }
   return gamma1;
}     	

void multinomial (int *count, int n, int k, const vector &p)
{
  int i, j;
  double u, *z, sum;
  z = create_vectord (k+1);
 
  
  for (i = 0; i < k; i++) count[i] = 0;
  
  z[0] = 0; 
  for (i = 1; i <= k; i++) {
   	sum = 0;
  	for (j = 0; j < i; j++) sum+= p.a[j];
  	z[i] = sum;
  }
  	
 for (j = 0; j < n; j++) {
  	u = drand48();
  	
  	for (i = 0; i < k; i++) {
  	    if ((z[i] < u) && (u <= z[i+1])) count[i]++;
  	 }
  }
 free (z);  
}  

double rlognorm (double mu, double sigma)
{
	double x;

    x = rnorm (mu, sigma);
	x = exp(x);

	return x;
}

void multinormal (vector &out, const vector &mean, const matrix &disp)
{
	int i, dim = disp.nrows;
	vector x(dim), z(dim);

	matrix l(dim, dim);                                        

	chol (l, disp);

	for (i = 0; i < dim; i++) {
		z.a[i] = rnorm (0, 1);
	}

	matvecpr (x, l, z);
	for (i = 0; i < dim; i++) out.a[i] = mean.a[i] + x.a[i];   

//	l.freeit();
}
		
void rinvertwishart (matrix &wishart, const matrix &LAMDA, int m)
{
	int i, j, dim = LAMDA.nrows;
	vector temp(dim), mean(dim);

	matrix X(m, dim), tX(dim, m), temp2(dim, dim);

	for (i = 0; i < dim; i++) mean.a[i] = 0.0;
	for (i = 0; i < m; i++) {
		multinormal (temp, mean, LAMDA);
		for (j = 0; j < dim; j++) X.a[i][j] = temp.a[j];
	}
	
	transpose (tX, X);
	temp2 = tX*X;
	inverse (wishart, temp2);

//	temp2.freeit();
//	X.freeit();
//	tX.freeit();

}

void rwishart (matrix &wishart, const matrix &scale, int m)
{
	int dim = scale.nrows;

	matrix temp (dim, dim);

	rinvertwishart (temp, scale, m);

	inverse (wishart, temp);

	temp.freeit();
}

void rdirichlet (vector &x, vector const &phi, int dim)
{
	int i;
	double sum = 0.0;
	vector theta(dim);

	for (i = 0; i < dim; i++){
		theta.a[i] = rgamma(phi.a[i],1);
	}
	sum = sum_components(theta, 0, dim);
	
	for (i = 0; i < dim; i++) x.a[i] = theta.a[i] / sum;

}

double rweibull (double shape, double scale)
{
	double x;

	x = rexp(1.0);

	x = pow((x / scale), 1/shape);

	return x;
}

