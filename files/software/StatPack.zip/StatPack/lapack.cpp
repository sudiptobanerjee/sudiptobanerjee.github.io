#include <fstream>
#include <iostream>
#include <cstdlib>
#include <new>
#include <cstdio>
#include <cassert>
#include <cmath>
#include "lapack.h"

using namespace std;

//Fundamental numeric functions used here
double min(double a, double b)
{
  return (a <= b ? a : b);
}

int min(int a, int b)
{
  return (a <= b ? a : b);
}

double max(double a, double b)
{
  return (a >= b ? a : b);
}

int max(int a, int b)
{
  return (a >= b ? a : b);
}

//Fundamental functions - often used as friends
//by vector and matrix classes or invoked directly

double **create_matrixd (int row, int col)
{
  register int i;
  double **temp;
    
  set_new_handler (out_of_store);
  temp = new double *[row];
  //	assert(temp);
  for(i = 0; i < row; ++i) {
    temp[i] = new double [col];
    //        assert(temp[i]);
  }
  return temp;
}

int **create_matrix (int row, int col)
{
  register int i;
  int **temp;
  
  set_new_handler (out_of_store);
  temp = new int *[row];
  //	assert(temp);
  for(i = 0; i < row; ++i) {
    temp[i] = new int [col];
    //        assert(temp[i]);
  }
  return temp;
}

void out_of_store (void)
{
  int i;
  cout << "Operator new failed: out of memory\n";
  // throw bad_alloc();
  cout << "Press any key to exit console" << endl;
  (void) getchar ();
  exit(0);
}

void freemat (double **a, int row, int col)
{
  int i;
  
  for (i = 0; i < row; i++) delete [] a[i];
  delete [] a;
  a = 0;
}

void freemat (int **a, int row, int col)
{
  int i;
  
  for (i = 0; i < row; i++) delete [] a[i];
  delete [] a;
  a = 0;
}

void ludcmp (double **a, int n, int *indx, double *d)
{
  int i, imax, j, k;
  double  big, dum, sum, temp;
  double *vv;
  
  vv = create_vectord (n);
  *d = 1.0;
  
  for (i = 0; i < n; i++) {
    big = 0.0;
    for (j = 0; j < n; j++)
      if ((temp=fabs(a[i][j])) > big) big = temp;
    /*    if (big == 0.0) {
      printf("Singular matrix in routine ldcmp\n");
      getchar();
      exit (0);
    }
    */    vv[i] = 1/big;
  }
  
  for (j = 0; j < n; j++) {
    for (i = 0; i < j; i++) {
      sum = a[i][j];
      for (k = 0; k < i; k++) sum -= a[i][k] * a[k][j];
      a[i][j] = sum;
    }
    big = 0.0;
    for (i = j; i < n; i++) {
      sum = a[i][j];
      for (k = 0; k < j; k++) sum -= a[i][k] * a[k][j];
      a[i][j] = sum;
      if ((dum=vv[i] * fabs(sum)) >=big) {
	big = dum;
	imax = i;
      }
    }
    if (j != imax) {
      for (k = 0; k < n; k++) {
	dum = a[imax][k];
	a[imax][k] = a[j][k];
	a[j][k] = dum;
      }
      *d = - (*d);
      vv[imax] = vv[j];
    }
    indx[j] = imax;
    //    if (a[j][j] == 0.0) a[j][j] = TINY;
    if (a[j][j] == 0.0) {
      printf("Singular matrix in routine ldcmp\n");
      exit (0);
    }
    if (j != (n-1)) {
      dum = 1.0 / a[j][j];
      for (i = j+1; i < n; i++) a[i][j] *= dum;
    }
  }
  
  delete [] vv;
}

void lubksb (double **a, int n, int *indx, double b[])
{
  int i, ii = -1, ip, j;
  double sum;
  
  for (i = 0; i < n; i++) {
    ip = indx[i];
    sum = b[ip];
    b[ip] = b[i];
    if (ii >= 0) 
      for (j = ii; j < i; j++) sum -= a[i][j] * b[j];
    else if (sum) ii = i;
    b[i] = sum;
  }
  for (i = n-1; i >= 0; i--) {
    sum = b[i];
    for (j = i+1; j < n; j++) sum -= a[i][j]*b[j];
    b[i] = sum / a[i][i];
  }
}

void solve (double *b, double **a, int n)
{
  int *indx;
  double d, **temp;
  
  indx = create_vector (n);
  temp = create_matrixd (n, n);
  copy (temp, a, n, n);
  
  ludcmp (temp, n, indx, &d);
  lubksb (temp, n, indx, b);

  delete [] indx;
  freemat (temp, n, n);
}

void inverse (double **ainv, double **a, int n)
{
  double d, *col, **temp;
  int i, j, *indx;
  
  indx = create_vector (n);
  col = create_vectord (n);
  
  temp = create_matrixd (n, n);
  copy (temp, a, n, n);
  
  ludcmp (temp, n, indx, &d);
  
  for (j = 0; j < n; j++) {
    for (i = 0; i < n; i++) col[i] = 0.0;
    col[j] = 1.0;
    lubksb (temp, n, indx, col);
    for (i = 0; i < n; i++) ainv[i][j] = col[i];
  }
  
  freemat (temp, n, n);
  delete [] indx;
  delete [] col;
}

void inverse (double **ainv, int n)
{
  double d, *col, **temp;
  int i, j, *indx;
  
  indx = create_vector (n);
  col = create_vectord (n);
  temp = create_matrixd (n,n);
  
  ludcmp (ainv, n, indx, &d);
  copy (temp, ainv, n, n);
  
  for (j = 0; j < n; j++) {
    for (i = 0; i < n; i++) col[i] = 0.0;
    col[j] = 1.0;
    lubksb (temp, n, indx, col);
    for (i = 0; i < n; i++) ainv[i][j] = col[i];
  }
  freemat(temp, n, n);
  delete [] indx;
  delete [] col;
}

void gaussj(double **a, int n, double **b, int m)
{
  int *indxc,*indxr,*ipiv;
  int i,icol,irow,j,k,l,ll;
  double big,dum,pivinv,temp;
  
  indxc=create_vector(n);
  indxr=create_vector(n);
  ipiv=create_vector(n);
  for (j=0;j<n;j++) ipiv[j]=0;
  for (i=0;i<n;i++) {
    big=0.0;
    for (j=0;j<n;j++)
      if (ipiv[j] != 1)
	for (k=0;k<n;k++) {
	  if (ipiv[k] == 0) {
	    if (fabs(a[j][k]) >= big) {
	      big=fabs(a[j][k]);
	      irow=j;
	      icol=k;
	    }
	  } else if (ipiv[k] > 1) {
	    cout << "gaussj: Singular Matrix-1" << endl;
	    exit(1);
	  }
	}
    ++(ipiv[icol]);
    if (irow != icol) {
      for (l=0;l<n;l++) SWAP(a[irow][l],a[icol][l])
			  for (l=0;l<m;l++) SWAP(b[irow][l],b[icol][l])
					      }
    indxr[i]=irow;
    indxc[i]=icol;
    if (a[icol][icol] == 0.0) cout << "gaussj: Singular Matrix-2" << endl;
    pivinv=1.0/a[icol][icol];
    a[icol][icol]=1.0;
    for (l=0;l<n;l++) a[icol][l] *= pivinv;
    for (l=0;l<m;l++) b[icol][l] *= pivinv;
    for (ll=0;ll<n;ll++)
      if (ll != icol) {
	dum=a[ll][icol];
	a[ll][icol]=0.0;
	for (l=0;l<n;l++) a[ll][l] -= a[icol][l]*dum;
	
        for (l=0;l<m;l++) b[ll][l] -= b[icol][l]*dum;
      }
  }
  for (l=n-1;l>=0;l--) {
    if (indxr[l] != indxc[l])
      for (k=0;k<n;k++)
	SWAP(a[k][indxr[l]],a[k][indxc[l]]);
  }
  delete [] ipiv;
  delete [] indxr;
  delete [] indxc;
}

double det (double **a, int n)
{
  double d = 1.0, **temp;
  int j, *indx;
  
  indx = create_vector (n);
  temp = create_matrixd (n, n);
  copy (temp, a, n, n);
  
  ludcmp (temp, n, indx, &d);
  for (j = 0; j < n; j++) d *= temp[j][j];
  
  delete [] indx;
  freemat (temp, n, n);
  
  return d;
}

double fast_det (double **a, int n)
{
  double d = 1.0, **temp;
  int j, *indx;
  
  indx = create_vector (n);

  ludcmp (temp, n, indx, &d);
  for (j = 0; j < n; j++) d *= a[j][j];
  
  delete [] indx;
  
  return d;
}

double *create_vectord (int dim)
{
  double *temp;
  
  set_new_handler (out_of_store);
  temp = new double [dim];
  //  assert(temp);
  
  return temp;
}

int *create_vector (int dim)
{
  int *vector;
  
  vector = new int [dim];
  set_new_handler (out_of_store);
  //  assert(vector);
  
  return vector;
}


void copy (double **c, double **a, int rows, int cols)
{
  int i, j;
  for (i = 0; i < rows; i++) {
    for (j = 0; j < cols; j++) c[i][j] = a[i][j];
  }
}    

void copy (int **c, int **a, int rows, int cols)
{
  int i, j;
  for (i = 0; i < rows; i++) {
    for (j = 0; j < cols; j++) c[i][j] = a[i][j];
  }
}

void copy (double **c, int **a, int rows, int cols)
{
  int i, j;
  for (i = 0; i < rows; i++) {
    for (j = 0; j < cols; j++) c[i][j] = a[i][j];
  }
}    

void copy (double *x, double *y, int dim)
{
  int i;
  for (i = 0; i < dim; i++) x[i] = y[i];
}

void copy (int *x, int *y, int dim)
{
  int i;
  for (i = 0; i < dim; i++) x[i] = y[i];
}

void copy (double *x, int *y, int dim)
{
  int i;
  for (i = 0; i < dim; i++) x[i] = y[i];
}


void vecsum (double *vector, double *a, double *b, int dim)
{
  int i;
  
  for (i = 0; i < dim; i++) vector[i] = a[i] + b[i];
  
}

void vecdiff (double *vector, double *a, double *b, int dim)
{
  int i;
  
  for (i = 0; i < dim; i++) vector[i] = a[i] - b[i];
  
}

void vecsclpr (double *vector, double a, double *b, int dim)
{
  int i;
  
  for (i = 0; i < dim; i++) vector[i] = a*b[i];
  
}

double innerprod (double *x, double *y, int dim)
{
  int i;
  double w;
  w = 0.0;
  for (i = 0; i < dim; i++) {
    w += (*(x+i)) * (*(y+i));
  }
  return w;
}


void swap (double **c, int u, int v1, int dim)
{
  int k;
  double temp;
  
  for (k = 0; k < 2*dim; k++) {
    temp = c[u][k];
    c[u][k] = c[v1][k];
    c[v1][k] = temp;
  }
}

void sweep (double **c, int u, int dim)
{  	
  int k, l;
  double temp;
  
  temp = c[u][u];
  for (l = u; l < 2*dim; l++) {
    c[u][l] = c[u][l] / temp;
  }
  
  for (k = 0; k < dim; k++) {
    if (k == u) continue;
    else temp = c[k][u];
    for (l = u; l < 2*dim; l++) {
      c[k][l] = c[k][l] - temp * c[u][l];  		          
    }
  }
  
}


void printvec (double *d, int dim)
{
  int i;
  
  for (i = 0; i < dim; i++) printf ("%lf\n", d[i]);
}

void fprintmatINT (FILE *fout, int **d, int rows, int cols)
{
  int i, j;
  for (i = 0; i < rows; i++) {
    for (j = 0; j < cols; j++) {
      fprintf (fout, "%d ", d[i][j]);
      fflush (fout);
    }
    fprintf (fout, "\n");
    fflush (fout);
  }
  fprintf (fout, "\n");
  fflush (fout);
}

void fprintvec (FILE *fout, double *d, int dim)
{
  int i;
  
  for (i = 0; i < dim; i++) {
    fprintf (fout, "%lf\n", d[i]);
    fflush (fout);
  }    
  fprintf (fout, "\n");
  fflush(fout);
}

void fprintvecINT (FILE *fout, int *d, int dim)
{
  int i;
  
  for (i = 0; i < dim; i++) {
    fprintf (fout, "%d\n", d[i]);
    fflush (fout);
  }    
  fprintf (fout, "\n");
  fflush(fout);
}

void freadmatINT (FILE *fin, int **d, int rows, int cols)
{
  int i, j;
  for (i = 0; i < rows; i++) {
    /*printf ("row[%d] : ", i);*/
    for (j = 0; j < cols; j++) {
      fscanf (fin, "%d", &d[i][j]);
    }
  }
}
 
void symmetrize (double **a, int dim)
{
  int i, j;
  for (i = 0; i < dim; i++) {
    for (j = i + 1; j < dim; j++) a[j][i] = a[i][j];
  }
}    


double sum_components (double *a, int start, int end)
{
  int i;
  double sum = 0.0;
  
  for (i = start; i < end; i++) sum += a[i];
  
  return sum;
}

int sum_componentsINT (int *a, int start, int end)
{
  int i;
  int sum = 0;
  
  for (i = start; i < end; i++) sum += a[i];
  
  return sum;
}


//Matrix functions and Methods

matrix::matrix()
{
}

matrix:: matrix(int m, int n)
{
  nrows = m;
  ncols = n;
  a = create_matrixd (nrows, ncols);
}

matrix:: ~matrix()
{
  //	cout << "destructor called\n";
  if (!a) return;
  freemat (a, nrows, ncols);
}


matrix:: matrix(const matrix &rhs)
{
  //	cout << "copy constructor called\n";
  nrows = rhs.nrows;
  ncols = rhs.ncols;
  determinant = rhs.determinant;
  
  a = create_matrixd (nrows, ncols);
  copy (a, rhs.a, nrows, ncols);
}

void matrix:: freeit (void)
{
  int i;
  if (a == 0) return;
  for (i = 0; i < nrows; i++) {
    delete [] a[i];
    a[i] = 0;
  }
  delete [] a;
  a = 0;
}

void matrix::set_row(const int i, const vector &x)
{
    if (x.length != ncols) {
          cout << "Invalid assignment attempted" << endl;
          (void) getchar();
          exit(0);
    }
    for (int j = 0; j < ncols; j++) a[i][j] = x[j];
}

void matrix::set_col(const int j, const vector &x)
{
    if (x.length != nrows) {
          cout << "Invalid assignment attempted" << endl;
          (void) getchar();
          exit(0);
    }
    for (int i = 0; i < nrows; i++) a[i][j] = x[i];
}

matrix &matrix::operator = (const matrix &rhs)
{
  //	cout <<"=operator called\n";
  copy (a, rhs.a, rhs.nrows, rhs.ncols);
  return *this;
}

double &matrix::operator () (const int i, const int j) const
{
  if ((i >= nrows) || (j >= ncols)) {
    cout << "Invalid matrix element access in (,)" << endl;
    (void) getchar();
    exit(0);
  }
  return this->a[i][j];
}

vector matrix::operator [] (const int i) const
{
  if (i >= nrows) {
    cout << "Invalid matrix row access in []" << endl;
    (void) getchar();
    exit(0);
  }
  int j;
  vector row_vec(ncols);
  
  for (j = 0; j < ncols; j++) row_vec[j] = a[i][j];
  return row_vec;
}

double matrix::compu_trace (void)
{
  int i, dim = nrows;
  
  double sum = 0.0;
  
  if (nrows > ncols) dim = ncols;
  
  for (i = 0; i < dim; i++) sum += a[i][i];
  
  return sum;
}

matrix matrix::transpose (void)
{
  int i, j;
  
  matrix temp (ncols, nrows);
  
  for (i = 0; i < ncols; i++) {
    for (j = 0; j < nrows; j++) temp.a[i][j] = a[j][i];
  }
  
  return temp;
}

matrix matrix::LU ()
{
  int i;
  int *indx, dim = nrows;
  double d = 1.0;
  
  matrix temp (dim, dim);
  indx = create_vector (dim);
  
  copy (temp.a, a, dim, dim);
  
  ludcmp (temp.a, dim, indx, &d);
  
  for (i = 0; i < dim; i++) d *= temp.a[i][i];
  
  determinant = d;
  
  delete [] indx;
  
  return temp;
}

matrix matrix::inv ()
{
  matrix temp (nrows, ncols);
  copy (temp.a, a, nrows, ncols);
  inverse (temp.a, nrows);
  //	determinant = det (a, nrows);
  return temp;
}

matrix matrix::chol ()
{
  int  i, j, k, u = nrows;
  double **c,  *p, temp;
  matrix l (nrows, ncols);
  
  c = create_matrixd (u, u);
  p = create_vectord (u);
  
  copy (c, a, u, u);
  symmetrize (c, u);
  
  for (i = 0; i < u; i++) {
    for (j = i; j < u; j++) {
      temp = c[i][j];
      for (k = i; k > 0; k--) {
	temp = temp - c[j][k-1] * c[i][k-1];
      }
      if (i == j) {
	if (temp <= 0.0) {
	  printf ("Matrix not p.d. in cholesky\n");
	  printf ("%lf\n", temp);
	  printf ("%d\n", i);
	  (void) getchar ();
	  exit (0);
	}
	p[i] = sqrt (temp);
      }
      else c[j][i] = temp / p[i] ;
    }
  }
  
  for (i = 0; i < u; i++) {
    for (j = 0; j < u; j++) {
      if (i == j) l.a[i][j] = p[i];
      else if (i > j) l.a[i][j] = c[i][j];
      else if (i < j) l.a[i][j] = 0;
    }
  }
  
  freemat (c, u, u);
  delete [] p;
  
  return l;
}

matrix I(int n)
{
  matrix out(n,n);
  for(int i = 0; i < n; i++) {
    out(i,i) = 1.0;
    for (int j = i+1; j < n; j++) {
      out(i,j) = 0.0; out(j,i) = 0.0;
         }
  }
  return out;
}

// C++ analogs of C functions in c:\my programs\general\matrix2.c

void matsum (matrix &C, const matrix &A, const matrix &B)
{
  int i, j;
  
  for (i = 0; i < A.nrows; i++) {
    for (j = 0; j < A.ncols; j++) C.a[i][j] = A.a[i][j] + B.a[i][j];
  }
}

void matdiff (matrix &C, const matrix &A, const matrix &B)
{
  int i, j;
  
	for (i = 0; i < A.nrows; i++) {
	  for (j = 0; j < A.ncols; j++) C.a[i][j] = A.a[i][j] - B.a[i][j];
	}
}

void matsclpr (matrix &B, double x, const matrix &A)
{
  int i, j;
  
  for (i = 0; i < A.nrows; i++) {
    for (j = 0; j < A.ncols; j++) {
      B.a[i][j] = x * A.a[i][j];
   		 }
  }
}

void matpr (matrix &C, const matrix &A, const matrix &B)
{
  int i, j, k;
  double sum;
  
  for (i = 0; i < A.nrows ; i++) {
    for (j = 0; j < B.ncols; j++) {
      sum = 0 ;
      for (k = 0; k < A.ncols; k++) {
	sum += A.a[i][k] * B.a[k][j];
      }
      C.a[i][j]  = sum;
    }
  }
}

void transpose (matrix &C, const matrix &A)
{
  int  i, j;
  
  for (i = 0; i < A.nrows; i++) {
    for ( j = 0; j < A.ncols; j++) {
      C.a[j][i] = A.a[i][j];
    }
  }
}

matrix transpose (const matrix &A)
{
  int  i, j;
  matrix C(A.ncols, A.nrows);
  
  for (i = 0; i < A.nrows; i++) {
    for ( j = 0; j < A.ncols; j++) {
      C.a[j][i] = A.a[i][j];
    }
  }
  return C;
}

void matvecpr (double *vector, const matrix &A, double *x)
{
  int i, j;
  double sum;
  
  for (i = 0; i < A.nrows; i++) {
    sum = 0;
    for (j = 0; j < A.ncols; j++) {
      sum += A.a[i][j] * x[j];
    }
    vector[i] = sum;
  }
}

double trace (const matrix &A)
{
  int i;
  double sum;
  sum = 0;
  for (i = 0; i < A.nrows; i++) sum += A.a[i][i];
  return sum;
}

void LU (matrix &lhs, matrix &rhs)
{
  int i;
  int *indx, dim = rhs.nrows;
  double d = 1.0;
  
  matrix temp (dim, dim);
  indx = create_vector (dim);
  
  copy (temp.a, rhs.a, dim, dim);
  
  ludcmp (temp.a, dim, indx, &d);
  
  for (i = 0; i < dim; i++) d *= temp.a[i][i];
  
  rhs.determinant = d;
  
  lhs = temp;
  
  delete [] indx;
  
  temp.freeit();
}

void fast_LU (matrix &arg)
{
  int i;
  int *indx, dim = arg.nrows;
  double d = 1.0;
  
  indx = create_vector (dim);
  
  ludcmp (arg.a, dim, indx, &d);
  
  for (i = 0; i < dim; i++) d *= arg.a[i][i];
  
  arg.determinant = d;

  delete [] indx;
}

matrix LU (const matrix &rhs)
{
  int i;
  int *indx, dim = rhs.nrows;
  double d = 1.0;
  
  matrix temp (dim, dim);
  indx = create_vector (dim);
  
  copy (temp.a, rhs.a, dim, dim);
  
  ludcmp (temp.a, dim, indx, &d);
  
  delete [] indx;
  
  return temp;
}

void solve (double *x, const matrix &A, double *b)
{
  int *indx, n = A.nrows;
  double d, **temp;
  
  indx = create_vector (n);
  temp = create_matrixd (n, n);
  copy (temp, A.a, n, n);
  copy (x, b, n);
  
  ludcmp (temp, n, indx, &d);
  lubksb (temp, n, indx, x);
  
  delete [] indx;
  freemat (temp, n, n);
}

void solve (const matrix &A, double *b)
{
  int *indx, n = A.nrows;
  double d, **temp;
  
  indx = create_vector (n);
  temp = create_matrixd (n, n);
  copy (temp, A.a, n, n);
  
  ludcmp (temp, n, indx, &d);
  lubksb (temp, n, indx, b);
  
  delete [] indx;
  freemat (temp, n, n);
}

void solve (matrix &X, const matrix &A, const matrix &B)
{
  int n = A.nrows, m = B.ncols;
  double **temp;
  temp = create_matrixd(n,n);
  copy (temp, A.a, n, n);
  X = B;
  gaussj(temp, n, X.a, m);
  freemat(temp, n, n);
}

void fast_solve (matrix &A, matrix &B)
{
  int n = A.nrows, m = B.ncols;
  gaussj(A.a, n, B.a, m);
}

void fast_solve (matrix &A, double *b)
{
  int *indx, n = A.nrows;
  double d;
  
  indx = create_vector (n);
  
  ludcmp (A.a, n, indx, &d);
  lubksb (A.a, n, indx, b);
  
  delete [] indx;
}

void inverse (matrix &Ainv, const matrix &A)
{
  double d, *col, **temp;
  int i, j, *indx, n = A.nrows;
  
  indx = create_vector (n);
  col = create_vectord (n);
  
  temp = create_matrixd (n, n);
  copy (temp, A.a, n, n);
  
  ludcmp (temp, n, indx, &d);
  
  for (j = 0; j < n; j++) {
    for (i = 0; i < n; i++) col[i] = 0.0;
    col[j] = 1.0;
    lubksb (temp, n, indx, col);
    for (i = 0; i < n; i++) Ainv.a[i][j] = col[i];
  }
  
  freemat (temp, n, n);
  delete [] indx;
  delete [] col;
}

void fast_inverse (matrix &Ainv)
{
  double d, *col, **temp;
  int i, j, *indx, n = Ainv.nrows;
  
  indx = create_vector (n);
  col = create_vectord (n);
  temp = create_matrixd (n,n);
  
  ludcmp (Ainv.a, n, indx, &d);
  copy (temp, Ainv.a, n, n);
  
  for (j = 0; j < n; j++) {
    for (i = 0; i < n; i++) col[i] = 0.0;
    col[j] = 1.0;
    lubksb (temp, n, indx, col);
    for (i = 0; i < n; i++) Ainv.a[i][j] = col[i];
  }
  
  freemat (temp, n, n);
  delete [] indx;
  delete [] col;
}

matrix inverse (const matrix &A)
{
  double d, *col;
  int i, j, *indx, n = A.nrows;
  
  matrix temp (n, n), Ainv (n, n);
  
  indx = create_vector (n);
  col = create_vectord (n);
  
  copy (temp.a, A.a, n, n);
  
  ludcmp (temp.a, n, indx, &d);
  
  for (j = 0; j < n; j++) {
    for (i = 0; i < n; i++) col[i] = 0.0;
    col[j] = 1.0;
    lubksb (temp.a, n, indx, col);
    for (i = 0; i < n; i++) Ainv.a[i][j] = col[i];
  }
  delete [] indx;
  delete [] col;
  return Ainv;
}

double det (const matrix &A)
{
  double d = 1.0, **temp;
  int j, *indx, n = A.nrows;
  
  indx = create_vector (n);
  temp = create_matrixd (n, n);
  copy (temp, A.a, n, n);
  
  ludcmp (temp, n, indx, &d);
  for (j = 0; j < n; j++) d *= temp[j][j];
  if (fabs(d) < 1.0e-10) d = 0.0;
  
  delete [] indx;
  freemat (temp, n, n);
  
  return d;
}

double fast_det (matrix &A)
{
  double d = 1.0;
  int j, *indx, n = A.nrows;
  
  indx = create_vector (n);
  
  ludcmp (A.a, n, indx, &d);
  for (j = 0; j < n; j++) d *= A.a[j][j];
  if (fabs(d) < 1.0e-10) d = 0.0;
  
  delete [] indx;
  
  return d;
}

double log_det (const matrix &A)
{
  double d = 1.0, **temp;
  int j, *indx, n = A.nrows;
  
  indx = create_vector (n);
  temp = create_matrixd (n, n);
  copy (temp, A.a, n, n);
  
  ludcmp (temp, n, indx, &d);
  d = 0.0;
  for (j = 0; j < n; j++) d += log(fabs(temp[j][j]));
  if (fabs(d) < 1.0e-10) d = 0.0;
  delete [] indx;
  freemat (temp, n, n);
  
  return d;
}

double fast_log_det (matrix &A)
{
  double d = 1.0;
  int j, *indx, n = A.nrows;
  
  indx = create_vector (n);
  
  ludcmp (A.a, n, indx, &d);
  d = 0.0;
  for (j = 0; j < n; j++) d += log(fabs(A.a[j][j]));
  if (fabs(d) < 1.0e-10) d = 0.0;
  delete [] indx;
  
  return d;
}

void matinv (matrix &Ainv, const matrix &A)
{
  int i, j, l, w1, dim = A.nrows;
  double **c;
  c = create_matrixd (dim, 2 * dim);
  for (i = 0; i < dim; i++) {
    for (j = 0; j < dim; j++) c[i][j] = A.a[i][j];
  }
  
  for (i = 0; i < dim; i++) {
    w1 = dim + i;
    for (j = dim; j < 2*dim; j++) {
      if (j == w1) c[i][j] = 1;
      else c[i][j] =0;
    }
  }
  
  for (j = 0; j < 2*dim; j++) {
    for (i = j; i < dim; i++) {
      if (c[i][j] != 0) {
	swap (c, i, j, dim);
	sweep (c, j, dim);
      }
      else continue;
    }
  }
  
  for ( i = 0; i < dim; i++) {
    for ( j = 0; j < dim; j++) {
      l = dim + j;
      Ainv.a[i][j] = c[i][l];
    }
  }
  freemat (c, dim, dim);
}

void chol (matrix &l, const matrix &A)
{
  int  i, j, k, u = A.nrows;
  double **c,  *p, temp;
  
  c = create_matrixd (u, u);
  p = create_vectord (u);
  
  copy (c, A.a, u, u);
  symmetrize (c, u);
  
  for (i = 0; i < u; i++) {
    for (j = i; j < u; j++) {
      temp = c[i][j];
      for (k = i; k > 0; k--) {
	temp = temp - c[j][k-1] * c[i][k-1];
      }
      if (i == j) {
	if (temp <= 0.0) {
	  printf ("Matrix not p.d. in cholesky\n");
	  printf ("%lf\n", temp);
	  printf ("%d\n", i);
	  (void) getchar();
	  exit (0);
	}
	p[i] = sqrt (temp);
      }
      else c[j][i] = temp / p[i] ;
    }
  }
  
  for (i = 0; i < u; i++) {
    for (j = 0; j < u; j++) {
      if (i == j) l.a[i][j] = p[i];
      else if (i > j) l.a[i][j] = c[i][j];
      else if (i < j) l.a[i][j] = 0;
    }
  }
  
  freemat (c, u, u);
  delete [] p;
}

void fast_chol (matrix &l, matrix &A)
{
  int  i, j, k, u = A.nrows;
  double *p, temp;
  
  p = create_vectord (u);
  
  symmetrize (A.a, u);
  
  for (i = 0; i < u; i++) {
    for (j = i; j < u; j++) {
      temp = A.a[i][j];
      for (k = i; k > 0; k--) {
	temp = temp - A.a[j][k-1] * A.a[i][k-1];
      }
      if (i == j) {
	if (temp <= 0.0) {
	  printf ("Matrix not p.d. in cholesky\n");
	  printf ("%lf\n", temp);
	  printf ("%d\n", i);
	  (void) getchar();
	  exit (0);
	}
	p[i] = sqrt (temp);
      }
      else A.a[j][i] = temp / p[i] ;
    }
  }
  
  for (i = 0; i < u; i++) {
    for (j = 0; j < u; j++) {
      if (i == j) l.a[i][j] = p[i];
      else if (i > j) l.a[i][j] = A.a[i][j];
      else if (i < j) l.a[i][j] = 0;
    }
  }
  delete [] p;
}

matrix chol (const matrix &A)
{
  int  i, j, k, u = A.nrows;
  double **c,  *p, temp;
  matrix l(u,u);
  
  c = create_matrixd (u, u);
  p = create_vectord (u);
  
  copy (c, A.a, u, u);
  symmetrize (c, u);
  
  for (i = 0; i < u; i++) {
    for (j = i; j < u; j++) {
      temp = c[i][j];
      for (k = i; k > 0; k--) {
	temp = temp - c[j][k-1] * c[i][k-1];
      }
      if (i == j) {
	if (temp <= 0.0) {
	  printf ("Matrix not p.d. in cholesky\n");
	  printf ("%lf\n", temp);
	  printf ("%d\n", i);
	  (void) getchar();
	  exit (0);
	}
	p[i] = sqrt (temp);
      }
      else c[j][i] = temp / p[i] ;
    }
  }
  
  for (i = 0; i < u; i++) {
    for (j = 0; j < u; j++) {
      if (i == j) l.a[i][j] = p[i];
      else if (i > j) l.a[i][j] = c[i][j];
      else if (i < j) l.a[i][j] = 0;
    }
  }
  
  freemat (c, u, u);
  delete [] p;
  return l;
}

void printmat (const matrix &A)
{
  int i, j;
  for (i = 0; i < A.nrows; i++) {
    for (j = 0; j < A.ncols; j++) {
      cout << A.a[i][j] << " ";
    }
    cout << "\n";
  }
  cout << "\n";
}

void fprintmat (FILE *fout, const matrix &A)
{
  int i, j;
  for (i = 0; i < A.nrows; i++) {
    for (j = 0; j < A.ncols; j++) {
      fprintf (fout, "%lf ", A.a[i][j]);
      fflush (fout);
    }
    fprintf (fout, "\n");
    fflush (fout);
  }
  fprintf (fout, "\n");
  fflush (fout);
}

void fprintmat (const char *filename, const matrix &A)
{
  int i, j;
  
  ofstream fout(filename);
  
  for (i = 0; i < A.nrows; i++) {
    for (j = 0; j < A.ncols; j++) {
      fout << A.a[i][j] <<" ";
      fout << flush;
    }
    fout << endl;
    fout << flush;
  }
  fout << endl;
  fout << flush;
  fout.close();
}

void readmat (matrix &A)
{
  int i, j;
  for (i = 0; i < A.nrows; i++)
    {
      cout << "row["<<i<<"] : ";
      for (j = 0; j < A.ncols; j++)
	cin >> A(i,j);
    }
}

void freadmat (FILE *fin, matrix &A)
{
  int i, j;
  for (i = 0; i < A.nrows; i++) {
    /*printf ("row[%d] : ", i);*/
    for (j = 0; j <A.ncols; j++) {
      fscanf (fin, "%lf", &A(i,j));
    }
  }
}

void freadmat (const char *filename, matrix &A)
{
  int i, j;
  ifstream fin(filename);
  
  for (i = 0; i < A.nrows; i++) {
    for (j = 0; j <A.ncols; j++) fin >> A(i,j);
  }
}

double ellipse (double *x, const matrix &A, double *y)
{
  double *temp, quad;
  
  temp = create_vectord (A.nrows);
  matvecpr (temp, A, y);
  quad = innerprod (x, temp, A.nrows);
  
  delete [] temp;
  return quad;
}

void sub_matrix (matrix &C, const matrix &A, int i1, int i2, int j1, int j2)
{
  int k, l;
  // int rows, cols;
  //  	rows = i2 - i1 +1;
  //  	cols = j2 - j1 +1;
  
  for (k = i1-1; k < i2; k++) {
    for (l = j1-1; l < j2; l++) {
      C.a[k-i1+1][l-j1+1] = A.a[k][l];
    }
  }
}

void BlockDiagonal (matrix &Out, const matrix &A, const matrix &B)
{
  int i, j;
  
  for (i = 0; i < A.nrows; i++) {
    for (j = 0; j < A.ncols; j++) Out(i,j) = A(i,j);
    for (j = A.ncols; j < Out.ncols; j++) Out(i,j) = 0.0;
  }
  
  for (i = A.nrows; i < Out.nrows; i++) {
    for (j = 0; j < A.ncols; j++) Out(i,j) = 0.0;
    for (j = A.ncols; j < Out.ncols; j++) Out(i,j) = B(i-A.nrows,j-A.ncols);
  }
  
}

void BlockMatrix (matrix &Out, const matrix &A11, const matrix &A12,
                               const matrix &A21, const matrix &A22)
{
  int i, j;
  
  for (i = 0; i < A11.nrows; i++) {
    for (j = 0; j < A11.ncols; j++) Out(i,j) = A11(i,j);
    for (j = A11.ncols; j < Out.ncols; j++) Out(i,j) = A12(i,j-A11.ncols);
  }
  
  for (i = A11.nrows; i < Out.nrows; i++) {
    for (j = 0; j < A11.ncols; j++) Out(i,j) = A21(i-A11.nrows,j);
    for (j = A11.ncols; j < Out.ncols; j++) Out(i,j) = A22(i-A11.nrows,j-A11.ncols);
  }
  
}

void symmetrize (matrix &A)
{
  int i, j, dim = A.nrows;
  for (i = 0; i < dim; i++) {
    for (j = i + 1; j < dim; j++) A.a[j][i] = A.a[i][j];
  }
}

void perturbmat (matrix &A, double eps)
{
  int i;
  
  for (i = 0; i < A.nrows; i++) A.a[i][i] += eps;
}

void vectomat (matrix &A, double *vector)
{
  int i, j;
  
  for (i = 0; i < A.nrows; i++) {
    for (j = 0; j < A.ncols; j++) A.a[i][j] = vector[i*A.nrows+j];
  }
  
}

void kroneckerprod(matrix &C, const matrix &A, const matrix &B)
{
  int i, j, k, l;
  
  for (k = 0; k < A.nrows; k++) {
    for (l = 0; l < A.ncols; l++) {
      for (i = 0; i < B.nrows; i++) {
	for (j = 0; j < B.ncols; j++) {
	  C(k*B.nrows+i,l*B.ncols+j) = A(k,l) * B(i,j);
	}
      }
    }
  }
}

void tred2 (vector &d, vector &e, matrix &V)
{
  
  //  This is derived from the Algol procedures tred2 by
  //  Bowdler, Martin, Reinsch, and Wilkinson, Handbook for
  //  Auto. Comp., Vol.ii-Linear Algebra, and the corresponding
  //  Fortran subroutine in EISPACK.
  
  int n = V.ncols;
  
  for (int j = 0; j < n; j++) {
    d.a[j] = V.a[n-1][j];
  }
  
  // Householder reduction to tridiagonal form.
  
  for (int i = n-1; i > 0; i--) {
    
    // Scale to avoid under/overflow.
    
    double scale = 0.0;
    double h = 0.0;
    for (int k = 0; k < i; k++) {
      scale = scale + fabs(d.a[k]);
    }
    if (scale == 0.0) {
      e.a[i] = d.a[i-1];
      for (int j = 0; j < i; j++) {
	d.a[j] = V.a[i-1][j];
	V.a[i][j] = 0.0;
	V.a[j][i] = 0.0;
            }
    } else {
      
      // Generate Householder vector.
      
      for (int k = 0; k < i; k++) {
	d.a[k] /= scale;
	h += d.a[k] * d.a[k];
      }
      double f = d.a[i-1];
      double g = sqrt(h);
      if (f > 0) {
	g = -g;
      }
      e.a[i] = scale * g;
      h = h - f * g;
      d.a[i-1] = f - g;
      for (int j = 0; j < i; j++) {
	e.a[j] = 0.0;
      }
      
      // Apply similarity transformation to remaining columns.
      
      for (int j = 0; j < i; j++) {
	f = d.a[j];
	V.a[j][i] = f;
	g = e.a[j] + V.a[j][j] * f;
	for (int k = j+1; k <= i-1; k++) {
	  g += V.a[k][j] * d.a[k];
	  e.a[k] += V.a[k][j] * f;
	}
	e.a[j] = g;
      }
      f = 0.0;
      for (int j = 0; j < i; j++) {
               e.a[j] /= h;
               f += e.a[j] * d.a[j];
      }
      double hh = f / (h + h);
      for (int j = 0; j < i; j++) {
	e.a[j] -= hh * d.a[j];
      }
      for (int j = 0; j < i; j++) {
	f = d.a[j];
	g = e.a[j];
	for (int k = j; k <= i-1; k++) {
	  V.a[k][j] -= (f * e.a[k] + g * d.a[k]);
	}
	d.a[j] = V.a[i-1][j];
	V.a[i][j] = 0.0;
      }
    }
    d.a[i] = h;
  }
  
  // Accumulate transformations.
  
  for (int i = 0; i < n-1; i++) {
    V.a[n-1][i] = V.a[i][i];
    V.a[i][i] = 1.0;
    double h = d.a[i+1];
    if (h != 0.0) {
      for (int k = 0; k <= i; k++) {
	d.a[k] = V.a[k][i+1] / h;
      }
      for (int j = 0; j <= i; j++) {
	double g = 0.0;
	for (int k = 0; k <= i; k++) {
	  g += V.a[k][i+1] * V.a[k][j];
	}
	for (int k = 0; k <= i; k++) {
	  V.a[k][j] -= g * d.a[k];
	}
      }
    }
    for (int k = 0; k <= i; k++) {
      V.a[k][i+1] = 0.0;
    }
  }
  for (int j = 0; j < n; j++) {
    d.a[j] = V.a[n-1][j];
    V.a[n-1][j] = 0.0;
  }
  V.a[n-1][n-1] = 1.0;
  e.a[0] = 0.0;
}

// Symmetric tridiagonal QL algorithm.

void tql2 (vector &d, vector &e, matrix &V)
{
  
  //  This is derived from the Algol procedures tql2, by
  //  Bowdler, Martin, Reinsch, and Wilkinson, Handbook for
  //  Auto. Comp., Vol.ii-Linear Algebra, and the corresponding
  //  Fortran subroutine in EISPACK.
  
  int n = V.ncols;
  
  for (int i = 1; i < n; i++) {
    e.a[i-1] = e.a[i];
  }
  e.a[n-1] = 0.0;
  
  double f = 0.0;
  double tst1 = 0.0;
  double eps = pow(2.0,-52.0);
  for (int l = 0; l < n; l++) {
    
    // Find small subdiagonal element
    
    tst1 = max(tst1,fabs(d.a[l]) + fabs(e.a[l]));
    int m = l;
    while (m < n) {
      if (fabs(e.a[m]) <= eps*tst1) {
	break;
      }
      m++;
    }
    
    // If m == l, d[l] is an eigenvalue,
    // otherwise, iterate.
    
    if (m > l) {
      int iter = 0;
      do {
	iter = iter + 1;  // (Could check iteration count here.)
	
	// Compute implicit shift
	
	double g = d.a[l];
	double p = (d.a[l+1] - g) / (2.0 * e.a[l]);
	double r = hypot(p,1.0);
	if (p < 0) {
	  r = -r;
	}
	d.a[l] = e.a[l] / (p + r);
	d.a[l+1] = e.a[l] * (p + r);
	double dl1 = d.a[l+1];
	double h = g - d.a[l];
	for (int i = l+2; i < n; i++) {
	  d.a[i] -= h;
	}
	f = f + h;
	
	// Implicit QL transformation.
	
	p = d.a[m];
	double c = 1.0;
	double c2 = c;
	double c3 = c;
	double el1 = e.a[l+1];
	double s = 0.0;
	double s2 = 0.0;
	for (int i = m-1; i >= l; i--) {
	  c3 = c2;
	  c2 = c;
	  s2 = s;
	  g = c * e.a[i];
	  h = c * p;
	  r = hypot(p,e.a[i]);
	  e.a[i+1] = s * r;
	  s = e.a[i] / r;
	  c = p / r;
	  p = c * d.a[i] - s * g;
	  d.a[i+1] = h + s * (c * g + s * d.a[i]);
	  
	  // Accumulate transformation.
	  
	  for (int k = 0; k < n; k++) {
	    h = V.a[k][i+1];
	    V.a[k][i+1] = s * V.a[k][i] + c * h;
	    V.a[k][i] = c * V.a[k][i] - s * h;
	  }
	}
	p = -s * s2 * c3 * el1 * e.a[l] / dl1;
	e.a[l] = s * p;
	d.a[l] = c * p;
	
	// Check for convergence.
	
      } while (fabs(e.a[l]) > eps*tst1);
    }
    d.a[l] = d.a[l] + f;
    e.a[l] = 0.0;
  }
  
  // Sort eigenvalues and corresponding vectors.
  
  for (int i = 0; i < n-1; i++) {
    int k = i;
    double p = d.a[i];
    for (int j = i+1; j < n; j++) {
      if (d.a[j] < p) {
	k = j;
	p = d.a[j];
      }
    }
    if (k != i) {
      d.a[k] = d.a[i];
      d.a[i] = p;
      for (int j = 0; j < n; j++) {
	p = V.a[j][i];
	V.a[j][i] = V.a[j][k];
	V.a[j][k] = p;
      }
    }
  }
}

   // Nonsymmetric reduction to Hessenberg form.

void orthes (vector &d, vector &e, vector &ort, matrix &V, matrix &H)
{
  
  //  This is derived from the Algol procedures orthes and ortran,
  //  by Martin and Wilkinson, Handbook for Auto. Comp.,
  //  Vol.ii-Linear Algebra, and the corresponding
  //  Fortran subroutines in EISPACK.
  
  int n = H.ncols;
  
  int low = 0;
  int high = n-1;
  
  for (int m = low+1; m <= high-1; m++) {
    
    // Scale column.
    
    double scale = 0.0;
    for (int i = m; i <= high; i++) {
      scale = scale + fabs(H.a[i][m-1]);
    }
    if (scale != 0.0) {
      
      // Compute Householder transformation.
      
      double h = 0.0;
      for (int i = high; i >= m; i--) {
               ort.a[i] = H.a[i][m-1]/scale;
               h += ort.a[i] * ort.a[i];
      }
      double g = sqrt(h);
      if (ort.a[m] > 0) {
	g = -g;
      }
      h = h - ort.a[m] * g;
      ort.a[m] = ort.a[m] - g;
      
      // Apply Householder similarity transformation
      // H = (I-u*u'/h)*H*(I-u*u')/h)
      
      for (int j = m; j < n; j++) {
	double f = 0.0;
	for (int i = high; i >= m; i--) {
	  f += ort.a[i]*H.a[i][j];
	}
	f = f/h;
	for (int i = m; i <= high; i++) {
	  H.a[i][j] -= f*ort.a[i];
	}
      }
      
      for (int i = 0; i <= high; i++) {
	double f = 0.0;
	for (int j = high; j >= m; j--) {
	  f += ort.a[j]*H.a[i][j];
	}
	f = f/h;
	for (int j = m; j <= high; j++) {
	  H.a[i][j] -= f*ort.a[j];
	}
      }
      ort.a[m] = scale*ort.a[m];
      H.a[m][m-1] = scale*g;
    }
  }
  
  // Accumulate transformations (Algol's ortran).
  
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      V.a[i][j] = (i == j ? 1.0 : 0.0);
    }
  }
  
  for (int m = high-1; m >= low+1; m--) {
    if (H.a[m][m-1] != 0.0) {
      for (int i = m+1; i <= high; i++) {
	ort.a[i] = H.a[i][m-1];
      }
      for (int j = m; j <= high; j++) {
	double g = 0.0;
	for (int i = m; i <= high; i++) {
	  g += ort.a[i] * V.a[i][j];
	}
	// Double division avoids possible underflow
               g = (g / ort.a[m]) / H.a[m][m-1];
               for (int i = m; i <= high; i++) {
		 V.a[i][j] += g * ort.a[i];
               }
            }
    }
  }
}


// Complex scalar division.

static double cdivr, cdivi;
void cdiv(double xr, double xi, double yr, double yi)
{
  double r,d;
  if (fabs(yr) > fabs(yi)) {
    r = yi/yr;
    d = yr + r*yi;
    cdivr = (xr + r*xi)/d;
    cdivi = (xi - r*xr)/d;
  } else {
    r = yr/yi;
    d = yi + r*yr;
    cdivr = (r*xr + xi)/d;
    cdivi = (r*xi - xr)/d;
  }
}


// Nonsymmetric reduction from Hessenberg to real Schur form.

void hqr2 (vector &d, vector &e, matrix &V, matrix &H)
{

  //  This is derived from the Algol procedure hqr2,
  //  by Martin and Wilkinson, Handbook for Auto. Comp.,
  //  Vol.ii-Linear Algebra, and the corresponding
  //  Fortran subroutine in EISPACK.
  
  // Initialize
  int nn = V.ncols;
  int n = nn-1;
  int low = 0;
  int high = nn-1;
  double eps = pow(2.0,-52.0);
  double exshift = 0.0;
  double p=0,q=0,r=0,s=0,z=0,t,w,x,y;
  
  // Store roots isolated by balanc and compute matrix norm
  
  double norm = 0.0;
  for (int i = 0; i < nn; i++) {
    if (i < low | i > high) {
      d.a[i] = H.a[i][i];
      e.a[i] = 0.0;
    }
    for (int j = max(i-1,0); j < nn; j++) {
      norm = norm + fabs(H.a[i][j]);
    }
  }
  
  // Outer loop over eigenvalue index
  
  int iter = 0;
  while (n >= low) {
    
    // Look for single small sub-diagonal element
    
    int l = n;
    while (l > low) {
      s = fabs(H.a[l-1][l-1]) + fabs(H.a[l][l]);
      if (s == 0.0) {
	s = norm;
      }
      if (fabs(H.a[l][l-1]) < eps * s) {
	break;
      }
      l--;
    }

    // Check for convergence
    // One root found
    
    if (l == n) {
      H.a[n][n] = H.a[n][n] + exshift;
      d.a[n] = H.a[n][n];
      e.a[n] = 0.0;
      n--;
      iter = 0;

         // Two roots found
      
    } else if (l == n-1) {
      w = H.a[n][n-1] * H.a[n-1][n];
      p = (H.a[n-1][n-1] - H.a[n][n]) / 2.0;
      q = p * p + w;
      z = sqrt(fabs(q));
      H.a[n][n] = H.a[n][n] + exshift;
      H.a[n-1][n-1] = H.a[n-1][n-1] + exshift;
      x = H.a[n][n];
      
      // Real pair
      
      if (q >= 0) {
	if (p >= 0) {
	  z = p + z;
	} else {
	  z = p - z;
	}
	d.a[n-1] = x + z;
	d.a[n] = d.a[n-1];
	if (z != 0.0) {
	  d.a[n] = x - w / z;
	}
	e.a[n-1] = 0.0;
	e.a[n] = 0.0;
	x = H.a[n][n-1];
	s = fabs(x) + fabs(z);
	p = x / s;
	q = z / s;
	r = sqrt(p * p+q * q);
	p = p / r;
	q = q / r;
	
	// Row modification
	
	for (int j = n-1; j < nn; j++) {
	  z = H.a[n-1][j];
	  H.a[n-1][j] = q * z + p * H.a[n][j];
	  H.a[n][j] = q * H.a[n][j] - p * z;
	}
	
	// Column modification
	
	for (int i = 0; i <= n; i++) {
	  z = H.a[i][n-1];
	  H.a[i][n-1] = q * z + p * H.a[i][n];
	  H.a[i][n] = q * H.a[i][n] - p * z;
	}
	
	// Accumulate transformations
	
	for (int i = low; i <= high; i++) {
	  z = V.a[i][n-1];
	  V.a[i][n-1] = q * z + p * V.a[i][n];
	  V.a[i][n] = q * V.a[i][n] - p * z;
	}
	
	// Complex pair
	
      } else {
	d.a[n-1] = x + p;
	d.a[n] = x + p;
	e.a[n-1] = z;
	e.a[n] = -z;
      }
      n = n - 2;
      iter = 0;
      
      // No convergence yet
      
    } else {
      
      // Form shift
      
      x = H.a[n][n];
      y = 0.0;
      w = 0.0;
      if (l < n) {
	y = H.a[n-1][n-1];
	w = H.a[n][n-1] * H.a[n-1][n];
      }
      
      // Wilkinson's original ad hoc shift
      
      if (iter == 10) {
	exshift += x;
	for (int i = low; i <= n; i++) {
	  H.a[i][i] -= x;
	}
	s = fabs(H.a[n][n-1]) + fabs(H.a[n-1][n-2]);
	x = y = 0.75 * s;
	w = -0.4375 * s * s;
      }
      
      // MATLAB's new ad hoc shift
      
      if (iter == 30) {
	s = (y - x) / 2.0;
	s = s * s + w;
	if (s > 0) {
	  s = sqrt(s);
	  if (y < x) {
	    s = -s;
	  }
	  s = x - w / ((y - x) / 2.0 + s);
	  for (int i = low; i <= n; i++) {
	    H.a[i][i] -= s;
	  }
	  exshift += s;
	  x = y = w = 0.964;
	}
      }
      
      iter = iter + 1;   // (Could check iteration count here.)
      
      // Look for two consecutive small sub-diagonal elements
      
      int m = n-2;
      while (m >= l) {
	z = H.a[m][m];
	r = x - z;
	s = y - z;
	p = (r * s - w) / H.a[m+1][m] + H.a[m][m+1];
	q = H.a[m+1][m+1] - z - r - s;
	r = H.a[m+2][m+1];
	s = fabs(p) + fabs(q) + fabs(r);
	p = p / s;
	q = q / s;
	r = r / s;
	if (m == l) {
	  break;
	}
	if (fabs(H.a[m][m-1]) * (fabs(q) + fabs(r)) <
	    eps * (fabs(p) * (fabs(H.a[m-1][m-1]) + fabs(z) +
			      fabs(H.a[m+1][m+1])))) {
	  break;
	}
	m--;
      }
      
      for (int i = m+2; i <= n; i++) {
	H.a[i][i-2] = 0.0;
	if (i > m+2) {
	  H.a[i][i-3] = 0.0;
	}
      }
      
      // Double QR step involving rows l:n and columns m:n
      
      for (int k = m; k <= n-1; k++) {
	bool notlast = (k != n-1);
	if (k != m) {
	  p = H.a[k][k-1];
	  q = H.a[k+1][k-1];
	  r = (notlast ? H.a[k+2][k-1] : 0.0);
	  x = fabs(p) + fabs(q) + fabs(r);
	  if (x != 0.0) {
	    p = p / x;
	    q = q / x;
	    r = r / x;
	  }
	}
	if (x == 0.0) {
	  break;
	}
	s = sqrt(p * p + q * q + r * r);
	if (p < 0) {
	  s = -s;
	}
	if (s != 0) {
	  if (k != m) {
	    H.a[k][k-1] = -s * x;
	  } else if (l != m) {
	    H.a[k][k-1] = -H.a[k][k-1];
	  }
	  p = p + s;
	  x = p / s;
	  y = q / s;
	  z = r / s;
	  q = q / p;
	  r = r / p;
	  
	  // Row modification
	  
	  for (int j = k; j < nn; j++) {
	    p = H.a[k][j] + q * H.a[k+1][j];
	    if (notlast) {
	      p = p + r * H.a[k+2][j];
	      H.a[k+2][j] = H.a[k+2][j] - p * z;
	    }
	    H.a[k][j] = H.a[k][j] - p * x;
	    H.a[k+1][j] = H.a[k+1][j] - p * y;
	  }
	  
	  // Column modification
	  
	  for (int i = 0; i <= min(n,k+3); i++) {
	    p = x * H.a[i][k] + y * H.a[i][k+1];
	    if (notlast) {
	      p = p + z * H.a[i][k+2];
	      H.a[i][k+2] = H.a[i][k+2] - p * r;
	    }
	    H.a[i][k] = H.a[i][k] - p;
	    H.a[i][k+1] = H.a[i][k+1] - p * q;
	  }
	  
	  // Accumulate transformations
	  
	  for (int i = low; i <= high; i++) {
	    p = x * V.a[i][k] + y * V.a[i][k+1];
	    if (notlast) {
	      p = p + z * V.a[i][k+2];
	      V.a[i][k+2] = V.a[i][k+2] - p * r;
	    }
	    V.a[i][k] = V.a[i][k] - p;
	    V.a[i][k+1] = V.a[i][k+1] - p * q;
	  }
	}  // (s != 0)
      }  // k loop
    }  // check convergence
  }  // while (n >= low)
  
  // Backsubstitute to find vectors of upper triangular form
  
  if (norm == 0.0) {
    return;
  }
  
  for (n = nn-1; n >= 0; n--) {
    p = d.a[n];
    q = e.a[n];
    
    // Real vector
    
    if (q == 0) {
      int l = n;
      H.a[n][n] = 1.0;
      for (int i = n-1; i >= 0; i--) {
	w = H.a[i][i] - p;
	r = 0.0;
	for (int j = l; j <= n; j++) {
	  r = r + H.a[i][j] * H.a[j][n];
	}
	if (e.a[i] < 0.0) {
	  z = w;
	  s = r;
	} else {
	  l = i;
	  if (e.a[i] == 0.0) {
	    if (w != 0.0) {
	      H.a[i][n] = -r / w;
	    } else {
	      H.a[i][n] = -r / (eps * norm);
	    }
	    
	    // Solve real equations
	    
	  } else {
	    x = H.a[i][i+1];
	    y = H.a[i+1][i];
	    q = (d.a[i] - p) * (d.a[i] - p) + e.a[i] * e.a[i];
	    t = (x * s - z * r) / q;
	    H.a[i][n] = t;
	    if (fabs(x) > fabs(z)) {
	      H.a[i+1][n] = (-r - w * t) / x;
	    } else {
	      H.a[i+1][n] = (-s - y * t) / z;
	    }
	  }
	  
	  // Overflow control
	  
	  t = fabs(H.a[i][n]);
	  if ((eps * t) * t > 1) {
	    for (int j = i; j <= n; j++) {
	      H.a[j][n] = H.a[j][n] / t;
	    }
	  }
	}
      }
      
      // Complex vector
      
    } else if (q < 0) {
      int l = n-1;
      
      // Last vector component imaginary so matrix is triangular
      
      if (fabs(H.a[n][n-1]) > fabs(H.a[n-1][n])) {
	H.a[n-1][n-1] = q / H.a[n][n-1];
	H.a[n-1][n] = -(H.a[n][n] - p) / H.a[n][n-1];
      } else {
	cdiv(0.0,-H.a[n-1][n],H.a[n-1][n-1]-p,q);
	H.a[n-1][n-1] = cdivr;
	H.a[n-1][n] = cdivi;
      }
      H.a[n][n-1] = 0.0;
      H.a[n][n] = 1.0;
      for (int i = n-2; i >= 0; i--) {
	double ra,sa,vr,vi;
	ra = 0.0;
	sa = 0.0;
	for (int j = l; j <= n; j++) {
	  ra = ra + H.a[i][j] * H.a[j][n-1];
	  sa = sa + H.a[i][j] * H.a[j][n];
	}
	w = H.a[i][i] - p;
	
	if (e.a[i] < 0.0) {
	  z = w;
	  r = ra;
	  s = sa;
	} else {
	  l = i;
	  if (e.a[i] == 0) {
	    cdiv(-ra,-sa,w,q);
	    H.a[i][n-1] = cdivr;
	    H.a[i][n] = cdivi;
	  } else {
	    
	    // Solve complex equations
	    
	    x = H.a[i][i+1];
	    y = H.a[i+1][i];
	    vr = (d.a[i] - p) * (d.a[i] - p) + e.a[i] * e.a[i] - q * q;
	    vi = (d.a[i] - p) * 2.0 * q;
	    if (vr == 0.0 && vi == 0.0) {
	      vr = eps * norm * (fabs(w) + fabs(q) +
				 fabs(x) + fabs(y) + fabs(z));
	    }
	    cdiv(x*r-z*ra+q*sa,x*s-z*sa-q*ra,vr,vi);
	    H.a[i][n-1] = cdivr;
	    H.a[i][n] = cdivi;
	    if (fabs(x) > (fabs(z) + fabs(q))) {
	      H.a[i+1][n-1] = (-ra - w * H.a[i][n-1] + q * H.a[i][n]) / x;
	      H.a[i+1][n] = (-sa - w * H.a[i][n] - q * H.a[i][n-1]) / x;
	    } else {
	      cdiv(-r-y*H.a[i][n-1],-s-y*H.a[i][n],z,q);
	      H.a[i+1][n-1] = cdivr;
	      H.a[i+1][n] = cdivi;
	    }
	  }
	  
	  // Overflow control
	  
	  t = max(fabs(H.a[i][n-1]),fabs(H.a[i][n]));
	  if ((eps * t) * t > 1) {
	    for (int j = i; j <= n; j++) {
	      H.a[j][n-1] = H.a[j][n-1] / t;
	      H.a[j][n] = H.a[j][n] / t;
	    }
	  }
	}
      }
    }
  }
  
  // Vectors of isolated roots
  
  for (int i = 0; i < nn; i++) {
    if (i < low || i > high) {
      for (int j = i; j < nn; j++) {
	V.a[i][j] = H.a[i][j];
      }
    }
  }
  
  // Back transformation to get eigenvectors of original matrix
  
  for (int j = nn-1; j >= low; j--) {
    for (int i = low; i <= high; i++) {
      z = 0.0;
      for (int k = low; k <= min(j,high); k++) {
	z = z + V.a[i][k] * H.a[k][j];
      }
      V.a[i][j] = z;
    }
  }
}     

void eigen(matrix &D, matrix &V, vector &d, vector &e, const matrix &Arg)
{
  
  int n = Arg.ncols;
  bool issymmetric;
  
  matrix A(n,n);
  A = Arg;
  
//      matrix V = new matrix(n,n);
//      vector d = new vector(n);
//      vector e = new vector(n);

  issymmetric = true;
  for (int j = 0; (j < n) && issymmetric; j++) {
    for (int i = 0; (i < n) && issymmetric; i++) {
      issymmetric = (A.a[i][j] == A.a[j][i]);
    }
  }
  
  if (issymmetric) {
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
	V.a[i][j] = A.a[i][j];
      }
    }
    
    // Tridiagonalize.
    tred2(d, e, V);
    
    // Diagonalize.
    tql2(d, e, V);
    
  } else {
    matrix H(n,n);
    vector ort(n);
    
    for (int j = 0; j < n; j++) {
      for (int i = 0; i < n; i++) {
	H.a[i][j] = A.a[i][j];
      }
    }
    
    // Reduce to Hessenberg form.
    orthes(d, e, ort, V, H);
    
    // Reduce Hessenberg to real Schur form.
    hqr2(d, e, V, H);
  }
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      D.a[i][j] = 0.0;
    }
    D.a[i][i] = d.a[i];
    if (e.a[i] > 0) {
      D.a[i][i+1] = e.a[i];
    } else if (e.a[i] < 0) {
      D.a[i][i-1] = e.a[i];
    }
  }
}

void svd (matrix &U, matrix &D, matrix &V, const matrix &Arg) {

      // Derived from LINPACK code.
      // Initialize.
  int m = Arg.nrows;
  int n = Arg.ncols;
  
  matrix A(m,n);
  A = Arg;
  
  int nu = min(m,n);
  vector s = vector(min(m+1,n));
  
  //      U = new double [m][nu];
  //      V = new double [n][n];
  
  vector e(n);
  vector work(m);
  bool wantu = true;
  bool wantv = true;
  
  // Reduce A to bidiagonal form, storing the diagonal elements
  // in s and the super-diagonal elements in e.
  
  int nct = min(m-1,n);
  int nrt = max(0,min(n-2,m));
  for (int k = 0; k < max(nct,nrt); k++) {
    if (k < nct) {
      
      // Compute the transformation for the k-th column and
      // place the k-th diagonal in s[k].
      // Compute 2-norm of k-th column without under/overflow.
      s[k] = 0;
      for (int i = k; i < m; i++) {
	s[k] = hypot(s[k],A.a[i][k]);
      }
      if (s[k] != 0.0) {
	if (A.a[k][k] < 0.0) {
	  s[k] = -s[k];
	}
	for (int i = k; i < m; i++) {
	  A.a[i][k] /= s[k];
	}
	A.a[k][k] += 1.0;
      }
      s[k] = -s[k];
    }
    for (int j = k+1; j < n; j++) {
      if ((k < nct) && (s[k] != 0.0))  {
	
	// Apply the transformation.
	
	double t = 0;
	for (int i = k; i < m; i++) {
	  t += A.a[i][k]*A.a[i][j];
	}
	t = -t/A.a[k][k];
	for (int i = k; i < m; i++) {
	  A.a[i][j] += t*A.a[i][k];
	}
      }
      
      // Place the k-th row of A into e for the
      // subsequent calculation of the row transformation.
      
      e[j] = A.a[k][j];
    }
    if (wantu && (k < nct)) {
      
      // Place the transformation in U for subsequent back
      // multiplication.
      
      for (int i = k; i < m; i++) {
	U.a[i][k] = A.a[i][k];
      }
    }
    if (k < nrt) {
      
      // Compute the k-th row transformation and place the
      // k-th super-diagonal in e[k].
      // Compute 2-norm without under/overflow.
      e[k] = 0;
      for (int i = k+1; i < n; i++) {
	e[k] = hypot(e[k],e[i]);
      }
      if (e[k] != 0.0) {
	if (e[k+1] < 0.0) {
	  e[k] = -e[k];
	}
	for (int i = k+1; i < n; i++) {
	  e[i] /= e[k];
	}
	e[k+1] += 1.0;
      }
      e[k] = -e[k];
      if ((k+1 < m) && (e[k] != 0.0)) {
	
	// Apply the transformation.
	
	for (int i = k+1; i < m; i++) {
	  work[i] = 0.0;
	}
	for (int j = k+1; j < n; j++) {
	  for (int i = k+1; i < m; i++) {
	    work[i] += e[j]*A.a[i][j];
	  }
	}
	for (int j = k+1; j < n; j++) {
	  double t = -e[j]/e[k+1];
	  for (int i = k+1; i < m; i++) {
	    A.a[i][j] += t*work[i];
	  }
	}
      }
      if (wantv) {
	
	// Place the transformation in V for subsequent
	// back multiplication.
	
	for (int i = k+1; i < n; i++) {
	  V.a[i][k] = e[i];
	}
      }
    }
  }
  
  // Set up the final bidiagonal matrix or order p.
  
  int p = min(n,m+1);
      if (nct < n) {
	s[nct] = A.a[nct][nct];
      }
      if (m < p) {
	s[p-1] = 0.0;
      }
      if (nrt+1 < p) {
	e[nrt] = A.a[nrt][p-1];
      }
      e[p-1] = 0.0;

      // If required, generate U.
      
      if (wantu) {
	for (int j = nct; j < nu; j++) {
	  for (int i = 0; i < m; i++) {
	    U.a[i][j] = 0.0;
	  }
	  U.a[j][j] = 1.0;
	}
	for (int k = nct-1; k >= 0; k--) {
	  if (s[k] != 0.0) {
	    for (int j = k+1; j < nu; j++) {
	      double t = 0;
	      for (int i = k; i < m; i++) {
		t += U.a[i][k]*U.a[i][j];
	      }
	      t = -t/U.a[k][k];
	      for (int i = k; i < m; i++) {
		U.a[i][j] += t*U.a[i][k];
	      }
	    }
	    for (int i = k; i < m; i++ ) {
	      U.a[i][k] = -U.a[i][k];
	    }
	    U.a[k][k] = 1.0 + U.a[k][k];
	    for (int i = 0; i < k-1; i++) {
	      U.a[i][k] = 0.0;
	    }
	  } else {
	    for (int i = 0; i < m; i++) {
	      U.a[i][k] = 0.0;
	    }
	    U.a[k][k] = 1.0;
	  }
	}
      }
      
      // If required, generate V.
      
      if (wantv) {
	for (int k = n-1; k >= 0; k--) {
	  if ((k < nrt) && (e[k] != 0.0)) {
	    for (int j = k+1; j < nu; j++) {
	      double t = 0;
	      for (int i = k+1; i < n; i++) {
		t += V.a[i][k]*V.a[i][j];
	      }
	      t = -t/V.a[k+1][k];
	      for (int i = k+1; i < n; i++) {
		V.a[i][j] += t*V.a[i][k];
	      }
	    }
	  }
	  for (int i = 0; i < n; i++) {
	    V.a[i][k] = 0.0;
	  }
	  V.a[k][k] = 1.0;
	}
      }
      
      // Main iteration loop for the singular values.

      int pp = p-1;
      int iter = 0;
      double eps = pow(2.0,-52.0);
      while (p > 0) {
	int k,kase;
	
	// Here is where a test for too many iterations would go.
	
	// This section of the program inspects for
	// negligible elements in the s and e arrays.  On
	// completion the variables kase and k are set as follows.
	
	// kase = 1     if s(p) and e[k-1] are negligible and k<p
	// kase = 2     if s(k) is negligible and k<p
	// kase = 3     if e[k-1] is negligible, k<p, and
	//              s(k), ..., s(p) are not negligible (qr step).
	// kase = 4     if e(p-1) is negligible (convergence).
	
	for (k = p-2; k >= -1; k--) {
	  if (k == -1) {
	    break;
	  }
	  if (fabs(e[k]) <= eps*(fabs(s[k]) + fabs(s[k+1]))) {
	    e[k] = 0.0;
	    break;
	  }
	}
	if (k == p-2) {
	  kase = 4;
	} else {
	  int ks;
	  for (ks = p-1; ks >= k; ks--) {
	    if (ks == k) {
	      break;
	    }
	    double t = (ks != p ? fabs(e[ks]) : 0.) +
	      (ks != k+1 ? fabs(e[ks-1]) : 0.);
	    if (fabs(s[ks]) <= eps*t)  {
	      s[ks] = 0.0;
	      break;
	    }
	  }
	  if (ks == k) {
	    kase = 3;
	  } else if (ks == p-1) {
	    kase = 1;
	  } else {
	    kase = 2;
	    k = ks;
	  }
	}
	k++;
	
	// Perform the task indicated by kase.
	
	switch (kase) {
	  
	  // Deflate negligible s(p).
	  
	case 1: {
	  double f = e[p-2];
	  e[p-2] = 0.0;
	  for (int j = p-2; j >= k; j--) {
	    double t = hypot(s[j],f);
	    double cs = s[j]/t;
	    double sn = f/t;
	    s[j] = t;
	    if (j != k) {
	      f = -sn*e[j-1];
	      e[j-1] = cs*e[j-1];
	    }
	    if (wantv) {
	      for (int i = 0; i < n; i++) {
		t = cs*V.a[i][j] + sn*V.a[i][p-1];
		V.a[i][p-1] = -sn*V.a[i][j] + cs*V.a[i][p-1];
		V.a[i][j] = t;
	      }
	    }
	  }
	}
	  break;
	  
	  // Split at negligible s(k).
	  
	case 2: {
	  double f = e[k-1];
	  e[k-1] = 0.0;
	  for (int j = k; j < p; j++) {
	    double t = hypot(s[j],f);
	    double cs = s[j]/t;
	    double sn = f/t;
	    s[j] = t;
	    f = -sn*e[j];
	    e[j] = cs*e[j];
	    if (wantu) {
	      for (int i = 0; i < m; i++) {
		t = cs*U.a[i][j] + sn*U.a[i][k-1];
		U.a[i][k-1] = -sn*U.a[i][j] + cs*U.a[i][k-1];
		U.a[i][j] = t;
	      }
	    }
	  }
	}
	  break;
	  
	  // Perform one qr step.
	  
	case 3: {
	  
	  // Calculate the shift.
	  
	  double scale = max(max(max(max(
					 fabs(s[p-1]),fabs(s[p-2])),fabs(e[p-2])),
				 fabs(s[k])),fabs(e[k]));
	  double sp = s[p-1]/scale;
	  double spm1 = s[p-2]/scale;
	  double epm1 = e[p-2]/scale;
	  double sk = s[k]/scale;
	  double ek = e[k]/scale;
	  double b = ((spm1 + sp)*(spm1 - sp) + epm1*epm1)/2.0;
	  double c = (sp*epm1)*(sp*epm1);
	  double shift = 0.0;
	  if ((b != 0.0) | (c != 0.0)) {
	    shift = sqrt(b*b + c);
	    if (b < 0.0) {
	      shift = -shift;
	    }
	    shift = c/(b + shift);
	  }
	  double f = (sk + sp)*(sk - sp) + shift;
	  double g = sk*ek;
	  
	  // Chase zeros.
	  
	  for (int j = k; j < p-1; j++) {
	    double t = hypot(f,g);
	    double cs = f/t;
	    double sn = g/t;
	    if (j != k) {
	      e[j-1] = t;
	    }
	    f = cs*s[j] + sn*e[j];
	    e[j] = cs*e[j] - sn*s[j];
	    g = sn*s[j+1];
	    s[j+1] = cs*s[j+1];
	    if (wantv) {
	      for (int i = 0; i < n; i++) {
		t = cs*V.a[i][j] + sn*V.a[i][j+1];
		V.a[i][j+1] = -sn*V.a[i][j] + cs*V.a[i][j+1];
		V.a[i][j] = t;
	      }
	    }
	    t = hypot(f,g);
	    cs = f/t;
	    sn = g/t;
	    s[j] = t;
	    f = cs*e[j] + sn*s[j+1];
	    s[j+1] = -sn*e[j] + cs*s[j+1];
	    g = sn*e[j+1];
	    e[j+1] = cs*e[j+1];
	    if (wantu && (j < m-1)) {
	      for (int i = 0; i < m; i++) {
		t = cs*U.a[i][j] + sn*U.a[i][j+1];
		U.a[i][j+1] = -sn*U.a[i][j] + cs*U.a[i][j+1];
		U.a[i][j] = t;
	      }
	    }
	  }
	  e[p-2] = f;
	  iter = iter + 1;
	}
	  break;
	  
	  // Convergence.
	  
	case 4: {
	  
	  // Make the singular values positive.
	  
	  if (s[k] <= 0.0) {
	    s[k] = (s[k] < 0.0 ? -s[k] : 0.0);
	    if (wantv) {
	      for (int i = 0; i <= pp; i++) {
		V.a[i][k] = -V.a[i][k];
	      }
	    }
	  }
	  
	  // Order the singular values.
	  
	  while (k < pp) {
	    if (s[k] >= s[k+1]) {
	      break;
	    }
	    double t = s[k];
	    s[k] = s[k+1];
	    s[k+1] = t;
	    if (wantv && (k < n-1)) {
	      for (int i = 0; i < n; i++) {
		t = V.a[i][k+1]; V.a[i][k+1] = V.a[i][k]; V.a[i][k] = t;
	      }
	    }
	    if (wantu && (k < m-1)) {
	      for (int i = 0; i < m; i++) {
		t = U.a[i][k+1]; U.a[i][k+1] = U.a[i][k]; U.a[i][k] = t;
	      }
	    }
	    k++;
	  }
	  iter = 0;
	  p--;
	}
	  break;
	}
      }
      for (int i = 0; i < n; i++) {
	for (int j = 0; j < n; j++) {
	  D.a[i][j] = 0.0;
	}
	D.a[i][i] = s[i];
      }
}

//MATRIX OPERATORS

matrix operator + (const matrix &A, const matrix &B)
{
  matrix temp(A.nrows, A.ncols);
  
  matsum(temp, A, B);
  
  return temp;
}

matrix operator - (const matrix &A, const matrix &B)
{
  matrix temp(A.nrows, A.ncols);
  
  matdiff(temp, A, B);

  return temp;
}

matrix operator * (const matrix &A, const matrix &B)
{
  matrix temp(A.nrows, B.ncols);
  
  matpr(temp, A, B);
  
  return temp;
}

matrix operator * (const double x, const matrix &rhs)
{
  int i, j;
  
  matrix temp(rhs.nrows, rhs.ncols);
  
  for (i = 0; i < rhs.nrows; i++) {
    for (j = 0; j < rhs.ncols; j++) {
      temp.a[i][j] = x * rhs.a[i][j];
    }
  }
  
  return temp;
}

matrix operator * (const matrix &lhs, const double x)
{
  int i, j;
  
  matrix temp(lhs.nrows, lhs.ncols);
  
  for (i = 0; i < lhs.nrows; i++) {
    for (j = 0; j < lhs.ncols; j++) {
      temp.a[i][j] = x * lhs.a[i][j];
    }
  }
  
  return temp;
}

matrix operator / (const matrix &lhs, const double x)
{
  int i, j;
  
  matrix temp (lhs.nrows, lhs.ncols);
  
  for (i = 0; i < lhs.nrows; i++) {
    for (j = 0; j < lhs.ncols; j++) temp.a[i][j] = lhs.a[i][j] / x;
  }
  
  return temp;
}

matrix operator % (const matrix &lhs, const matrix &rhs)
{
  int i, j, k, l;
  matrix out(lhs.nrows*rhs.nrows, lhs.ncols*rhs.ncols);
  
  for (k = 0; k < lhs.nrows; k++) {
    for (l = 0; l < lhs.ncols; l++) {
      for (i = 0; i < rhs.nrows; i++) {
	for (j = 0; j < rhs.ncols; j++) {
	  out(k*rhs.nrows+i,l*rhs.ncols+j) = lhs(k,l)*rhs(i,j);
	}
      }
    }
  }
  return out;
}

//Vector methods and functions

vector::vector (void)
{
}

vector::vector (int len)
{
  length = len;
  a = create_vectord (length);
}

vector::~vector() // Destructor
{
  //	cout << "destructor called" << endl;
  if (!a) return;
  delete [] a;
  a = 0;
}

vector::vector (const vector &rhs) //Copy constructor
{
  //	cout << "Copy Constructor called" << endl;
  length = rhs.length;
  a = create_vectord (length);
  copy (a, rhs.a, length);
  
}

vector &vector::operator = (const vector &rhs)
{
  //	cout <<"=operator called\n";
  copy (a, rhs.a, rhs.length);
  return *this;
}

double &vector::operator [] (const int i) const
{
  if (i >= length) {
    cout << "Invalid vector element access in []" << endl;
    (void) getchar();
    exit(0);
  }
  return this->a[i];
}

void vector::freeit (void)
{
  if (!a) return;
  delete [] a;
  a = 0;
}

double vector::compu_norm (void)
{
  norm = sqrt(innerprod (a, a, length));
  return norm;
}

void copy (vector &lhs, const vector &rhs)
{
  int i;
  
  for (i = 0; i < lhs.length; i++) lhs.a[i] = rhs.a[i];

}

void vecsum (vector &out, const vector &lhs, const vector &rhs)
{
  vecsum (out.a, lhs.a, rhs.a, out.length);
}

void vecdiff (vector &out, const vector &lhs, const vector &rhs)
{
  vecdiff (out.a, lhs.a, rhs.a, out.length);
}

void vecsclpr (vector &out, double x, const vector &rhs)
{
  vecsclpr (out.a, x, rhs.a, out.length);
}

double innerprod (const vector &x, const vector &y)
{
  return innerprod (x.a, y.a, x.length);
}

double sum_components (const vector &x, int start, int end)
{
  return sum_components (x.a, start, end);
}

void sub_vector (vector &out, const vector &x, int start, int end)
{
  for (int i = 0; i < end-start+1; i++) out[i] = x[i+start-1];
}

void concatenate (vector &out, const vector &x, const vector &y)
{
  int i;
  for (i = 0; i < x.length; i++) out.a[i] = x.a[i];
  for (i = x.length; i < out.length; i++) out.a[i] = y.a[i];
}

void freadvec (FILE *fin, vector &A)
{
  for (int i = 0; i < A.length; i++) fscanf (fin, "%lf", &A[i]);
}

void freadvec (const char *filename, vector &A)
{
  ifstream fin(filename);
  
  for (int i = 0; i < A.length; i++) fin >> A[i];
}

void printvec (const vector &x)
{
  printvec (x.a, x.length);
}


//VECTOR OPERATORS

vector operator + (const vector &lhs, const vector &rhs)
{
  //	int i;
  
  vector temp (lhs.length);
  
  vecsum (temp, lhs, rhs);
  //for (i = 0; i < lhs.length; i++) temp.a[i] = lhs.a[i] + rhs.a[i];
  
  return temp;
}

vector operator - (const vector &lhs, const vector &rhs)
{
  int i;
  
  vector temp (lhs.length);
  
  for (i = 0; i < lhs.length; i++) temp.a[i] = lhs.a[i] - rhs.a[i];
  
  return temp;
}

double operator * (const vector &lhs, const vector &rhs)
{
  double temp;
  
  temp = innerprod (lhs.a, rhs.a, lhs.length);
  
  return temp;
}

vector operator * (const double x, const vector &rhs)
{
  int i;
  vector temp(rhs.length);
  
  for (i = 0; i < rhs.length; i++) temp.a[i] = x*rhs.a[i];
  
  return temp;
}

vector operator * (const vector &lhs, const double x)
{
  int i;
  vector temp(lhs.length);
  
  for (i = 0; i < lhs.length; i++) temp.a[i] = x*lhs.a[i];
  
  return temp;
}

vector operator / (const vector &lhs, const double x)
{
  int i;
  vector temp(lhs.length);
  
  for (i = 0; i < lhs.length; i++) temp.a[i] = lhs.a[i] / x;
  
  return temp;
}

//Other useful functions involving matrices and vectors

void matvecpr (vector &out, const matrix &A, const vector &x)
{
  int i, j;
  double sum;
  
  out.length = A.nrows;
  
  for (i = 0; i < A.nrows; i++) {
    sum = 0;
    for (j = 0; j < A.ncols; j++) {
      sum += A.a[i][j] * x.a[j];
    }
    out.a[i] = sum;
  }
}

void matvecpr (vector &out, const vector &x, const matrix &A)
{
  int i, j;
  double sum;
  
  out.length = A.ncols;
  
  for (j = 0; j < A.ncols; j++) {
    sum = 0;
    for (i = 0; i < A.nrows; i++) {
      sum += x.a[i] * A.a[i][j];
    }
    out.a[j] = sum;
  }
}

void solve (vector &x, const matrix &A, const vector &b)
{
  int *indx, n = A.nrows;
  double d, **temp;
  
  indx = create_vector (n);
  temp = create_matrixd (n, n);
  copy (temp, A.a, n, n);
  copy (x.a, b.a, n);
  
  ludcmp (temp, n, indx, &d);
  lubksb (temp, n, indx, x.a);
  
  delete [] indx;
  freemat (temp, n, n);
}

double ellipse (const vector &x, const matrix &A, const vector &y)
{
  double quad;
  
  vector temp (A.nrows);
  
  matvecpr (temp, A, y);
  
  quad = innerprod (x, temp);
  
  temp.freeit();
  
  return quad;
}

void Row_extract (vector &lhs, const matrix &rhs, const int &row_no)
{
  int j;
  for (j = 0; j < rhs.ncols; j++) lhs[j] = rhs(row_no, j);
}

void Col_extract (vector &lhs, const matrix &rhs, const int &col_no)
{
  int i;
  for (i = 0; i < rhs.nrows; i++) lhs[i] = rhs(i, col_no);
}

vector operator * (const matrix &lhs, const vector &x)
{
  vector temp (lhs.nrows);
  
  matvecpr (temp, lhs, x);

  return temp;
}

vector operator * (const vector &x, const matrix &rhs)
{
  vector temp (rhs.nrows);
  
  matvecpr (temp, x, rhs);
  
  return temp;
}
