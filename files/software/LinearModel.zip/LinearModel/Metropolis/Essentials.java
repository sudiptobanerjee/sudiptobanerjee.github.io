/*
 * Essentials.java
 *
 * Created on December 9, 2002, 8:58 AM
 */

import StatPack.Jama.*;
import StatPack.MyIO.*;
import StatPack.Metropolis.*;
import java.io.*;
import java.util.StringTokenizer;


/**
 *
 * @author  sudiptob
 */
public class Essentials extends Metropolis  {
    
    /** Creates a new instance of Essentials */
    public Essentials() {
	super();
    }
    
    /** Create objects for use in this class **/
    static Matrix Y = new Matrix(Main.N,1);
    static Matrix X = new Matrix(Main.N, Main.no_covariates);
    static Matrix t_X = new Matrix(Main.no_covariates, Main.N);
    static Matrix DISP = new Matrix(Main.N, Main.N), 
	DISPINV = new Matrix(Main.N,Main.N);
    static double DISP_log_det;
    static double a = Main.a0, b = Main.b0;

    /** Method to read data **/
    public static void read_data ()
    {

	File fin = new File("X2.txt");
        fileinput.readmatrix(fin, X);
	t_X = X.transpose();
        
        File fin2 = new File("Y_12.txt");
        fileinput.readmatrix(fin2,Y);
        
    }

    /** Method to initialize Gibbs parameters **/
    public static void startvals ()
    {
	
	for(int i=0; i< Main.no_covariates; i++) {
	    Main.beta.set(i,0, 0.0);
	    Main.beta_mean.set(i,0, 0.0);
	    Main.scale[i] = 0.25;
	}
	Main.sigmasq = 1.0;
	Main.sigmasq_scale = 0.25;
    }

/** Method to compute DISP and DISP_INV **/
    
    public static void compute_DISPINV (double x)
    {
	//	System.out.println("Inside DISPINV fn: "+x);
	DISP.setMatrix(0,DISP.getRowDimension()-1,0,DISP.getColumnDimension()-1, 
		       Matrix.identity(DISP.getRowDimension(),DISP.getColumnDimension()).times(x));
	
	DISPINV = DISP.inverse();
	
	DISP_log_det = DISP.log_det();
    }

    public void update_beta ()
    {
	double [] x = new double[Main.niter+1];

	for (int j = 0; j < Main.no_covariates;j++) {
		    Main.COUNT[j] += 
			sample_normal(x,
				      Main.beta.get(j,0),
				      Main.niter,
				      Main.scale[j],
				      j);
		    Main.beta.set(j,0, x[Main.niter]);
	}
    }

    public void update_sigmasq ()
    {
	double [] x = new double[Main.niter+1];
	
	Main.COUNT_sigmasq += 
	    sample_normal(x,
			  Math.log(Main.sigmasq),
			  Main.niter,
			  Main.sigmasq_scale);
	//	System.out.println("x[Main.niter]: "+x[Main.niter]);
	Main.sigmasq = Math.exp(x[Main.niter]);
    }

    
    public double target (final double x, final int j) 
    {
	Matrix theta = new Matrix(Main.beta.getArrayCopy());
	theta.set(j,0, x);
	
	return 
	    -0.5*(Y.minus(X.times(theta)).transpose().times(DISPINV).times(Y.minus(X.times(theta))).get(0,0))/Main.sigmasq;
    }
    
    public double target (final double x)
    {
	double y = Math.exp(x);

	Matrix theta = new Matrix(Main.beta.getArrayCopy());

	compute_DISPINV(y);

	return
	     -0.5*(Y.minus(X.times(theta)).transpose().times(DISPINV).times(Y.minus(X.times(theta))).get(0,0))
	    - 0.5*DISP_log_det - b/y - (a+1)*Math.log(y);
    }	

    public double proposal (double x, double y, double scale)
    {
	return 0;
    }

    public double rproposal (double x, double scale)
    {
	return 0;
    }

    public double target (final Matrix x)
    {
	return 0;
    }
}


