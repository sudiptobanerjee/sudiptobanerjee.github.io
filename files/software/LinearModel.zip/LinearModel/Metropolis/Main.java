/*
 * Main.java
 *
 * Created on December 9, 2002, 8:51 AM
 */

import StatPack.Jama.*;
import StatPack.Distributions.*;
import StatPack.MyIO.*;
import java.io.*;

/**
 *
 * @author  sudiptob
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
        /** Global constants: **/
    public static int no_covariates = 4;
    public static int N = 389;
    public static int NITER = 10000;
    public static int niter = 1;
    public static double a0 = 0.00001, b0 = 0.000001;
    
    /** Global variables: **/
    public static double sigmasq;
    public static Matrix beta = new Matrix(no_covariates,1);    
    public static Matrix beta_disp = new Matrix(no_covariates, no_covariates);
    public static Matrix beta_mean = new Matrix(no_covariates,1);
    
    public static double [] scale = new double[no_covariates];
    public static double sigmasq_scale = 0.025;
    public static int [] COUNT = new int [no_covariates];
    public static int COUNT_sigmasq = 0;
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
       	double quad;
        File fout = new File("Output.txt");
        FileWriter fw = new FileWriter(fout);
        BufferedWriter bw = new BufferedWriter(fw);
	
	Essentials E = new Essentials();
    
	System.out.println("Reading Data");
	E.read_data ();

	System.out.println ("Setting Starting values");
	E.startvals ();
	System.out.println("sigmasq: "+sigmasq);
	for (int i = 0; i < NITER; i++) {
		System.out.println("Iteration: "+ (i+1));

		E.compute_DISPINV(sigmasq);
		System.out.println("Update beta");
		E.update_beta();
		System.out.println("Update sigmasq");
		E.update_sigmasq ();
		System.out.println("Writing output");
		for (int j = 0; j < no_covariates; j++) {
		    System.out.print("Acceptance Ratios: "+(COUNT[j]+0.0)/(i+1)+" ");
                    bw.write(Double.toString(beta.get(j,0))+" ");  
		}
                System.out.println((COUNT_sigmasq+0.0)/(i+1));
		bw.write(Double.toString(sigmasq));
                bw.newLine(); 
	}
       bw.close();
       fw.close();
       
       System.out.println("End of program.");
    }

}
    
