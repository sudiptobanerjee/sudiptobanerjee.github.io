/*
 * Main.java
 *
 * Created on December 9, 2002, 8:51 AM
 */

import StatPack.Jama.*;
import StatPack.Distributions.*;
import StatPack.MyIO.*;
import java.io.*;

/**
 *
 * @author  sudiptob
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
        /** Global constants: **/
    public static int no_covariates = 4;
    public static int N = 389;
    public static int NITER = 10000;
    public static double a0 = 0.01, b0 = 0.01;
    
    /** Global variables: **/
    public static double sigmasq;
    public static Matrix beta = new Matrix(no_covariates,1);    
    public static Matrix beta_disp = new Matrix(no_covariates, no_covariates);
    public static Matrix beta_mean = new Matrix(no_covariates,1);
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
       	double quad;
        File fout = new File("Output.txt");
        FileWriter fw = new FileWriter(fout);
        BufferedWriter bw = new BufferedWriter(fw);
        
	System.out.println("Reading Data");
	Essentials.read_data ();

	System.out.println ("Setting Starting values");
	Essentials.startvals ();

	for (int i = 0; i < NITER; i++) {
		System.out.println("Iteration: "+ (i+1));
                
		/*                Essentials.compute_DISPINV();
                Essentials.compute_beta_disp ();
                Essentials.compute_beta_mean ();
		Normal.mrandom(beta, beta_mean, beta_disp);
		*/
		Essentials.set_beta_disp ();
                Essentials.set_beta_mean ();
		Normal.mrandom(beta, beta_mean, beta_disp);
		quad = Essentials.set_quad ();
		sigmasq = Gamma.irandom(a0 + N/2, b0 + quad/2);

		for (int j = 0; j < no_covariates; j++) 
                    bw.write(Double.toString(beta.get(j,0))+" ");               
                bw.write(Double.toString(sigmasq));
                bw.newLine(); 
	}
       bw.close();
       fw.close();
       System.out.println("End of program.");
    }

}
    
