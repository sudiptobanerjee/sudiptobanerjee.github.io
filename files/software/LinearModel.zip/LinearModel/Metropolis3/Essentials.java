/*
 * Essentials.java in Metropolis2/
 *
 * Created on December 9, 2002, 8:58 AM
 */

import StatPack.Jama.*;
import StatPack.MyIO.*;
import StatPack.Distributions.*;
import java.io.*;
import java.util.StringTokenizer;


/**
 *
 * @author  sudiptob
 */
public class Essentials {
    
    /** Creates a new instance of Essentials */
    public Essentials() {
	super();
    }
    
    /** Create objects for use in this class **/
    static Matrix Y = new Matrix(Main.N,1),
	X = new Matrix(Main.N, Main.no_covariates),
	t_X = new Matrix(Main.no_covariates, Main.N),
	DISP = new Matrix(Main.N, Main.N), 
	DISPINV = new Matrix(Main.N,Main.N);
    
    static double DISP_log_det=0.0,
	a = Main.a0, 
	b = Main.b0;
    
    static int no_covariates = Main.no_covariates,
	no_parameters = Main.no_parameters,
	niter = Main.niter;

    /** Method to read data **/
    public static void read_data ()
    {

	File fin = new File("X2.txt");
        fileinput.readmatrix(fin, X);
	t_X = X.transpose();
        
        File fin2 = new File("Y_12.txt");
        fileinput.readmatrix(fin2,Y);
        
    }

    /** Method to initialize parameters **/
    public static void startvals ()
    {
	for(int i=0; i< Main.no_covariates; i++) 
	    Main.beta.set(i,0, 30.0);
	Main.beta.set(2,0, -80.0);
	Main.sigmasq = 1.0;
	Main.Theta.setMatrix(0,no_covariates-1,0,0, Main.beta);
	Main.Theta.set(no_parameters-1,0, Math.log(Main.sigmasq));
    }
    
    /** Method to set the Metropolis scales of the parameters**/
    public static void metrop_scale ()
    {
	for (int i=0; i < no_covariates; i++) 
	    Main.scale.set(i,i, 0.0045);
	Main.scale.set(no_parameters-1,no_parameters-1,0.0025);
    }


    /** Method to compute DISP and DISP_INV **/
    
    public static void compute_DISPINV (double x)
    {
	//	System.out.println("Inside DISPINV fn: "+x);
	DISP.setMatrix(0,DISP.getRowDimension()-1,0,DISP.getColumnDimension()-1, 
		       Matrix.identity(DISP.getRowDimension(),DISP.getColumnDimension()).times(x));
	
	//	DISPINV = DISP.inverse();
	DISPINV.setMatrix(0,DISP.getRowDimension()-1,0,DISP.getColumnDimension()-1, 
		       Matrix.identity(DISP.getRowDimension(),DISP.getColumnDimension()).by(x));
	
	//DISP_log_det = DISP.log_det();
	DISP_log_det = DISP.getRowDimension()*Math.log(x);
    }

    public static void update_parameters ()
    {
	Matrix x = new Matrix (no_parameters,niter+1, 0.0);

	Main.COUNT += sample_mnormal(x, Main.Theta, niter, Main.scale);
	Main.Theta.setMatrix(0,no_parameters-1,0,0, x.copy().getMatrix(0,no_parameters-1,niter,niter));
	Main.beta.setMatrix(0,no_covariates-1,0,0,Main.Theta);
	Main.sigmasq = Math.exp(Main.Theta.get(no_parameters-1,0));
    }

    public static double target (final Matrix x)
    {
	Matrix theta = new Matrix(no_covariates,1);
	theta.setMatrix(0,no_covariates-1,0,0,x);

	double y = Math.exp(x.get(no_parameters-1,0));
	compute_DISPINV(y);

	return
	    -0.5*(Y.minus(X.times(theta)).transpose().times(DISPINV).times(Y.minus(X.times(theta))).get(0,0))
	    -0.5*DISP_log_det - b/y - (a+1)*Math.log(y);
    }

    public static int sample_mnormal (Matrix x, 
				      Matrix x_prev, 
				      int niter, 
				      Matrix scale) {
	
	double r, temp, temp1, temp2;
        int k = 0;
	Matrix y = new Matrix(x.getRowDimension(),1, 0.0);
	x.setMatrix(0,x.getRowDimension()-1,0,0, x_prev);
	
	for (int j = 0; j < niter; j++) {
            
	    x.setMatrix(0,x.getRowDimension()-1, j+1,j+1, 
			x.getMatrix(0,x.getRowDimension()-1,j,j));
	    
	    y = Normal.mrandom(x.getMatrix(0,x.getRowDimension()-1,j+1,j+1), 
			       scale);
	    temp1 = target(y);
	    temp2 = target(x.getMatrix(0,x.getRowDimension()-1,j+1,j+1));
            
            r = temp1 + 
		lden_mnorm(x.getMatrix(0,x.getRowDimension()-1,j+1,j+1),
			   y, scale) - 
		(temp2 + lden_mnorm(y, x.getMatrix(0,x.getRowDimension()-1,
						   j+1,j+1), scale));
            
            if (r > 50) r = 50;
            else if (r < -10.0) r = 0.0;
            else r = Math.exp(r);
	    
            if (r >= 1) {
                x.setMatrix(0,x.getRowDimension()-1,j+1,j+1,y);
		k++;
            }
	    
            else {
                temp = Math.random();
		if (temp < r) {
		x.setMatrix(0,x.getRowDimension()-1,j+1,j+1,y);
		k++;
                }
		else x.setMatrix(0,x.getRowDimension()-1,j+1,j+1, x.getMatrix(0,x.getRowDimension()-1,j,j));
            }
        }
	return k;
    }
    
    public static int sample_joint (Matrix x, 
				    Matrix x_prev, 
				    int niter,
				    Matrix scale)
    {
	double r, temp, temp1, temp2;
        int k = 0;
	Matrix y = new Matrix(x.getRowDimension(),1, 0.0);
	
	x.setMatrix(0,x.getRowDimension()-1,0,0, x_prev);
	
	for (int j = 0; j < niter; j++) {
            
	    x.setMatrix(0,x.getRowDimension()-1, j+1,j+1, 
			x.getMatrix(0,x.getRowDimension()-1,j,j));
	    
	    y = Normal.mrandom(x.getMatrix(0,x.getRowDimension()-1,j+1,j+1), 
			       scale);
	    temp1 = target(y);
	    temp2 = target(x.getMatrix(0,x.getRowDimension()-1,j+1,j+1));
            
            r = temp1 + 
		lden_joint(x.getMatrix(0,x.getRowDimension()-1,j+1,j+1),
			   y, scale) - 
		(temp2 + lden_joint(y, x.getMatrix(0,x.getRowDimension()-1,
						   j+1,j+1), scale));
            
            if (r > 50) r = 50;
	    //           else if (r < -10.0) r = 0.0;
            else r = Math.exp(r);

            if (r >= 1) {
                x.setMatrix(0,x.getRowDimension()-1,j+1,j+1,y);
		k++;
            }
	    
            else {
                temp = Math.random();
		if (temp < r) {
		    x.setMatrix(0,x.getRowDimension()-1,j+1,j+1,y);
		    k++;
                }
		else x.setMatrix(0,x.getRowDimension()-1,j+1,j+1, x.getMatrix(0,x.getRowDimension()-1,j,j));
            }
        }
	return k;
      
    }
    
    static double lden_norm (double x, double mu, double scale)
    {
	return 
	    -Math.log(scale) - 0.50 * Math.pow(x-mu, 2) / Math.pow(scale, 2);
    }

    static double lden_mnorm (final Matrix x, final Matrix mu, final Matrix scale)
    {
	return 
	    -0.50*(x.minus(mu).transpose().times(scale.inverse()).times(x.minus(mu)).get(0,0));
    }
    
    static double lden_joint (final Matrix x, final Matrix mu, final Matrix scale)
    {
	Matrix x_normal = new Matrix(x.getRowDimension()-1,x.getColumnDimension()),
	    mu_normal = new Matrix(mu.getRowDimension()-1,mu.getColumnDimension()),
	    scale_normal = new Matrix(scale.getRowDimension()-1,scale.getColumnDimension()-1);
	
	double y = x.get(x.getRowDimension()-1,x.getColumnDimension()-1),
	    y_mu = mu.get(mu.getRowDimension()-1,mu.getRowDimension()-1),
	    scale_y = scale.get(scale.getRowDimension()-1,scale.getColumnDimension()-1); 
	
	x_normal.setMatrix(0,x_normal.getRowDimension()-1,0,0, x.getMatrix(0,x_normal.getRowDimension()-1,0,0));
	mu_normal.setMatrix(0,mu_normal.getRowDimension()-1,0,0, x.getMatrix(0,mu_normal.getRowDimension()-1,0,0));
	scale_normal.setMatrix(0,scale_normal.getRowDimension()-1,0,scale_normal.getColumnDimension()-1, 
			       scale.getMatrix(0,scale_normal.getRowDimension()-1,0,scale_normal.getColumnDimension()-1));

	return 
	    -0.50*(x_normal.minus(mu_normal).transpose().times(scale_normal.inverse()).times(x_normal.minus(mu_normal)).get(0,0))
	    -0.50*Math.log(scale_y) - 0.50 * Math.pow(y-y_mu, 2) / scale_y - y;
    }

}


