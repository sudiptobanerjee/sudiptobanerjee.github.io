/*
 * Main.java
 *
 * Created on December 9, 2002, 8:51 AM
 */

import StatPack.Jama.*;
import StatPack.Distributions.*;
import StatPack.MyIO.*;
import java.io.*;

/**
 *
 * @author  sudiptob
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
        /** Global constants: **/
    public static int no_covariates = 4;
    public static int no_parameters = 5;
    public static int N = 389;
    public static int NITER = 20000;
    public static int niter = 1;
    public static double a0 = 0.0001, b0 = 0.0001;
    
    /** Global variables: **/
    public static double sigmasq = 1.0;
    public static Matrix beta = new Matrix(no_covariates,1),    
	scale = new Matrix(no_parameters,no_parameters),
	Theta = new Matrix(no_parameters,1, 0.0);

    public static int COUNT = 0;
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {

       	double quad;
        
	File fout = new File("Output.txt");
        FileWriter fw = new FileWriter(fout);
        BufferedWriter bw = new BufferedWriter(fw);
    
	System.out.println("Reading Data");
	Essentials.read_data ();

	System.out.println ("Setting Starting values");
	Essentials.startvals ();

	System.out.println ("Setting Metropolis scales");
	Essentials.metrop_scale ();

	//	System.out.println("sigmasq: "+sigmasq);
	
	for (int i = 0; i < NITER; i++) {
		System.out.println("Iteration: "+ (i+1));

		Essentials.compute_DISPINV(sigmasq);
		System.out.println("Updating parameters");
		Essentials.update_parameters();

		System.out.println("Writing output");
		for (int j = 0; j < no_covariates; j++) {
                    bw.write(Double.toString(beta.get(j,0))+" ");  
		}
                System.out.println((COUNT+0.0)/(i+1));
		bw.write(Double.toString(sigmasq));
                bw.newLine(); 
	}
       bw.close();
       fw.close();
       
       System.out.println("End of program.");
    }

}
    
