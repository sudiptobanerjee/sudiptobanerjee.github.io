/*
 * Essentials.java in Metropolis2/
 *
 * Created on December 9, 2002, 8:58 AM
 */

import StatPack.Jama.*;
import StatPack.MyIO.*;
import StatPack.Metropolis.*;
import java.io.*;
import java.util.StringTokenizer;


/**
 *
 * @author  sudiptob
 */
public class Essentials extends Metropolis  {
    
    /** Creates a new instance of Essentials */
    public Essentials() {
	super();
    }
    
    /** Create objects for use in this class **/
    static Matrix Y = new Matrix(Main.N,1),
	X = new Matrix(Main.N, Main.no_covariates),
	t_X = new Matrix(Main.no_covariates, Main.N),
	DISP = new Matrix(Main.N, Main.N), 
	DISPINV = new Matrix(Main.N,Main.N);
    
    static double DISP_log_det=0.0,
	a = Main.a0, 
	b = Main.b0;
    
    static int no_covariates = Main.no_covariates,
	no_parameters = Main.no_parameters,
	niter = Main.niter;

    /** Method to read data **/
    public static void read_data ()
    {

	File fin = new File("X2.txt");
        fileinput.readmatrix(fin, X);
	t_X = X.transpose();
        
        File fin2 = new File("Y_12.txt");
        fileinput.readmatrix(fin2,Y);
        
    }

    /** Method to initialize parameters **/
    public static void startvals ()
    {
	for(int i=0; i< Main.no_covariates; i++) 
	    Main.beta.set(i,0, 0.0);
	Main.sigmasq = 1.0;
	Main.Theta.set(no_parameters-1,0, Math.log(Main.sigmasq));
    }
    
    /** Method to set the Metropolis scales of the parameters**/
    public static void metrop_scale ()
    {
	for (int i=0; i < no_covariates; i++) 
	    Main.scale.set(i,i, 0.0035);
	Main.scale.set(no_parameters-1,no_parameters-1,0.0035);
    }


    /** Method to compute DISP and DISP_INV **/
    
    public static void compute_DISPINV (double x)
    {
	//	System.out.println("Inside DISPINV fn: "+x);
	DISP.setMatrix(0,DISP.getRowDimension()-1,0,DISP.getColumnDimension()-1, 
		       Matrix.identity(DISP.getRowDimension(),DISP.getColumnDimension()).times(x));
	
	//	DISPINV = DISP.inverse();
	DISPINV.setMatrix(0,DISP.getRowDimension()-1,0,DISP.getColumnDimension()-1, 
		       Matrix.identity(DISP.getRowDimension(),DISP.getColumnDimension()).by(x));
	
	//DISP_log_det = DISP.log_det();
	DISP_log_det = DISP.getRowDimension()*Math.log(x);
    }

    public void update_parameters ()
    {
	Matrix x = new Matrix (no_parameters,niter+1, 0.0);

	Main.COUNT += sample_mnormal(x, Main.Theta, niter, Main.scale);
	Main.Theta.setMatrix(0,no_parameters-1,0,0, x.copy().getMatrix(0,no_parameters-1,niter,niter));
	Main.beta.setMatrix(0,no_covariates-1,0,0,Main.Theta);
	Main.sigmasq = Math.exp(Main.Theta.get(no_parameters-1,0));
    }

    public double target (final Matrix x)
    {
	Matrix theta = new Matrix(no_covariates,1);
	theta.setMatrix(0,no_covariates-1,0,0,x);

	double y = Math.exp(x.get(no_parameters-1,0));
	compute_DISPINV(y);

	return
	    -0.5*(Y.minus(X.times(theta)).transpose().times(DISPINV).times(Y.minus(X.times(theta))).get(0,0))
	    - 0.5*DISP_log_det - b/y - (a+1)*Math.log(y);
    }	

    public double target (final double x)
    {
	return 0;
    }
    

    public double target (final double x, final int j)
    {
	return 0;
    }

    public double proposal (double x, double y, double scale)
    {
	return 0;
    }

    public double rproposal (double x, double scale)
    {
	return 0;
    }

}


