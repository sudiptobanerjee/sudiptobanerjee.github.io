
source("~/RPrograms/gibbs.R")

BURNIN <- 1000
THIN <- 1

out <- gibbs.sample("../Output.txt", BURNIN, THIN)
parameters.qnt <- param.quantiles(out)

Y <- read.table("../Y_12.txt",header=F)
X <- read.table("../X2.txt",header=F)

simple.lm <- lm(Y[,1] ~ X[,2]+X[,3]+X[,4])
simple.lm.summary <- summary(simple.lm)
 
