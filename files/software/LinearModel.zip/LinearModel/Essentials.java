/*
 * Essentials.java
 *
 * Created on December 9, 2002, 8:58 AM
 */

import StatPack.Jama.*;
import StatPack.MyIO.*;
import java.io.*;
import java.util.StringTokenizer;

/**
 *
 * @author  sudiptob
 */
public class Essentials {
    
    /** Creates a new instance of Essentials */
    public Essentials() {
    }
    
    /** Create objects for use in this class **/
    static Matrix Y = new Matrix(Main.N,1);
    static Matrix X = new Matrix(Main.N, Main.no_covariates);
    static Matrix t_X = new Matrix(Main.no_covariates, Main.N);
    static Matrix DISP = new Matrix(Main.N, Main.N), DISPINV = new Matrix(Main.N,Main.N);
    
       static double DISP_determinant;
    
    /** Method to read data **/
    public static void read_data ()
    {

	File fin = new File("X2.txt");
        fileinput.readmatrix(fin, X);
	t_X = X.transpose();
        
        File fin2 = new File("Y_12.txt");
        fileinput.readmatrix(fin2,Y);
        
    }

    /** Method to initialize Gibbs parameters **/
    public static void startvals ()
    {

	for(int i=0; i< Main.no_covariates; i++) {
		Main.beta.set(i,0, 0.0);
		Main.beta_mean.set(i,0, 0.0);
	}
	Main.sigmasq = 1.0;
}

/** Method to compute DISP and DISP_INV **/
    
public static void compute_DISPINV ()
{

	for (int i = 0; i < Main.N; i++) {
		DISP.set(i,i, Main.sigmasq);
		for (int j = i+1; j < Main.N; j++) {
			DISP.set(i,j, Main.sigmasq*0.0);
			DISP.set(j,i, DISP.get(i,j));
		}
	}

	DISPINV = DISP.inverse();

	DISP_determinant = DISP.log_det();
}

/** Methods to compute full-conditional mean for beta (general)**/
public static void compute_beta_mean ()
{
 Main.beta_mean = Main.beta_disp.times(t_X).times(DISPINV).times(Y);
}

public static void set_beta_mean ()
{
 Main.beta_mean = Main.beta_disp.times(t_X).by(Main.sigmasq).times(Y);
}

/** Methods to compute full-conditional dispersion for beta (general)**/
public static void compute_beta_disp ()
{
 Main.beta_disp = t_X.times(DISPINV).times(X).inverse();
}

public static void set_beta_disp ()
{
 Main.beta_disp = t_X.times(X).inverse().times(Main.sigmasq);
}

public static double compute_quad ()
{
	double quad;
       
        quad = (Y.minus(X.times(Main.beta))).transpose().times(DISPINV).
                times(Y.minus(X.times(Main.beta))).get(0,0);
	quad *= Main.sigmasq;
        return quad;
}

public static double set_quad ()
{
 double quad = 
 (Y.minus(X.times(Main.beta))).transpose().times(Y.minus(X.times(Main.beta))).get(0,0);

 return quad;
}
}
