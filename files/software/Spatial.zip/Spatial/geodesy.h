#ifndef GEODESY_H
#define GEODESY_H

#include "lapack.h"

#define R 6371
#define pi 3.141593

void geodeticdistance(matrix &D, const matrix &LatLongi, int NSITES);
void geodeticdistance(matrix &D, const matrix &LatLongi);
double distonearth(vector point1, vector point2);
void euclideandistance (matrix &D, const matrix &LOC, int NSITES);
void euclideandistance (matrix &D, const matrix &LOC);
double distonplane(vector point1, vector point2);
double no_curvature_distance (const vector &point1, const vector &point2);
void no_curvature_distance (matrix &D, const matrix &LOC);
int check_identical_points (const matrix &D);
void identify_identical_points (const matrix &D);

#endif

