#ifndef AREAL_H
#define AREAL_H

#include "lapack.h"

void customize_neighborhood (int **neighborhood, const int num_regions, const int max_neighbors);
void compute_CAR (int **b, int **neighborhood, const int num_regions, const int max_neighbors);
void neighbor_means (vector &means, int **neighborhood, const vector &spatial_effects,
					 const int num_regions, const int max_neighbors);
void compute_no_neighbors (int *no_neighbors, int **neighborhood, const int num_regions,
						   const int max_neighbors);
void adjacency (int **adj, int **neighborhood, const int num_regions, const int max_neighbors);
void adjacency_scaled (matrix &adj, int **neighborhood, const int num_regions, const int max_neighbors);
void adjacency_general (int **adj, int **neighborhood, const int num_regions, const int max_neighbors);
void CAR_general (matrix &b, const matrix &C, const matrix &MINV);
void MCAR_separable (matrix &out, const matrix &Lambda, const matrix &Adj);
void MCAR_non_separable (matrix &out, const matrix &Lambda, const matrix &BlockAdj);
void Is_Symmetry (int **adj, const int num_regions);

#endif
