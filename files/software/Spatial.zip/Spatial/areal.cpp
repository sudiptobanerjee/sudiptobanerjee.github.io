#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <cmath>
#include "areal.h"

extern FILE *fdbg, *ferr;

using namespace std;

void customize_neighborhood (int **neighborhood, const int num_regions, const int max_neighbors)
{
	int i, j;

	for (i = 0; i < num_regions; i++) {
		for (j = 0; j < max_neighbors; j++) neighborhood[i][j] --;
	}
}

void compute_CAR (int **b, int **neighborhood, const int num_regions, const int max_neighbors)
{
	int i, j, k, count;

	for (i = 0; i < num_regions; i++) {
		count = 0;
		for (j = 0; j < max_neighbors; j++) {
			if (neighborhood[i][j] >= 0) count ++;
		}
		b[i][i] = count;

		for (k = i+1; k < num_regions; k++) {
			b[i][k] = 0; b[k][i] = 0;
				for (j = 0; j < max_neighbors; j++) {
					if (k == neighborhood[i][j]) b[i][k] = - 1;
				}
				b[k][i] = b[i][k];
		}
	}
}

void neighbor_means (vector &means, int **neighborhood, const vector &spatial_effects,
                   const int num_regions, const int max_neighbors)
{
	int i, j, k, count;
	double sum;

	for (i = 0; i < num_regions; i++) {
		count = 0;
		sum = 0.0;
		for (j = 0; j < max_neighbors; j++) {
			if (neighborhood[i][j] >= 0) {
				count ++;
				k = neighborhood[i][j];
				sum += spatial_effects.a[k];
			}
			else break;
		}
		means[i] = sum / count;
	}

}

void compute_no_neighbors (int *no_neighbors, int **neighborhood, const int num_regions,
						   const int max_neighbors)
{
	int i, j, count = 0;

	for (i = 0; i < num_regions; i++) {
		count = 0;
		for (j = 0; j < max_neighbors; j++) {
			if (neighborhood[i][j] >= 0) count ++;
			else break;
		}
		no_neighbors[i] = count;
	}
}

void adjacency (int **adj, int **neighborhood, const int num_regions, const int max_neighbors)
{
	int i, j, k;

	for (i = 0; i < num_regions; i++) {
		adj[i][i] = 0;
		for (k = i+1; k < num_regions; k++) {
			adj[i][k] = 0; adj[k][i] = 0;
				for (j = 0; j < max_neighbors; j++) {
					if (k == neighborhood[i][j]) adj[i][k] = 1;
				}
				adj[k][i] = adj[i][k];
		}
	}
}

void adjacency_scaled (matrix &adj, int **neighborhood, const int num_regions, const int max_neighbors)
{
	int i, j, k, *count;

	count = create_vector (num_regions);

	compute_no_neighbors (count, neighborhood, num_regions, max_neighbors);

	for (i = 0; i < num_regions; i++) {
		adj(i,i) = 0;
		for (k = i+1; k < num_regions; k++) {
			adj(i,k) = 0; adj(k,i) = 0;
				for (j = 0; j < max_neighbors; j++) {
					if (k == neighborhood[i][j]) {
						adj(i,k) = 1.0 / count[i];
						adj(k,i) = 1.0 / count[k];
					}
				}
		}
	}

	free (count);
}

void adjacency_general (int **adj, int **neighborhood, const int num_regions, const int max_neighbors)
{
	int i, j, k;

	for (i = 0; i < num_regions; i++) {
		adj[i][i] = 0;
		for (k = 0; k < num_regions; k++) {
			adj[i][k] = 0;
				for (j = 0; j < max_neighbors; j++) {
					if (k == neighborhood[i][j]) adj[i][k] = 1;
				}
		}
	}
}

void CAR_general (matrix &b, const matrix &C, const matrix &MINV)
{
	int i, j, num_regions = C.ncols;
	matrix I(num_regions, num_regions);

	for (i = 0; i < num_regions; i++) {
		I(i,i) = 1.0;
		for (j = i+1; j < num_regions; j++) {
			I(i,j) = 0.0;
			I(j,i) = 0.0;
		}
	}
        b = MINV*(I - C);
}

//Separable MCAR
void MCAR_separable (matrix &out, const matrix &Lambda, const matrix &Adj)
{
 out = Lambda % Adj;
}

//In the following: BlockAdj = BlockDiag(A1,A2,..,An), where each Ai is an output from
//   CAR_general
void MCAR_non_separable (matrix &out, const matrix &Lambda, const matrix &BlockAdj)
{
 matrix A(BlockAdj.nrows,BlockAdj.ncols);

 A = chol(BlockAdj);

 int n = (int) BlockAdj.ncols/Lambda.ncols;

 out = A*(Lambda%I(n))*transpose(A);
}

void Is_Symmetry (int **adj, const int num_regions)
{
	int i, j, SIGNAL = 0;

	for (i = 0; i < num_regions; i++) {
		for (j = i+1; j < num_regions; j++) {
			if (adj[i][j] == adj[j][i]) continue;
			else {
				SIGNAL++;
				cout << "WARNING: Assymetry found in Adj["<<i+1<<"]["<<j+1<<"]" << endl;
			}
		}
	}
	if (SIGNAL != 0) {
        cout << "Error in distribution of sites: Program exits";
        exit(0);
        }
}
