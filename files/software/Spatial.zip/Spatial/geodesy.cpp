#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "geodesy.h"

extern FILE *fdbg, *ferr;

using namespace std;

void geodeticdistance(matrix &D, const matrix &LatLongi,int NSITES)
{
	int i, j;
	double temp;
	vector Latrad(NSITES), Longrad(NSITES);

	for (i = 0; i < NSITES; i++) {
		Latrad.a[i] = LatLongi.a[i][1] * pi / 180;
		Longrad.a[i] = LatLongi.a[i][0] * pi / 180;
	}

	for (i = 0; i < NSITES; i++) {
		D.a[i][i] = 0.0;
		for (j = i+1; j < NSITES; j++) {
                    temp = sin(Latrad.a[i])*sin(Latrad.a[j])
                        + cos(Latrad.a[i])*cos(Latrad.a[j])*cos(fabs(Longrad.a[i]-Longrad.a[j]));
                    D.a[i][j] = R*acos(temp);
                    if (D.a[i][j] < 0.0000001) D.a[i][j] = 0.0;
                    else D.a[i][j] = D.a[i][j];
                    D.a[j][i] = D.a[i][j];
		}
	}

	D.a[NSITES-1][NSITES-1] = 0.0;

}

void geodeticdistance(matrix &D, const matrix &LatLongi)
{
	int i, j, NSITES = LatLongi.nrows;
	double temp;
	vector Latrad(NSITES), Longrad(NSITES);

	for (i = 0; i < NSITES; i++) {
		Latrad.a[i] = LatLongi.a[i][1] * pi / 180;
		Longrad.a[i] = LatLongi.a[i][0] * pi / 180;
	}

	for (i = 0; i < NSITES; i++) {
		D.a[i][i] = 0.0;
		for (j = i+1; j < NSITES; j++) {
                    temp = sin(Latrad.a[i])*sin(Latrad.a[j])
                        + cos(Latrad.a[i])*cos(Latrad.a[j])*cos(fabs(Longrad.a[i]-Longrad.a[j]));
                    D.a[i][j] = R*acos(temp);
                    if (D.a[i][j] < 0.0000001) D.a[i][j] = 0.0;
                    else D.a[i][j] = D.a[i][j];
                    D.a[j][i] = D.a[i][j];
		}
	}

	D.a[NSITES-1][NSITES-1] = 0.0;

}

double distonearth(vector point1, vector point2)
{
	int i;
	double distance;
	vector p1rad(2), p2rad(2);

	for (i = 0; i < 2; i++) {
            p1rad.a[i] = point1.a[i] * pi / 180;
            p2rad.a[i] = point2.a[i] * pi / 180;
	}

	distance = sin(p1rad.a[1])*sin(p2rad.a[1])
		+ cos(p1rad.a[1])*cos(p2rad.a[1])*cos(fabs(p1rad.a[0]-p2rad.a[0]));
	distance = R*acos(distance);

	return distance;
}

void euclideandistance (matrix &D, const matrix &LOC, int NSITES)
{
     int i, j, dim = LOC.ncols;
     vector diff(dim), point1(dim), point2 (dim);

     for (i = 0; i < NSITES; i++)
     {
	D(i,i) = 0.0;
	point1 = LOC[i];
	//        copy(point1.a, LOC.a[i], dim);
	for (j = i+1; j < NSITES; j++)
        {
	  point2 = LOC[j];
	  //            copy(point2.a, LOC.a[j], dim);
            diff = point1 - point2;
            D(i,j) = sqrt(diff*diff);
            if (D(i,j) < 1.0E-15) D(i,j) = 0.0;
	    else D(i,j) = D(i,j);
	    D(j,i) = D(i,j);
	}
     }
}

void euclideandistance (matrix &D, const matrix &LOC)
{
     int i, j, dim = LOC.ncols, NSITES = LOC.nrows;
     vector diff(dim), point1(dim), point2 (dim);

     for (i = 0; i < NSITES; i++)
     {
       D(i,i) = 0.0;
       point1 = LOC[i];
	for (j = i+1; j < NSITES; j++)
        {
            point2 = LOC[j];
            diff = point1 - point2;
            D(i,j) = sqrt(diff*diff);
            if (D(i,j) < 1.0E-15) D(i,j) = 0.0;
	    else D(i,j) = D(i,j);
	    D(j,i) = D(i,j);
	}
     }
}

double distonplane(vector point1, vector point2)
{
       double distance;
       int dim = point1.length;
       vector diff (dim);

       diff = point1 - point2;

       distance = sqrt (diff*diff);

       return distance;
}

double no_curvature_distance (const vector &point1, const vector &point2)
{
	int i;
	double distance;
	vector p1rad(2), p2rad(2);

	for (i = 0; i < 2; i++) {
            p1rad.a[i] = point1.a[i] * pi / 180;
            p2rad.a[i] = point2.a[i] * pi / 180;
	}

	distance = R*distonplane (p1rad, p2rad);

	return distance;
}

void no_curvature_distance (matrix &D, const matrix &LOC)
{
	int NSITES = LOC.nrows;
	matrix temp(NSITES, NSITES);

	temp = LOC * R * pi / 180;

	euclideandistance (D, temp, NSITES);
}

int check_identical_points (const matrix &D)
{
 int i, j;

 for (i = 0; i < D.nrows; i++) {
     for (j = i+1; j < D.ncols; j++) {
         if (D(i,j) < 0.000000001) return 1;
     }
 }
 return 0;
}

void identify_identical_points (const matrix &D)
{
 int i, j, Count = 0;

 for (i = 0; i < D.nrows; i++) {
     for (j = i+1; j < D.ncols; j++) {
         if (D(i,j) < 0.000000001) {
            cout << "Identical sites: " << i+1 <<" "<< j+1 << endl;
            Count++;
         }
     }
 }
 if (Count > 0) {
    cout << "Number of identical pairs: " << Count << endl;
    cout << "Return to exit: ";
    cout << getchar();
    exit(0);
 }
}


