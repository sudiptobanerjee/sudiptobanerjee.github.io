/****** This program is written for the order-free MCAR model            ***********/
/****** Here I fit a trivariate cancer data from Minnesita counties      ***********/
/******               V1.0 on Oct. 12, 2004                              ***********/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "matrix.h"
//#include "arms.h"
#include "generator.h"
#include "mcar.h"
#include <R.h>
#include <Rmath.h>


/******* Since p=3, there are six alphas, and six lamdas       ******************************/

extern double gbeta1, gbeta2, gbeta3, *Y1, *Y2, *Y3, *phi1, *phi2, *phi3, lamda1,lamda2, lamda3, lamda4, lamda5, lamda6;
extern double **D, **C,  *N1, *N2, *N3, *alpha, *eta, *theta, *eigen1;


void read_data (void)
{
	int i, j;

	FILE *fin;

	fin=fopen("neighbor1.txt", "r");
	for (i = 0; i < no_regions; i++) {
		for (j = 0; j < no_regions; j++) fscanf (fin, "%lf", &D[i][j]);

	}
	fclose(fin);

	fin=fopen("neighbor2.txt", "r");
	for (i = 0; i < no_regions; i++) {
		for (j = 0; j < no_regions; j++) fscanf (fin, "%lf", &C[i][j]);

    }
	fclose(fin);

}



void global_memory (void)
{
	Y1 = create_vectord (N);
	Y2 = create_vectord (N);
	Y3 = create_vectord (N);
	C= create_matrixd (no_regions, no_regions);
	D = create_matrixd (no_regions, no_regions);
	phi1 =create_vectord(no_regions);
	phi2 =create_vectord (no_regions);
	phi3 =create_vectord (no_regions);
	N1 = create_vectord (N);
	N2 = create_vectord (N);
	N3 = create_vectord (N);
	eta= create_vectord(p);
	theta= create_vectord(p);
	alpha= create_vectord (2*p);
	eigen1= create_vectord(no_regions);


}


void start_vals (double *Y10,double *Y20, double *Y30, double *N10,double *N20,double *N30, double *beta0,
                 double *phi10, double *phi20,double *phi30,double *lamda0, double *eta0,double *theta0,
				 double *eigen10)
{
	int i;
	double *alpha0;
	alpha0= create_vectord (2*p);

   	for (i = 0; i < no_regions; i++)
	 {
		phi1[i]=phi10[i];
		phi2[i]=phi20[i];
		phi3[i]=phi30[i];
		eigen1[i]=eigen10[i];

	 }

	 for (i = 0; i < N; i++)
	 {
		Y1[i]=Y10[i];
		Y2[i]=Y20[i];
		Y3[i]=Y30[i];
		N1[i]=N10[i];
		N2[i]=N20[i];
		N3[i]=N30[i];

	 }


	gbeta1= beta0[0];
	gbeta2= beta0[1];
	gbeta3= beta0[2];

	eta[0]=eta0[0];
	eta[1]=eta0[1];
	eta[2]=eta0[2];
	theta[0]=theta0[0];
	theta[1]=theta0[1];
	theta[2]=theta0[2];


	lamda1=lamda0[0];
	lamda2=lamda0[1];
	lamda3=lamda0[2];
	lamda4=lamda0[3];
	lamda5=lamda0[4];
	lamda6=lamda0[5];

	alphafun(alpha0, theta0, eta0);

	alpha[0]=alpha0[0]; alpha[1]=alpha0[1];alpha[2]=alpha0[2];
    alpha[3]=alpha0[3]; alpha[4]=alpha0[4];alpha[5]=alpha0[5];

	Free(alpha0);

}




void alphafun( double *xalpha, double *xtheta, double *xeta)
{

 double **P1, **P2, **P3, **temp1, **temp3, **temp2, **temp4, **temp5, **temp6;

 P1=create_matrixd(p, p);
 P2=create_matrixd(p, p);
 P3=create_matrixd(p, p);
 temp1=create_matrixd(p, p);
 temp2=create_matrixd(p, p);
 temp3=create_matrixd(p, p);
 temp4=create_matrixd(p, p);
 temp5=create_matrixd(p, p);
 temp6=create_matrixd(p, p);


 P1[0][0]=cos(M_PI/2.0*xtheta[0]); P1[0][1]=sin(M_PI/2.0*xtheta[0]); P1[0][2]=0;
 P1[1][0]=(-1)*sin(M_PI/2.0*xtheta[0]); P1[1][1]=cos(M_PI/2.0*xtheta[0]); P1[1][2]=0;
 P1[2][0]=0; P1[2][1]=0; P1[2][2]=1;

 P2[0][0]=cos(M_PI/2.0*xtheta[1]); P2[0][2]=sin(M_PI/2.0*xtheta[1]); P2[0][1]=0;
 P2[2][0]=(-1)*sin(M_PI/2.0*xtheta[1]); P2[2][2]=cos(M_PI/2.0*xtheta[1]); P2[2][1]=0;
 P2[1][0]=0; P2[1][1]=1; P2[1][2]=0;

 P3[1][1]=cos(M_PI/2.0*xtheta[2]); P3[1][2]=sin(M_PI/2.0*xtheta[2]); P3[1][0]=0;
 P3[2][1]=(-1)*sin(M_PI/2.0*xtheta[2]); P3[2][2]=cos(M_PI/2.0*xtheta[2]); P3[2][0]=0;
 P3[0][0]=1; P3[0][1]=0; P3[0][2]=0;

 matpr (temp1, P1, P2, p, p, p);
 matpr (temp2, temp1, P3, p, p, p);

 temp3[0][0]=xeta[0]; temp3[0][1]=0; temp3[0][2]=0;
 temp3[1][0]=0; temp3[1][1]=xeta[1]; temp3[1][2]=0;
 temp3[2][0]=0; temp3[2][1]=0; temp3[2][2]=xeta[2];

 matpr (temp4, temp2, temp3, p, p, p);

 transpose(temp5, temp2, p, p);

 matpr (temp6, temp4, temp5, p, p, p);

 xalpha[0]=temp6[0][0]; xalpha[1]=temp6[0][1]; xalpha[2]=temp6[0][2];
 xalpha[3]=temp6[1][1]; xalpha[4]=temp6[1][2]; xalpha[5]=temp6[2][2];

 freematd(temp1, p, p);
 freematd(temp2, p, p);
 freematd(temp3, p, p);
 freematd(temp4, p, p);
 freematd(temp5, p, p);
 freematd(temp6, p, p);
 freematd(P1, p, p);
 freematd(P2, p, p);
 freematd(P3, p, p);

}


double target_beta1(double x)

{
 double sum=0;
 int i;

 for( i=0; i<no_regions; i++)
  {
   sum=sum+Y1[i]*x - N1[i]*exp(x+ lamda1*phi1[i]+lamda2*phi2[i]+ lamda3*phi3[i]);

 }
return(sum);

 }



double target_beta2(double x)

{
 double sum=0;
 int i;

 for( i=0; i<no_regions; i++)
  {
   sum=sum+Y2[i]*x - N2[i]*exp(x+lamda4*phi2[i]+ lamda5*phi3[i]);

 }
return(sum);

 }


double target_beta3(double x)

{
 double sum=0;
 int i;

 for( i=0; i<no_regions; i++)
  {
   sum=sum+Y3[i]*x - N3[i]*exp(x+ lamda6*phi3[i]);

 }
return(sum);

 }




double target_phi1(double x, int k)
{
   int  j;
   double sum=0, sum1 = 0.0, sum2 = 0.0;

	 for (j=0; j<no_regions; j++)
	  {

		sum1=sum1+C[j][k]*(phi2[j])*alpha[1]*2 + C[j][k]*(phi3[j])*alpha[2]*2;
		sum2=sum2+C[j][k]*(phi1[j])*alpha[0]*2;


	  }

	sum=Y1[k]*(lamda1*x)-N1[k]*exp(gbeta1+ lamda1*x+lamda2*phi2[k] + lamda3*phi3[k]);
	sum=sum	-0.5*(x*x*D[k][k] - sum2*x- sum1*x);

   return (sum);

 }




double target_phi2(double x, int k)
{
   int  j;
   double sum=0, sum1 = 0.0, sum2 = 0.0;

	 for (j=0; j<no_regions; j++)
	  {
		sum1=sum1+C[j][k]*(phi1[j])*alpha[1]*2+C[j][k]*(phi3[j])*alpha[4]*2;
		sum2=sum2+C[j][k]*(phi2[j])*alpha[3]*2;

	  }

	sum=Y2[k]*(lamda4*x)-N2[k]*exp(gbeta2+ lamda4*x + lamda5*phi3[k] ) + Y1[k]*(lamda2*x)-N1[k]*exp(gbeta1+
	         lamda1*phi1[k]+ lamda2*x + lamda3*phi3[k]) ;
	sum=sum	- 0.5*(x*x*D[k][k] - sum2*x - sum1*x);

   return (sum);

 }



 double target_phi3(double x, int k)
{
   int  j;
   double sum=0, sum1 = 0.0, sum2 = 0.0;

	 for (j=0; j<no_regions; j++)
	  {
		sum1=sum1+C[j][k]*(phi1[j])*alpha[2]*2+C[j][k]*(phi2[j])*alpha[4]*2;
		sum2=sum2+C[j][k]*(phi3[j])*alpha[5]*2;

	  }

	sum=Y2[k]*(lamda5*x)-N2[k]*exp(gbeta2+ lamda4*phi2[k] + lamda5*x) + Y1[k]*(lamda3*x)-N1[k]*exp(gbeta1+
	          lamda1*phi1[k]+lamda2*phi2[k] + lamda3*x) + Y3[k]*(lamda6*x)-N3[k]*exp(gbeta3+ lamda6*x);
	sum=sum	- 0.5*(x*x*D[k][k] - sum2*x-sum1*x);

   return (sum);

 }


double target_lamda(double *x)

{
 double sum=0, **A, **tA, **AtA, **invA, y;
 int i;

 for( i=0; i<no_regions; i++)
  {
   sum=sum+Y1[i]*(x[0]*phi1[i]+ x[1]*phi2[i]+ x[2]*phi3[i]) - N1[i]*exp(gbeta1+x[0]*phi1[i]+
       x[1]*phi2[i]+ x[2]*phi3[i]);
   sum=sum + Y2[i]*(x[3]*phi2[i] + x[4]*phi3[i]) - N2[i]*exp(gbeta2+x[3]*phi2[i]+ x[4]*phi3[i]);
   sum=sum + Y3[i]*(x[5]*phi3[i]) - N3[i]*exp(gbeta3+x[5]*phi3[i]);
 }

 A = create_matrixd (p, p);
 tA = create_matrixd (p, p);
 AtA = create_matrixd (p, p);
 invA = create_matrixd (p, p);

 A[0][0]=x[0];  A[0][1]=x[1];  A[0][2]=x[2];
 A[1][0]=0;  A[1][1]=x[3]; A[1][2]=x[4];
 A[2][0]=0; A[2][1]=0; A[2][2]=x[5];

 transpose(tA, A, p, p);
 matpr(AtA, A, tA, p, p ,p);
 inverse(invA, p, AtA);

 y=b1*trace(invA, p);

 sum=sum - (a1+4)*log(x[0]*x[3]*x[5]) - 0.5*y + 3*log(x[5])+ 2*log(x[3]) + log(x[0]);

 freematd(A, p, p);
 freematd(tA, p, p);
 freematd(AtA, p, p);
 freematd(invA, p, p);

return(sum);

 }





double target_alpha1(double *x, double *z)

{
 double *temp1, *temp2, *temp3;
 double determ, y, sum=0;
 int i, j;

 determ=0;
 for (j=0; j<p; j++)
	  {  for (i=0; i<no_regions; i++) determ=determ + log(1- eigen1[i]*x[j]);

      }

 temp1=create_vectord(no_regions);
 temp2=create_vectord(no_regions);
 temp3=create_vectord(no_regions);

 for (i=0; i<no_regions; i++)
    { temp1[i]=phi1[i]; temp2[i]=phi2[i];temp3[i]=phi3[i]; }

 sum=0;
 for( i=0; i<no_regions; i++)
	{ for (j=0; j<no_regions; j++)
      {
		sum=sum+ temp1[i]*temp1[j]*C[i][j]*z[0] + temp2[i]*temp2[j]*C[i][j]*z[3]+
		         temp3[i]*temp3[j]*C[i][j]*z[5]+ temp1[i]*temp2[j]*C[i][j]*z[1]*2 +
				 temp1[i]*temp3[j]*C[i][j]*z[2]*2 + temp2[i]*temp3[j]*C[i][j]*z[4]*2;


       }
    }

 y=0.5*determ+0.5*sum ;

 Free(temp1);
 Free(temp2);
 Free(temp3);

 return(y);

 }


 double target_alpha2(double *z)

{
 double *temp1, *temp2, *temp3;
 double y, sum=0;
 int i, j;

 temp1=create_vectord(no_regions);
 temp2=create_vectord(no_regions);
 temp3=create_vectord(no_regions);

 for (i=0; i<no_regions; i++)
    { temp1[i]=phi1[i]; temp2[i]=phi2[i]; temp3[i]=phi3[i]; }

 sum=0;
 for( i=0; i<no_regions; i++)
	{ for (j=0; j<no_regions; j++)
      {
		sum=sum+ temp1[i]*temp1[j]*C[i][j]*z[0] + temp2[i]*temp2[j]*C[i][j]*z[3]+
		         temp3[i]*temp3[j]*C[i][j]*z[5]+ temp1[i]*temp2[j]*C[i][j]*z[1]*2 +
				 temp1[i]*temp3[j]*C[i][j]*z[2]*2 + temp2[i]*temp3[j]*C[i][j]*z[4]*2;


       }
    }

 y=0.5*sum ;

 Free(temp1);
 Free(temp2);
 Free(temp3);

 return(y);

 }


double metroplis_beta1(double x_prev, double scale)
{
 double lgratio=0, u ,y, z,  temp1=0, temp2=0;

 u=unif_rand( );

 y=x_prev+scale*norm_rand( );

 temp1=target_beta1(y);
 temp2=target_beta1(x_prev);
 lgratio=temp1-temp2;


 if (u>0)
   {
     if (lgratio>=log(u))  { z= y; }
       else { z=x_prev;}
   }
 else { z=x_prev;}

  return(z);

}


double metroplis_beta2(double x_prev, double scale)
{
 double lgratio=0, u ,y, z,  temp1=0, temp2=0;

 u=unif_rand( );
 y=x_prev+scale*norm_rand( );
 temp1=target_beta2(y);
 temp2=target_beta2(x_prev);
 lgratio=temp1-temp2;


 if (u>0)
   {
     if (lgratio>=log(u))  { z= y; }
       else { z=x_prev;}
   }
 else { z=x_prev;}

  return(z);

}


double metroplis_beta3(double x_prev, double scale)
{
 double lgratio=0, u ,y, z,  temp1=0, temp2=0;

 u=unif_rand( );
 y=x_prev+scale*norm_rand( );
 temp1=target_beta3(y);
 temp2=target_beta3(x_prev);
 lgratio=temp1-temp2;


 if (u>0)
   {
     if (lgratio>=log(u))  { z= y; }
       else { z=x_prev;}
   }
 else { z=x_prev;}

  return(z);

}




double metroplis_phi1(int j, double x_prev, double scale)
{
 double lgratio=0, u ,y, x=0, temp1=0, temp2=0;
 u=unif_rand( );
 y=x_prev+scale*norm_rand( );
 temp1=target_phi1(y, j);
 temp2=target_phi1(x_prev, j);
 lgratio=temp1-temp2;
 if (u>0)
     { if (lgratio>=log(u))  x=y;
        else x=x_prev;
      }
 else x=x_prev;
 return(x);

}


double metroplis_phi2(int j, double x_prev, double scale)
{
 double lgratio=0, u ,y, x=0, temp1=0, temp2=0;
 u=unif_rand( );
 y=x_prev+scale*norm_rand( );
 temp1=target_phi2(y, j);
 temp2=target_phi2(x_prev, j);
 lgratio=temp1-temp2;
 if (u>0)
     { if (lgratio>=log(u))  x=y;
        else x=x_prev;
      }
 else x=x_prev;
 return(x);

}


double metroplis_phi3(int j, double x_prev, double scale)
{
 double lgratio=0, u ,y, x=0, temp1=0, temp2=0;
 u=unif_rand( );
 y=x_prev+scale*norm_rand( );
 temp1=target_phi3(y, j);
 temp2=target_phi3(x_prev, j);
 lgratio=temp1-temp2;
 if (u>0)
     { if (lgratio>=log(u))  x=y;
        else x=x_prev;
      }
 else x=x_prev;
 return(x);

}



/*
double metroplis_lamda1(double x_prev, double scale)
{
 double lgratio=0, u ,y, newy, x, z,  temp1=0, temp2=0;

 u=unif_rand( );
 x=log(x_prev);
 y=x +scale*norm_rand( );
 newy=exp(y);

 temp1=target_lamda1(newy);
 temp2=target_lamda1(x_prev);
 lgratio=temp1-temp2 + y - x;
 if (u>0)
     {
        if (lgratio>=log(u) )  { z= newy; }
        else { z=x_prev;}
     }
 else { z=x_prev;}


 return(z);

}


double metroplis_lamda4(double x_prev, double scale)
{
 double lgratio=0, u ,y, newy, x, z,  temp1=0, temp2=0;

 u=unif_rand( );
 x=log(x_prev);
 y=x +scale*norm_rand( );
 newy=exp(y);
   temp1=target_lamda4(newy);
   temp2=target_lamda4(x_prev);
   lgratio=temp1-temp2 + y - x;
   if (u>0)
    {
      if (lgratio>=log(u) )  { z= newy; }
       else { z=x_prev;}
    }
   else { z=x_prev;}

 return(z);

}


double metroplis_lamda6(double x_prev, double scale)
{
 double lgratio=0, u ,y, newy, x, z,  temp1=0, temp2=0;

 u=unif_rand( );
 x=log(x_prev);
 y=x +scale*norm_rand( );
 newy=exp(y);
    temp1=target_lamda6(newy);
   temp2=target_lamda6(x_prev);
   lgratio=temp1-temp2+ y - x;
   if (u>0)
    {
      if (lgratio>=log(u) )  { z= newy; }
       else { z=x_prev;}
    }
   else { z=x_prev;}


 return(z);

}


double metroplis_lamda2(double x_prev, double scale)
{
 double lgratio=0, u ,y, z,  temp1=0, temp2=0;

 u=unif_rand( );

 y=x_prev + scale*norm_rand( );

 temp1=target_lamda2(y);
 temp2=target_lamda2(x_prev);

 lgratio=temp1-temp2;


 if (u>0)
   {
     if (lgratio>=log(u))  { z= y; }
       else { z=x_prev;}
   }
 else { z=x_prev;}

  return(z);

}


double metroplis_lamda3(double x_prev, double scale)
{
 double lgratio=0, u ,y, z,  temp1=0, temp2=0;

 u=unif_rand( );

 y=x_prev + scale*norm_rand( );

 temp1=target_lamda3(y);
 temp2=target_lamda3(x_prev);

 lgratio=temp1-temp2;


 if (u>0)
   {
     if (lgratio>=log(u))  { z= y; }
       else { z=x_prev;}
   }
 else { z=x_prev;}

  return(z);

}




double metroplis_lamda5(double x_prev, double scale)
{
 double lgratio=0, u ,y, z,  temp1=0, temp2=0;

 u=unif_rand( );

 y=x_prev + scale*norm_rand( );

 temp1=target_lamda5(y);
 temp2=target_lamda5(x_prev);

 lgratio=temp1-temp2;


 if (u>0)
   {
     if (lgratio>=log(u))  { z= y; }
       else { z=x_prev;}
   }
 else { z=x_prev;}

  return(z);

}
*/


void metroplis_lamda1(double *x_cur, double *x_prev, double *scale)
{
 double lgratio=0, u , *y, *x, *newy, temp1=0, temp2=0;
 int i;

 u=unif_rand( );
 y=create_vectord(2*p);
 newy=create_vectord(2*p);
 x=create_vectord(2*p);

 x[0]=log(x_prev[0]); x[1]=x_prev[1];x[2]=x_prev[2];
 x[3]=log(x_prev[3]); x[4]=x_prev[4];x[5]=log(x_prev[5]);

 y[0]=x[0] + scale[0]*norm_rand( );
 y[3]=x[3] + scale[1]*norm_rand( );
 y[5]=x[5] + scale[2]*norm_rand( );


 newy[0]=exp(y[0]);newy[3]=exp(y[3]);newy[5]=exp(y[5]);
 newy[1]=x_prev[1];  newy[2]=x_prev[2]; newy[4]=x_prev[4];

 temp1=target_lamda(newy);
 temp2=target_lamda(x_prev);

 lgratio=temp1-temp2 + y[0]- x[0] + y[3]- x[3] + y[5]- x[5];

 if (u>0)
   {
     if (lgratio>=log(u))  { for (i=0; i<(2*p); i++) x_cur[i]=newy[i]; }
       else { for (i=0; i<(2*p); i++) x_cur[i]=x_prev[i];}
   }
 else {for (i=0; i<(2*p); i++) x_cur[i]=x_prev[i];}

Free(y);
Free(newy);
Free(x);

}


void metroplis_lamda2(double *x_cur, double *x_prev, double *scale)
{
 double lgratio=0, u , *y, temp1=0, temp2=0;
 int i;

 u=unif_rand( );
 y=create_vectord(2*p);

 y[1]=x_prev[1] + scale[0]*norm_rand( );
 y[2]=x_prev[2] + scale[1]*norm_rand( );
 y[4]=x_prev[4] + scale[2]*norm_rand( );


 y[0]=x_prev[0]; y[3]=x_prev[3]; y[5]=x_prev[5];

 temp1=target_lamda(y);
 temp2=target_lamda(x_prev);

 lgratio=temp1-temp2;

 if (u>0)
   {
     if (lgratio>=log(u))  { for (i=0; i<(2*p); i++) x_cur[i]=y[i]; }
       else { for (i=0; i<(2*p); i++) x_cur[i]=x_prev[i];}
   }
 else {for (i=0; i<(2*p); i++) x_cur[i]=x_prev[i];}

Free(y);

}







void metroplis_alpha1(double *x_cur, double *x_prev, double *scale)
{
 double lgratio=0, u ,*y,  *logit_x, *logit_y;
 double temp1=0, temp2=0, sum=0, *newalpha,  *oldalpha;
 int i;
 /*double **tempmat1, **tempmat2, *value1, *value2;
 int *dim, k;

 k=p; dim=&k;

 tempmat1=create_matrixd(p, p);
 tempmat2=create_matrixd(p, p); */

 u=unif_rand( );
 logit_x=create_vectord(p);
 logit_y=create_vectord(p);
 y=create_vectord(p);

 for (i=0; i<p; i++)
  {
    logit_x[i]=log((1.19+x_prev[i])/(0.99-x_prev[i]));
    logit_y[i]=logit_x[i]+scale[i]*norm_rand( );
    y[i]=(0.99*exp(logit_y[i])-1.19)/(1+exp(logit_y[i]));
  }

 newalpha=create_vectord(2*p);
 oldalpha=create_vectord(2*p);

 alphafun(newalpha, theta, y);
 alphafun(oldalpha, theta, x_prev);

 /*tempmat1[0][0]=newalpha[0]; tempmat1[0][1]=newalpha[1];tempmat1[0][2]=newalpha[2];
 tempmat1[1][0]=newalpha[1]; tempmat1[1][1]=newalpha[3];tempmat1[1][2]=newalpha[4];
 tempmat1[2][0]=newalpha[2]; tempmat1[2][1]=newalpha[4];tempmat1[2][2]=newalpha[5];

 tempmat2[0][0]=oldalpha[0]; tempmat2[0][1]=oldalpha[1];tempmat2[0][2]=oldalpha[2];
 tempmat2[1][0]=oldalpha[1]; tempmat2[1][1]=oldalpha[3];tempmat2[1][2]=oldalpha[4];
 tempmat2[2][0]=oldalpha[2]; tempmat2[2][1]=oldalpha[4];tempmat2[2][2]=oldalpha[5];

 value1=create_vectord(p);
 value2=create_vectord(p);

 eigen(tempmat1, value1, dim, dim);
 eigen(tempmat2, value2, dim, dim);

 Rprintf("check eigenvalue\n");
 Rprintf("value1=, %lf, %lf, %lf\n", value1[0], value1[1], value1[2]);
 Rprintf("y=, %lf, %lf, %lf\n", y[0], y[1], y[2]);
 Rprintf("value2=, %lf, %lf, %lf\n", value2[0], value2[1], value2[2]);
 Rprintf("xprev=, %lf, %lf, %lf\n", x_prev[0], x_prev[1], x_prev[2]);

*/

 temp1=target_alpha1(y, newalpha);
 temp2=target_alpha1(x_prev, oldalpha);

 sum=0;
 for (i=0; i<p; i++)

    { sum=sum+log((1.19+y[i])*(0.99- y[i]))-log((1.19+x_prev[i])*(0.99-x_prev[i])) ;}

 lgratio=temp1-temp2+ sum ;


 if (u>0)
   { if (lgratio>=log(u))
       { for (i=0; i<p; i++) x_cur[i]=y[i];
	     alpha[0]=newalpha[0]; alpha[1]=newalpha[1];alpha[2]=newalpha[2];
		 alpha[3]=newalpha[3]; alpha[4]=newalpha[4];alpha[5]=newalpha[5];
	   }
     else  { for (i=0; i<p; i++)  x_cur[i]=x_prev[i]; }

   }
 else    { for (i=0; i<p; i++) x_cur[i]=x_prev[i]; }


 Free(y);
 Free(logit_x);
 Free(logit_y);
 Free(newalpha);
 Free(oldalpha);

 /*Free(value1);
  Free(value2);
  freematd(tempmat1, p, p);
   freematd(tempmat2, p, p); */



}


void metroplis_alpha2(double *x_cur, double *x_prev, double *scale)
{
 double lgratio=0, u ,*y,  *logit_x, *logit_y;
 double temp1=0, temp2=0, sum=0, *newalpha,  *oldalpha;
 int i;

 u=unif_rand( );
 logit_x=create_vectord(p);
 logit_y=create_vectord(p);
 y=create_vectord(p);

 for (i=0; i<p; i++)
  {
    logit_x[i]=log((1+x_prev[i])/(1-x_prev[i]));
    logit_y[i]=logit_x[i]+scale[i]*norm_rand( );
    y[i]=1*(exp(logit_y[i])-1)/(1+exp(logit_y[i]));
  }

 newalpha=create_vectord(2*p);
 oldalpha=create_vectord(2*p);

 alphafun(newalpha, y, eta);
 alphafun(oldalpha, x_prev, eta);

 temp1=target_alpha2(newalpha);
 temp2=target_alpha2(oldalpha);

 sum=0;
 for (i=0; i<p; i++)

    { sum=sum+log((1+y[i])*(1- y[i]))-log((1+x_prev[i])*(1-x_prev[i]));}

 lgratio=temp1-temp2+ sum ;


 if (u>0)
   { if (lgratio>=log(u))
       { for (i=0; i<p; i++) x_cur[i]=y[i];
	     alpha[0]=newalpha[0]; alpha[1]=newalpha[1];alpha[2]=newalpha[2];
		 alpha[3]=newalpha[3]; alpha[4]=newalpha[4];alpha[5]=newalpha[5];
	   }
     else  { for (i=0; i<p; i++)  x_cur[i]=x_prev[i]; }

   }
 else    { for (i=0; i<p; i++) x_cur[i]=x_prev[i]; }


 Free(y);
 Free(logit_x);
 Free(logit_y);
 Free(newalpha);
 Free(oldalpha);


}




double density(void)
{

   int i;
  double func=0.0, lnF ;


 for (i = 0; i < N; i++)
	{
	  func=func+Y1[i]*(gbeta1+lamda1*phi1[i]+ lamda2*phi2[i]+ lamda3*phi3[i]) - N1[i]*exp(gbeta1+
	       lamda1*phi1[i]+ lamda2*phi2[i]+ lamda3*phi3[i])+ Y2[i]*(gbeta2+ lamda4*phi2[i] +
		   lamda5*phi3[i]) - N2[i]*exp(gbeta2+lamda4*phi2[i] + lamda5*phi3[i])+
		   Y3[i]*(gbeta3+ lamda6*phi3[i]) - N3[i]*exp(gbeta3+ lamda6*phi3[i]);
    }

    lnF= (-2)*func;

    return (lnF);

}


/*double dtheta_fun (double *beta0_m, double *lamda0_m, double *phi10_m,
                    double *phi20_m, double *phi30_m)

{
   int i;
   double func=0.0, dtheta;
   for (i = 0; i < N; i++)
	{
	 func=func+Y1[i]*(beta0_m[0]+lamda0_m[0]*phi10_m[i]+ lamda0_m[1]*phi20_m[i]+ lamda0_m[2]*phi30_m[i]) -
	      N1[i]*exp(beta0_m[0]+lamda0_m[0]*phi10_m[i]+ lamda0_m[1]*phi20_m[i]+ lamda0_m[2]*phi30_m[i])+
	      Y2[i]*(beta0_m[1]+ lamda0_m[3]*phi20_m[i] + lamda0_m[4]*phi30_m[i]) -
		  N2[i]*exp(beta0_m[1]+ lamda0_m[3]*phi20_m[i] + lamda0_m[4]*phi30_m[i])+
		   Y3[i]*(beta0_m[2]+ lamda0_m[5]*phi30_m[i]) - N3[i]*exp(beta0_m[2]+ lamda0_m[5]*phi30_m[i]);
    }


   dtheta=(-2)*func;
   return (dtheta);

}
*/

double dtheta_fun (double *p1, double *p2, double *p3)

{
   int i;
   double func=0.0, dtheta;
   for (i = 0; i < N; i++)
	{
	 func=func+Y1[i]*log(p1[i]) - N1[i]*p1[i] +Y2[i]*log(p2[i]) - N2[i]*p2[i] +
	      Y3[i]*log(p3[i]) - N3[i]*p3[i];

    }


   dtheta=(-2)*func;
   return (dtheta);

}




