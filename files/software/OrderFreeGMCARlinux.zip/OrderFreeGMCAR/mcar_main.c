/****** This program is written for the order-free MCAR model            ***********/
/****** Here I fit a trivariate cancer data from Minnesita counties      ***********/
/******               V1.0 on Oct. 12, 2004                              ***********/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "matrix.h"
#include "generator.h"
#include "mcar.h"
#include <R.h>
#include <Rmath.h>

double gbeta1, gbeta2, gbeta3, *Y1, *Y2, *Y3, *phi1, *phi2, *phi3, lamda1,lamda2, lamda3, lamda4, lamda5, lamda6;
double **D, **C,  *N1, *N2, *N3, *alpha, *eta, *theta, *eigen1;



void mcar(  double *beta_f,double *phi1_f, double *phi2_f, double *phi3_f, double *alpha_f, double *lamda_f,
            double *Y10, double *N10, double *Y20, double *N20,double *Y30, double *N30, double *beta0,
			double *phi10, double *phi20, double *phi30, double *lamda0, double *eta0, double *theta0,
			double *eigen10, int *nstart, int *nend, int *count1, int *count2, int *count3,int *count4,int *count5,
			int *count6, double *betascale, double *phi1scale, double *phi2scale,double *phi3scale, double *lamscale1,
			double *lamscale2,double *etascale, double *thetascale, double *beta_m, double *phi1_m, double *phi2_m,
			double *phi3_m,double *alpha_m, double *lamda_m, double *p1_m, double *p2_m, double *p3_m, double *Dbar,
		    double *Dtheta)


{
	int i, j, m,n;

	double   *lamda_curr, *lamda_prev, *eta_curr, *eta_prev, *theta_curr, *theta_prev, x_prev, x, sumlnF=0;

    eta_curr=create_vectord(p);
	eta_prev=create_vectord(p);
	theta_curr=create_vectord(p);
	theta_prev=create_vectord(p);
	lamda_curr=create_vectord(2*p);
	lamda_prev=create_vectord(2*p);

	m=nend[0]-nstart[0];


	global_memory ();

    read_data ();




	start_vals (Y10, Y20, Y30, N10, N20, N30, beta0,phi10, phi20, phi30, lamda0,
	            eta0, theta0, eigen10);


	GetRNGstate( );

	for (i = 0; i < nend[0]; i++)
	{

	 Rprintf("GIBBS: %d\n", i+1);


/**** update beta  **********/


	 x_prev=gbeta1;
     x=metroplis_beta1(x_prev, betascale[0]);
     if (((x-x_prev)>0.00001 || (x_prev-x)>0.00001)  && i>=nstart[0]) count1[0]=count1[0]+1;
	 gbeta1=x;

	 x_prev=gbeta2;
     x=metroplis_beta2(x_prev, betascale[1]);
     if (((x-x_prev)>0.00001 || (x_prev-x)>0.00001)  && i>=nstart[0]) count1[1]=count1[1]+1;
	 gbeta2=x;

	 x_prev=gbeta3;
     x=metroplis_beta3(x_prev, betascale[2]);
     if (((x-x_prev)>0.00001 || (x_prev-x)>0.00001)  && i>=nstart[0]) count1[2]=count1[2]+1;
	 gbeta3=x;

	 if (i>=nstart[0])  { beta_f[(i-nstart[0])]=gbeta1;
      	                  beta_f[m+(i-nstart[0])]=gbeta2;
						  beta_f[2*m+(i-nstart[0])]=gbeta3;

		                }



/**** update phi  **********/

	 for (j=0; j<no_regions; j++)
	   {
	      x=metroplis_phi1(j, phi1[j], phi1scale[j]);
		  if (((x-phi1[j])>0.00001 || (phi1[j]-x)>0.00001)  && i>=nstart[0]) count2[j]=count2[j]+1;
	      phi1[j]=x;
          if (i>=nstart[0]) { n= m*j+i-nstart[0];
		                      phi1_f[n]=phi1[j];
							 }
	  	}


	 for (j=0; j<no_regions; j++)
	     {
	      x=metroplis_phi2(j, phi2[j], phi2scale[j]);
		  if (((x-phi2[j])>0.00001 || (phi2[j]-x)>0.00001)  && i>=nstart[0]) count3[j]=count3[j]+1;
	      phi2[j]=x;
          if (i>=nstart[0]) { n= m*j+i-nstart[0];
		                      phi2_f[n]=phi2[j];
							 }
	  	}

	 for (j=0; j<no_regions; j++)
	     {
	      x=metroplis_phi3(j, phi3[j], phi3scale[j]);
		  if (((x-phi3[j])>0.00001 || (phi3[j]-x)>0.00001)  && i>=nstart[0]) count4[j]=count4[j]+1;
	      phi3[j]=x;
          if (i>=nstart[0]) { n= m*j+i-nstart[0];
		                      phi3_f[n]=phi3[j];
							 }
	  	}

     lamda_prev[0]=lamda1; lamda_prev[1]=lamda2; lamda_prev[2]=lamda3;
	  lamda_prev[3]=lamda4; lamda_prev[4]=lamda5; lamda_prev[5]=lamda6;

     metroplis_lamda1(lamda_curr, lamda_prev, lamscale1);

	 if (((lamda_curr[0]-lamda_prev[0])>0.00001 ||(lamda_prev[0]-lamda_curr[0])>0.00001) && i>=nstart[0])
		               count5[0]=count5[0]+1;

	 lamda1=lamda_curr[0];
	 lamda2=lamda_curr[1];
     lamda3=lamda_curr[2];
	 lamda4=lamda_curr[3];
	 lamda5=lamda_curr[4];
     lamda6=lamda_curr[5];



	 lamda_prev[0]=lamda1; lamda_prev[1]=lamda2; lamda_prev[2]=lamda3;
	 lamda_prev[3]=lamda4; lamda_prev[4]=lamda5; lamda_prev[5]=lamda6;

     metroplis_lamda2(lamda_curr, lamda_prev, lamscale2);

	 if (((lamda_curr[1]-lamda_prev[1])>0.00001 ||(lamda_prev[0]-lamda_curr[0])>0.00001) && i>=nstart[0])
	               count5[1]=count5[1]+1;


	 lamda1=lamda_curr[0];
	 lamda2=lamda_curr[1];
     lamda3=lamda_curr[2];
	 lamda4=lamda_curr[3];
	 lamda5=lamda_curr[4];
     lamda6=lamda_curr[5];

/**** update lamda  **********/
     /*x_prev=lamda1*lamda1;
     x=metroplis_lamda1(x_prev, lamscale[0]);
     if (((x-x_prev)>0.00001 || (x_prev-x)>0.00001)  && i>=nstart[0]) count5[0]=count5[0]+1;
	 lamda1=sqrt(x);

	 x_prev=lamda2;
     x=metroplis_lamda2(x_prev, lamscale[1]);
     if (((x-x_prev)>0.00001 || (x_prev-x)>0.00001)  && i>=nstart[0]) count5[1]=count5[1]+1;
	 lamda2=x;

	 x_prev=lamda3;
     x=metroplis_lamda3(x_prev, lamscale[2]);
     if (((x-x_prev)>0.00001 || (x_prev-x)>0.00001)  && i>=nstart[0]) count5[2]=count5[2]+1;
	 lamda3=x;

	 x_prev=lamda4*lamda4;
     x=metroplis_lamda4(x_prev, lamscale[3]);
     if (((x-x_prev)>0.00001 || (x_prev-x)>0.00001)  && i>=nstart[0]) count5[3]=count5[3]+1;
	 lamda4=sqrt(x);

	 x_prev=lamda5;
     x=metroplis_lamda5(x_prev, lamscale[4]);
     if (((x-x_prev)>0.00001 || (x_prev-x)>0.00001)  && i>=nstart[0]) count5[4]=count5[4]+1;
	 lamda5=x;

	 x_prev=lamda6*lamda6;
     x=metroplis_lamda6(x_prev, lamscale[5]);
     if (((x-x_prev)>0.00001 || (x_prev-x)>0.00001)  && i>=nstart[0]) count5[5]=count5[5]+1;
	 lamda6=sqrt(x);*/




	 if (i>=nstart[0])  { lamda_f[(i-nstart[0])]=lamda1;
	                      lamda_f[m+(i-nstart[0])]=lamda2;
						  lamda_f[2*m+(i-nstart[0])]=lamda3;
						  lamda_f[3*m+(i-nstart[0])]=lamda4;
						  lamda_f[4*m+(i-nstart[0])]=lamda5;
						  lamda_f[5*m+(i-nstart[0])]=lamda6;
					     }


	 Rprintf("%lf, %lf, %lf, %lf, %lf, %lf\n", lamda1, lamda2, lamda3,lamda4, lamda5, lamda6);


/**** update alpha  **********/

    eta_prev[0]=eta[0]; eta_prev[1]=eta[1]; eta_prev[2]=eta[2];

     metroplis_alpha1(eta_curr, eta_prev, etascale);

	 if (((eta_curr[0]-eta_prev[0])>0.00001 ||(eta_prev[0]-eta_curr[0])>0.00001) && i>=nstart[0])
		               count6[0]=count6[0]+1;
	 eta[0]=eta_curr[0];
	 eta[1]=eta_curr[1];
     eta[2]=eta_curr[2];

     theta_prev[0]=theta[0]; theta_prev[1]=theta[1]; theta_prev[2]=theta[2];

     metroplis_alpha2(theta_curr, theta_prev, thetascale);

	 if (((theta_curr[0]-theta_prev[0])>0.00001 ||(theta_prev[0]-theta_curr[0])>0.00001) && i>=nstart[0])
		               count6[1]=count6[1]+1;
	 theta[0]=theta_curr[0];
	 theta[1]=theta_curr[1];
     theta[2]=theta_curr[2];

     if (i>=nstart[0])
            { alpha_f[i-nstart[0]]=alpha[0];
		      alpha_f[m+i-nstart[0]]=alpha[1];
              alpha_f[m*2+i-nstart[0]]=alpha[2];
			  alpha_f[3*m+i-nstart[0]]=alpha[3];
		      alpha_f[4*m+i-nstart[0]]=alpha[4];
              alpha_f[m*5+i-nstart[0]]=alpha[5];
            }

     Rprintf("alpha=%lf, %lf, %lf,%lf, %lf, %lf \n", alpha[0], alpha[1], alpha[2],
               alpha[3], alpha[4], alpha[5]);

if (i>=nstart[0])  sumlnF=sumlnF + density( );


// ending sampling

}


Free(lamda_curr);
Free(lamda_prev);
Free(eta_curr);
Free(eta_prev);
Free(theta_curr);
Free(theta_prev);
Free(eigen1);
Free(eta);
Free(theta);
Free(alpha);
freematd(C, no_regions, no_regions);
freematd(D, no_regions, no_regions);

//Calculate Dbar

Dbar[0]=sumlnF/m;

// Calculate Dtheta

for (i=0; i<m; i++)  {
                       beta_m[0]=beta_m[0]+ beta_f[i];
					   beta_m[1]=beta_m[1]+ beta_f[m+i];
					   beta_m[2]=beta_m[2]+ beta_f[2*m+i];

					 }

  beta_m[0]= beta_m[0]/m;
  beta_m[1]= beta_m[1]/m;
  beta_m[2]= beta_m[2]/m;


for (j=0; j<no_regions; j++)
 {  for (i=0; i<m; i++)
       { phi1_m[j]=phi1_m[j]+ phi1_f[j*m+i];
	     phi2_m[j]=phi2_m[j]+ phi2_f[j*m+i];
		 phi3_m[j]=phi3_m[j]+ phi3_f[j*m+i];
	   }
    phi1_m[j]= phi1_m[j]/m;
    phi2_m[j]= phi2_m[j]/m;
	phi3_m[j]= phi3_m[j]/m;
 }


for (j=0; j<(2*p); j++)
 { for (i=0; i<m; i++)  { alpha_m[j]=alpha_m[j]+ alpha_f[j*m+i];
                          lamda_m[j]=lamda_m[j]+ lamda_f[j*m+i];
						}
   alpha_m[j]= alpha_m[j]/m;
   lamda_m[j]= lamda_m[j]/m;


 }


for (j=0; j<no_regions; j++)
{ for (i=0; i<m; i++)
  { p1_m[j]=p1_m[j]+ exp(beta_f[i]+ lamda_f[i]*phi1_f[j*m+i]+
           lamda_f[m+i]*phi2_f[j*m+i]+ lamda_f[2*m+i]*phi3_f[j*m+i]);
	p2_m[j]=p2_m[j]+ exp(beta_f[m+i]+ lamda_f[3*m+i]*phi2_f[j*m+i]+
           lamda_f[4*m+i]*phi3_f[j*m+i]);
	p3_m[j]=p3_m[j]+ exp(beta_f[2*m+i] + lamda_f[5*m+i]*phi3_f[j*m+i]);
  }
  p1_m[j]= p1_m[j]/m;
  p2_m[j]= p2_m[j]/m;
  p3_m[j]= p3_m[j]/m;

}



//Dtheta[0]= dtheta_fun(beta_m, lamda_m, phi1_m, phi2_m, phi3_m);
Dtheta[0]= dtheta_fun(p1_m, p2_m, p3_m);


Free(Y1);
Free(Y2);
Free(Y3);
Free(N1);
Free(N2);
Free(N3);
Free(phi1);
Free(phi2);
Free(phi3);


PutRNGstate( );
}








