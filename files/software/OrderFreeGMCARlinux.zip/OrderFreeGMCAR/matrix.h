/* Header file for matrix2.c */

int *create_vector(int dim);
int **create_matrix (int row, int col);
double **create_matrixd (int row, int col);
double *create_vectord (int dim);
void freematd (double **a, int row, int col);
void freemat (int **a, int row, int col);

void matpr (double **c, double **a, double **b, int m, int p, int n);
void transpose (double **matrix, double **x, int rows, int cols);
void matsclpr (double **matrix, double a, double **b, int rows, int cols);
void matdiff (double **matrix, double **a, double **b, int rows, int cols);
void matsum (double **matrix, double **a, double **b, int rows, int cols);
double det (double **matrix, int dim);
double trace (double **a, int dim);
void Row_extract (double *row_vector, double **matrix, int row_no, int ncol);
void Col_extract (double *col_vector, double **matrix, int col_no, int nrow);
void vecprm (double **matrix, double *vector1, double *vector2, int rows, int cols);
void zero_mat(double **matrix, int rows, int cols);
void ident_mat(double **matrix, int dim);
void kroneckerprod(double **c, double **a, double **b,
					   int rowa, int cola, int rowb, int colb);
void sub_matrix (double **matrix, double **a, int rowa, int cola, int rowb, int colb);
void vecmatpr (double *vector, double **a, int rows, int cols, double *x);
double vecprs (double *vector1, double *vector2, int row);
void vectormat (double **matrix, double *vector, int nrow, int ncol);
void matvector (double *vector, double **matrix,int nrow, int ncol);
void matvecpr (double *vector, double **a, int rows, int cols, double *x);
void inverse (double **invertmat, int dim, double **matrix);
void cholcop(double **matrix, double **A, int dim);
void eigen(double **matrix, double *value, int*n, int *m);
void eigen2(double **matrix, double *value1, double *value2, int*n, int *m);
void Q(double **matrix, double **qy, double **y, int dim);
/*void cholcop2(double **matrix, double **A, int dim, int *index);*/


/* End of Header file */
