void rwishart (double **wishart, double **V, int dim, int n);
void multinormal (double *vector, double *mean, double **disp, int dim);

