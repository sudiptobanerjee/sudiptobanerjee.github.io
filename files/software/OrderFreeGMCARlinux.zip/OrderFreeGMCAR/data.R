A<-matrix(0, 3,3)
B<-matrix(0, 3,3)
count<-length(result$lamda[ ,1])
gamma<-matrix(0, count, 6)
lam<-matrix(0, count, 6)

for ( i in 1: count)
{
 A[1, 1]<-result$lamda[i, 1]
 A[1, 2]<-result$lamda[i, 2]
 A[1, 3]<-result$lamda[i, 3]
 A[2, 2]<-result$lamda[i, 4]
 A[2, 3]<-result$lamda[i, 5]
 A[3, 3]<-result$lamda[i, 6]
 A[2, 1]<-0
 A[3, 1]<-0
 A[3, 2]<-0
 
 #invA<-solve(A)
 #tinvA<-t(invA)
 LAMBDA<-A %*% t(A)

 
 lam[i, 1]<-LAMBDA[1,1]
 lam[i, 2]<-LAMBDA[1,2]
 lam[i, 3]<-LAMBDA[1,3]
 lam[i, 4]<-LAMBDA[2,2]
 lam[i, 5]<-LAMBDA[2,3]
 lam[i, 6]<-LAMBDA[3,3]


}



rho12<-lam[ ,2]/sqrt(lam[ ,1]*lam[ , 4])
rho13<-lam[ ,3]/sqrt(lam[ ,1]*lam[ , 6])
rho23<-lam[ ,5]/sqrt(lam[ ,4]*lam[ , 6])

