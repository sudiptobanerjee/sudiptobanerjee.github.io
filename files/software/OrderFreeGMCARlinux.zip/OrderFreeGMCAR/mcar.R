a <- read.table("newcancer.txt")
Y30 <- a$V1
N30<-a$V2
Y20<-a$V3
N20<-a$V4
Y10<-a$V5
N10<-a$V6

dyn.load("mcar_main.so")
set.seed(2000)
nstart<-20000
nend<-40000
m<-nend-nstart

beta0<-c(0, 0, 0)
lamda0<-c(0.1, 0.1, 0.1, 0.1, 0.1, 0.1)
eta0<-c(0.5, 0.5, 0.5)
#theta0<-c(0, 0, 0)
theta0<-c(0.5, 0.5, 0.5)
phi10<-rep(0, 87)
phi20<-rep(0, 87)
phi30<-rep(0, 87)


phi3scale<-rep(c(1.6, 0.8, 1.5, 2.9,1.5, 1.2, 1.8, 0.5, 2.4, 1.9, 2.3, 1.5, 1.9, 
                 1.5,0.9, 1.9, 1.5,1.2, 2.6,1.6, 1.2, 1.6, 1.6, 1.0,1.5, 1.1, 1.5),
                 c(1, 1, 13, 1, 2, 1, 7, 1, 1, 6, 1, 2, 2,  22, 1,1, 2, 1 , 1, 1,1,1, 2,1,3,1, 10))

phi2scale<-rep(c(1.6, 1.1, 1.5, 2.9,1.5, 1.2, 1.8, 0.5, 2.4, 1.9, 2.3, 1.5, 1.9, 
                 1.5,0.9, 1.9, 1.5,1.2, 2.6,1.6, 1.2, 1.6, 1.6, 1.0,1.5, 1.1, 1.5),
                 c(1, 1, 13, 1, 2, 1, 7, 1, 1, 6, 1, 2, 2,  22, 1,1, 2, 1 , 1, 1,1,1, 2,1,3,1, 10))

phi1scale<-rep(c(1.6, 1.1, 1.5, 2.9,1.5, 1.2, 1.8, 0.5, 2.4, 1.9, 2.3, 1.5, 1.9, 
                 1.5,0.5, 1.9, 1.5,1.2, 2.6,1.6, 1.2, 1.6, 1.6, 1.0,1.5, 1.1, 1.5),
                 c(1, 1, 13, 1, 2, 1, 7, 1, 1, 6, 1, 2, 2,  22, 1,1, 2, 1 , 1, 1,1,1, 2,1,3,1, 10))


count1<-rep(0, 3)
count2<-rep(0, 87)
count3<-rep(0, 87) 
count4<-rep(0, 87)  
count5<-rep(0, 2)
count6<-rep(0, 2)

betascale<-c(0.03, 0.18, 0.09)
lamscale1<-c(0.13, 0.13, 0.13)
lamscale2<-c(0.012, 0.012, 0.012)
etascale<-c(1.1, 1.1, 1.1)
thetascale<-c(0.35, 0.35, 0.35)

eigen0<-c(1, 0.976466, 0.945103, 0.914546, 0.896109, 0.853733, -0.828599, 
0.810916, -0.797678, 0.787944, 0.752647, 0.722467, 0.671456, 
0.653351, -0.644926, 0.635718, -0.596496, -0.585722, 0.584486, 
-0.569975, -0.559889, 0.547598, -0.533633, -0.526835, -0.51854, 
0.507757, -0.48498, 0.481172, -0.460869, -0.451699, 0.45023, 
0.443717, -0.443393, -0.42966, -0.419549, -0.414294, -0.405326, 
0.404818, -0.395494, 0.38954, -0.384918, -0.376355, -0.371398, 
-0.357654, -0.35455, 0.353759, -0.344871, -0.34066, 0.337249, 
-0.325639, -0.324645, 0.315731, -0.304237, -0.302407, -0.296646, 
-0.28674, 0.275953, -0.264383, -0.244665, -0.239905, 0.236394, 
-0.23333, -0.219387, 0.213575, -0.1959, 0.18821, -0.182575, -0.177528, 
0.171187, 0.163226, -0.162738, -0.158852, 0.142323, -0.125492, 
-0.112241, -0.100351, 0.094117, -0.088885, 0.078619, -0.071806, 
0.060392, -0.0526, -0.03992, 0.036946, 0.019738, -0.013601, 0.005243
)

dbar<-0
dtheta<-0

beta1<-c(0, 0, 0)
lamda1<-c(0, 0, 0, 0, 0, 0)
alpha1<-c(0, 0, 0, 0, 0, 0)
phi11<-rep(0, 87)
phi21<-rep(0, 87)
phi31<-rep(0, 87)
p1<-rep(0, 87)
p2<-rep(0, 87)
p3<-rep(0, 87)


 result<- .C("mcar",            beta=matrix(as.double(0),m, 3),
                                phi1=matrix(as.double(0),m, 87),
                                phi2=matrix(as.double(0),m, 87),
                                phi3=matrix(as.double(0),m, 87),
                                alpha=matrix(as.double(0),m, 6),
                                lamda=matrix(as.double(0),m, 6),
                                as.double(Y10),
                                as.double(N10),
                                as.double(Y20),
                                as.double(N20),
                                as.double(Y30),
                                as.double(N30),
                                as.double(beta0),
                                as.double(phi10), 
                                as.double(phi20),
                                as.double(phi30),
                                as.double(lamda0),
                                as.double(eta0),
                                as.double(theta0),
                                as.double(eigen0),  
                                as.integer(nstart),
                                as.integer(nend),
                                accept1=as.integer(count1),
                                accept2=as.integer(count2), 
                                accept3=as.integer(count3), 
                                accept4=as.integer(count4),
                                accept5=as.integer(count5), 
                                accept6=as.integer(count6), 
                                as.double(betascale),
                                as.double(phi1scale),
                                as.double(phi2scale),
                                as.double(phi3scale), 
                                as.double(lamscale1),
                                as.double(lamscale2),
                                as.double(etascale),
                                as.double(thetascale),
                                betam=as.double(beta1),
                                phi1m=as.double(phi11), 
                                phi2m=as.double(phi21),
                                phi3m=as.double(phi31),
                                alpham=as.double(alpha1),
                                lamdam=as.double(lamda1),
                                p1m=as.double(p1), 
                                p2m=as.double(p2),
                                p3m=as.double(p3),
                                Dbar=as.double(dbar),
                                Dtheta=as.double(dtheta) 
   
)         
                

            







         
