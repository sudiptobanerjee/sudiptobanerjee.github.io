#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "matrix.h"
#include "generator.h"
#include <Rmath.h>
#include <R.h>
#include "R_ext/Applic.h"


/* Uses the algorithm on pp. 231-232 of W J Kennedy, Jr,         */
/* and J E Gentle, Statistical Computing, Dekker 1980.           */
/* generate from W(n, V) with dim=p                   */

/*void rwishart (double **wishart, double **V, int dim, int n)
{
           int i, j, k, *p, *inf, l;
           double **b, **A, **tA, *y, **s,**z, *temp1, *temp2 ;

		   if(n<dim)
			   {
		         REprintf("N should not be less than dimension\n");
		         return;
			   }

		   temp1= create_vectord (dim*dim);
           temp2= create_vectord (dim*dim);
		   y = create_vectord (dim);
           A=create_matrixd (dim, dim);
           tA = create_matrixd(dim, dim);
           s = create_matrixd (dim, dim);
           b= create_matrixd (dim, dim);
           z= create_matrixd (dim, dim);

		   p=&dim; inf=&l;
		   matvector (temp1, V,dim, dim);
		   F77_CALL(chol)(temp1, p, p, temp2, inf);
		   if(inf[0]!=0)
			   {
		         REprintf("This is not P.d matrix\n");
		         return;
			   }
           vectormat (A, temp2, dim,dim);

		   for (j=0; j<dim; j++)
			   for (i=0; i<dim; i++)
				  if(i<=j ) z[i][j]=norm_rand( );
			      else z[i][j]=0;

		   for (j=0; j<dim; j++)  y[j]=rchisq(n-j);

		   b[0][0]=y[0];
           for (j=1;j < dim;j++) {
                b[j][j]=y[j];
                for (i=0;i <j;i++)  b[j][j]+=z[i][j]*z[i][j];
                b[0][j]=z[0][j]*sqrt(y[0]);
                for (i=1;i < j;i++) {
                        b[i][j]=z[i][j]*sqrt(y[i]);
                        for (k=0;k < i;k++)
                                b[i][j]+=z[k][i]*z[k][j];
                }
                for (i=0;i < j;i++)
                        b[j][i]=b[i][j];
          }

		   transpose (tA, A, dim, dim);
           matpr (s, A, b, dim, dim, dim);
           matpr (wishart, s, tA,dim,dim, dim);

       freematd (z, dim, dim);
	   freematd (b, dim, dim);
	   freematd (s, dim, dim);
	   freematd (A, dim, dim);
	   freematd (tA, dim, dim);
	   Free (temp2);
	   Free (temp1);
	   Free (y);


}

*/


void rwishart (double **wishart, double **V, int dim, int m)
{
	int i, j;
	double **X, *temp, **tX, *mean;
    if(m<dim)
	   {
	       REprintf("N should not be less than dimension\n");
	       return;
	   }

	X = create_matrixd (m, dim);
	temp = create_vectord (dim);
	mean = create_vectord (dim);
	tX = create_matrixd (dim, m);
	for (i = 0; i < dim; i++) mean[i] = 0.0;
	for (i = 0; i < m; i++) {
		multinormal (temp, mean, V, dim);
		for (j = 0; j < dim; j++) X[i][j] = temp[j];
	}

	transpose (tX, X, m, dim);
	matpr (wishart, tX, X, dim, m, dim);

	freematd (X, m, dim);
	freematd (tX, dim, m);
	Free (temp);
	Free (mean);
}




void multinormal (double *vector, double *mean, double **disp, int dim)
{
	int i, *inf, l, *p;
	double *x, *z, **A, *temp1, *temp2, **tA  ;

	temp1= create_vectord(dim*dim);
	temp2= create_vectord (dim*dim);
	p=&dim; inf=&l;
    matvector (temp1, disp,dim, dim);
    F77_CALL(chol)(temp1, p, p, temp2, inf);
	if(inf[0]!=0)
			   {
		         REprintf("This is not P.d matrix\n");
				 Free (temp1);
	             Free (temp2);
		         return;
			   }
	x = create_vectord (dim);
	z = create_vectord (dim);
	A=create_matrixd (dim, dim);
    tA=create_matrixd (dim, dim);
    vectormat (A, temp2, dim,dim);
    transpose (tA, A, dim, dim);
	for (i = 0; i < dim; i++) z[i] = norm_rand( );
	matvecpr (x, tA, dim, dim, z);
	for (i = 0; i < dim; i++) vector[i] = mean[i] + x[i];
	Free (x);
	Free (z);
	Free (temp1);
	Free (temp2);
	freematd (A, dim, dim);
    freematd (tA, dim, dim);
}
