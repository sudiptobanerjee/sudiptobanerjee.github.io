#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include "matrix.h"
#include "generator.h"
#include <R.h>
#include <Rmath.h>
#include "R_ext/Applic.h"


double **create_matrixd (int row, int col)
{
    register int i;
    double **matrix;

    matrix = Calloc(row, double *);
	assert(matrix);
    for(i = 0; i < row; ++i) {
        matrix[i] = Calloc(col, double);
        assert(matrix[i]);
	}
    return matrix;
}

double *create_vectord (int dim)
{
  double *vector;

  vector = Calloc (dim, double);
  assert(vector);

  return vector;
}


int *create_vector (int dim)
{
  int *vector;

  vector = Calloc (dim, int);
  assert(vector);

  return vector;
}


int **create_matrix (int row, int col)
{
    register int i;
    int **matrix;

    matrix = Calloc(row, int *);
    assert(matrix);
	for(i = 0; i < row; ++i) {
        matrix[i] = Calloc(col,int);
        assert(matrix[i]);
	}
    return matrix;

}

void freematd (double **a, int row, int col)
{
	int i;

	for (i = 0; i < row; i++) Free(a[i]);
	Free(a);
}

void freemat (int **a, int row, int col)
{
	int i;

	for (i = 0; i < row; i++) Free(a[i]);
	Free(a);
}


void matpr (double **c, double **a, double **b, int m, int p, int n)
{
          int i, j, k;
          double sum;

           for (i = 0; i < m ; i++) {
           	for(j = 0; j < n; j++) {
           		sum = 0 ;
           		for (k = 0; k < p; k++) {
           		sum += a[i][k] * b[k][j];
		}
	     c[i][j]  = sum;
	}
         }
}

void matsclpr (double **matrix, double a, double **b, int rows, int cols)
{
   int i, j;

   	for (i = 0; i < rows; i++) {
   		 for (j = 0; j < cols; j++) {
   		 	matrix[i][j] = a * b[i][j];
   		 }
   	}
}

void matsum (double **matrix, double **a, double **b, int rows, int cols)
{
   int i, j;

	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) matrix[i][j] = a[i][j] + b[i][j];
	}
}


void matdiff (double **matrix, double **a, double **b, int rows, int cols)
{
   int i, j;

	for (i = 0; i < rows; i++) {
		for (j = 0; j < cols; j++) matrix[i][j] = a[i][j] - b[i][j];
	}
}


void transpose (double **matrix, double **x, int rows, int cols)
{
  int  i, j;

  	for (i = 0; i < rows; i++) {
  		for ( j = 0; j < cols; j++) {
  			matrix[j][i] = x[i][j];
  		}
  	}
}




double det (double **matrix, int dim)
{
double *temp1;
double *qraux, *b, prod=1.0;
double *tol, tol1;
int *pivot, *n, *k, i , rank;
n=&dim;
temp1=create_vectord(dim*dim);
pivot=create_vector(dim);
qraux=create_vectord(dim);
b=create_vectord(dim*2);
k=&rank;
tol1=1.0e-07;
tol=&tol1;
matvector (temp1, matrix,dim, dim);
F77_CALL(dqrdc2)(temp1,n,n,n,tol,k,qraux,pivot,b);

if(k[0]< dim) { REprintf("This is not full rank matrix\n");
                return(0);
			  }
for (i = 0; i < dim; i++) prod=prod*temp1[i*dim+i];



Free(temp1);
Free(pivot);
Free(qraux);
Free(b);

if((dim % 2) == 1) return(prod);
else return((-1.0)*prod);

}



double trace (double **a, int dim)
{
 int i;
 double sum;
 	sum = 0;
 	for (i = 0; i < dim; i++) sum += a[i][i];
 return sum;
}


void Row_extract (double *row_vector, double **matrix, int row_no, int ncol)
{
	int j;

	for (j = 0; j < ncol; j++) row_vector[j] = matrix[row_no][j];
}

void Col_extract (double *col_vector, double **matrix, int col_no, int nrow)
{
	int i;

	for (i = 0; i < nrow; i++) col_vector[i] = matrix[i][col_no];
}


void vecprm (double **matrix, double *vector1, double *vector2, int rows, int cols)
{
  int i, j;
  for (i = 0; i < rows; i++)
	{
  	 for (j = 0; j < cols; j++) 	matrix[i][j]=vector1[i]*vector2[j];
	}

}


void zero_mat(double **matrix, int rows, int cols)
{
	int i, j;
	for (i = 0; i < rows; i++)
	{
  	 for (j = 0; j < cols; j++) 	matrix[i][j]=0;
	}

}


void ident_mat(double **matrix, int dim)
{
	int i, j;
	for (i = 0; i < dim; i++)
	{
  	 for (j = 0; j < dim; j++)
		 { if (i!=j) matrix[i][j]=0;
	       else matrix[i][j]=1;
		}
	}

}


void kroneckerprod(double **c, double **a, double **b,
					   int rowa, int cola, int rowb, int colb)
{
	int i, j, k, l, rowc, colc;

	rowc = rowa*rowb;
	colc = cola*colb;

		for (k = 0; k < rowa; k++) {
			for (l = 0; l < cola; l++) {
				for (i = 0; i < rowb; i++) {
					for (j = 0; j < colb; j++) {
						c[k*rowb+i][l*colb+j] = a[k][l] * b[i][j];
					}
				}
			}
		}
}



void sub_matrix (double **matrix, double **a, int rowa, int cola, int rowb , int colb)
{
  int i, j, m, n;
  m=rowa*rowb;
  n=cola*colb;

  	for (i = 0; i < rowb; i++) {
  		for (j=0; j < colb; j++) {
  			matrix[i][j] = a[m+i][n+j];
  		}
  	}
}

/* Vector X matrix */

void vecmatpr (double *vector, double **a, int rows, int cols, double *x)
{
  int i, j;
  double sum;

  	for (j = 0; j < cols; j++) {
  		sum = 0;
  		for (i = 0; i < rows; i++) {
  			sum += a[i][j] * x[i];
  		}
  		vector[j] = sum;
  	}
 }


double vecprs (double *vector1, double *vector2, int row)
{
  int i;
  double sum=0;
  for (i = 0; i < row; i++) sum=sum+vector1[i]*vector2[i];
  return(sum);

}

/***** by column ****/
void vectormat (double **matrix, double *vector, int nrow, int ncol)
{
	int i, j;

	for (i = 0; i < nrow; i++) {
		for (j = 0; j < ncol; j++) matrix[i][j] = vector[j*nrow+i];
	}

}


void matvector (double *vector, double **matrix,int nrow, int ncol)
{
	int i, j;

	for (i = 0; i < nrow; i++) {
		for (j = 0; j < ncol; j++) vector[j*nrow+i]=matrix[i][j];
	}

}


/*Mattrix X vector */
void matvecpr (double *vector, double **a, int rows, int cols, double *x)
{
  int i, j;
  double sum;

  	for (i = 0; i < rows; i++) {
  		sum = 0;
  		for (j = 0; j < cols; j++) {
  			sum += a[i][j] * x[j];
  		}
  		vector[i] = sum;
  	}
 }


void inverse (double **invertmat, int dim, double **matrix)
{

double *qraux, *b,  *y, **ymat, *temp1, *temp2;
double *tol, tol1;
int *pivot, *n, *k, rank, *inf, l;
n=&dim;
pivot=create_vector(dim);
qraux=create_vectord(dim);
b=create_vectord(dim*2);
k=&rank;
tol1=1.0e-07;
tol=&tol1;
inf=&l;

temp1=create_vectord(dim*dim);
matvector (temp1, matrix,dim, dim);

ymat=create_matrixd(dim, dim);
ident_mat(ymat, dim);
y=create_vectord(dim*dim);
matvector (y, ymat,dim, dim);

temp2=create_vectord(dim*dim);

F77_CALL(dqrdc2)(temp1,n,n,n,tol,k,qraux,pivot,b);

if(k[0]<dim) { REprintf("This is not full rank matrix\n");
               return;
			 }

F77_CALL(dqrcf)(temp1,n,k,qraux,y, n, temp2,inf);

if(inf[0]!= 0) { REprintf("This is a singular matrx\n");
                 return;
			   }

vectormat (invertmat, temp2, dim, dim);

Free(pivot);
Free(qraux);
Free(b);
Free(y);
Free(temp1);
Free(temp2);
freematd(ymat, dim, dim);

}


void cholcop(double **matrix, double **A, int dim)
{
	int *inf, l, *p;
	double *temp1, *temp2;
	temp1= create_vectord(dim*dim);
	temp2= create_vectord (dim*dim);
	p=&dim; inf=&l;
    matvector (temp1, A,dim, dim);
    F77_CALL(chol)(temp1, p, p, temp2, inf);
	vectormat (matrix, temp2, dim,dim);
   	Free (temp1);
	Free (temp2);
	if(inf[0]!=0)
	   {
	      REprintf("This is not P.d matrix\n");
	      return;
	   }
}


/*****This program for eigen value only works for a symetric matrix  ***********/

void eigen(double **matrix, double *value, int*n, int *m)

{
   int *inf, l=0, k=1, *matz;
   double *temp1, *temp2, *temp3;
   if (m[0]!=n[0]) { REprintf("This is a singular matrx\n");
                             return;
 	        }
   temp1=create_vectord(m[0]*m[0]);
   matvector (temp1, matrix,m[0], m[0]);
   temp2=create_vectord(m[0]*m[0]);
   temp3=create_vectord(m[0]);
   inf=&l;
   matz=&k;
   F77_CALL(rs)(n, m, temp1, value, matz, temp2, temp3, temp3, inf);
   if (inf[0]!=0)  { REprintf("This is a wrong result\n");
                           return;
                         }

   Free(temp1);
   Free(temp2);
   Free(temp3);


}



/*****This program for eigen value works for a general matrix  ***********/

void eigen2(double **matrix, double *value1, double *value2, int*n, int *m)

{
   int *inf, l=0, k=1, *matz, *temp4;
   double *temp1, *temp2, *temp3;
   if (m[0]!=n[0]) { REprintf("This is a singular matrx\n");
                             return;
 	        }
   temp1=create_vectord(m[0]*m[0]);
   matvector (temp1, matrix,m[0], m[0]);
   temp2=create_vectord(m[0]*m[0]);
   temp3=create_vectord(m[0]);
   temp4=create_vector(m[0]);
   inf=&l;
   matz=&k;
   F77_CALL(rg)(n, m, temp1, value1, value2, matz, temp2, temp4, temp3, inf);
   if (inf[0]!=0)  { REprintf("This is a wrong result\n");
                           return;
                         }

   Free(temp1);
   Free(temp2);
   Free(temp3);
   Free(temp4);


}


