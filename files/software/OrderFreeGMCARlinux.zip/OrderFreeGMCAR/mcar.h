#define no_regions	87
#define N	87
#define p 3
#define a1 3
#define b1 0.3

void read_data (void);

void start_vals (double *Y10,double *Y20, double *Y30, double *N10,double *N20,double *N30, double *beta0,
                 double *phi10, double *phi20,double *phi30,double *lamda0, double *eta0,double *theta0,
				 double *eigen10);


void global_memory (void);
void alphafun( double *xalpha, double *xtheta, double *xeta);
/*
double target_lamda1(double x);
double target_lamda2(double x);
double target_lamda3(double x);
double target_lamda4(double x);
double target_lamda5(double x);
double target_lamda6(double x);
*/

double target_lamda(double *x);

double target_beta1(double x);
double target_beta2(double x);
double target_beta3(double x);


void metroplis_alpha1(double *x_cur, double *x_prev, double *scale);
void metroplis_alpha2(double *x_cur, double *x_prev, double *scale);


double target_alpha1(double *x, double *z);
double target_alpha2(double *z);

double target_phi1(double x,  int k);
double target_phi2(double x,  int k);
double target_phi3(double x,  int k);


double metroplis_phi1(int j, double x_prev, double scale);
double metroplis_phi2(int j, double x_prev, double scale);
double metroplis_phi3(int j, double x_prev, double scale);

/*
double metroplis_lamda1(double x_prev, double scale);
double metroplis_lamda2(double x_prev, double scale);
double metroplis_lamda3(double x_prev, double scale);
double metroplis_lamda4(double x_prev, double scale);
double metroplis_lamda5(double x_prev, double scale);
double metroplis_lamda6(double x_prev, double scale);
*/

void metroplis_lamda1(double *x_cur, double *x_prev, double *scale);
void metroplis_lamda2(double *x_cur, double *x_prev, double *scale);


double metroplis_beta1(double x_prev, double scale);
double metroplis_beta2(double x_prev, double scale);
double metroplis_beta3(double x_prev, double scale);


double density(void);
double dtheta_fun (double *p1_m, double *p2_m, double *p3_m);
//double dtheta_fun (double *beta0_m, double *lamda0_m, double *phi10_m,
//                    double *phi20_m, double *phi30_m);
