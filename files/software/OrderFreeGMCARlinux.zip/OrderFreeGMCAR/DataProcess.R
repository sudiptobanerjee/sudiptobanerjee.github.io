dat1<-read.table("c:\\paper3\\cancerdata\\research data\\esoph.txt")

count<-rep(0, 18)
pop<-rep(0, 18)
rate<-rep(0, 18)

for (i in 1:18)
{
for ( j in 1:87)
{
 count[i]<-count[i]+ dat1[i+ (j-1)*18, 4]
 pop[i]<- pop[i]+ dat1[i+ (j-1)*18, 5]
}

rate[i]<-count[i]/pop[i]
}


exprate<-rep(rate, 87)
expdeath<-exprate*dat1[ ,5]

newdata<-cbind(dat1, exprate, expdeath)

obs<-rep(0, 87)
expect<-rep(0, 87) 

for ( j in 1:87)
{
 for (k in 1:18) 
 { obs[j]<-obs[j]+ newdata[(j-1)*18+k, 4]
   expect[j]<-expect[j]+ newdata[(j-1)*18+k, 7]
}

}

newdat1<-cbind(obs, expect)


dat2<-read.table("c:\\paper3\\cancerdata\\research data\\layrx.txt")


count<-rep(0, 18)
pop<-rep(0, 18)
rate<-rep(0, 18)

for (i in 1:18)
{
for ( j in 1:87)
{
 count[i]<-count[i]+ dat2[i+ (j-1)*18, 4]
 pop[i]<- pop[i]+ dat2[i+ (j-1)*18, 5]
}

rate[i]<-count[i]/pop[i]
}


exprate<-rep(rate, 87)
expdeath<-exprate*dat2[ ,5]

newdata<-cbind(dat2, exprate, expdeath)

obs<-rep(0, 87)
expect<-rep(0, 87) 

for ( j in 1:87)
{
 for (k in 1:18) 
 { obs[j]<-obs[j]+ newdata[(j-1)*18+k, 4]
   expect[j]<-expect[j]+ newdata[(j-1)*18+k, 7]
}

}

newdat2<-cbind(obs, expect)

dat3<-read.table("c:\\paper3\\cancerdata\\research data\\lung.txt")

count<-rep(0, 18)
pop<-rep(0, 18)
rate<-rep(0, 18)

for (i in 1:18)
{
for ( j in 1:87)
{
 count[i]<-count[i]+ dat3[i+ (j-1)*18, 4]
 pop[i]<- pop[i]+ dat3[i+ (j-1)*18, 5]
}

rate[i]<-count[i]/pop[i]
}


exprate<-rep(rate, 87)
expdeath<-exprate*dat3[ ,5]

newdata<-cbind(dat3, exprate, expdeath)

obs<-rep(0, 87)
expect<-rep(0, 87) 

for ( j in 1:87)
{
 for (k in 1:18) 
 { obs[j]<-obs[j]+ newdata[(j-1)*18+k, 4]
   expect[j]<-expect[j]+ newdata[(j-1)*18+k, 7]
}

}

newdat3<-cbind(obs, expect)



finaldat<-cbind(newdat1, newdat2, newdat3)

write(t(finaldat), "c:\\Paper3\\cancerdata\\research data\\newcancer.txt", ncolumn=6)
